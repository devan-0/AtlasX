import React from 'react';

interface Props {
  label?: string;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

const SIZES = {
  sm: 'w-5 h-5 border-2',
  md: 'w-8 h-8 border-2',
  lg: 'w-12 h-12 border-3',
};

export default function LoadingSpinner({ label, size = 'md', className = '' }: Props) {
  return (
    <div className={`flex flex-col items-center gap-2 ${className}`}>
      <div className={`${SIZES[size]} border-mars-500 border-t-transparent rounded-full animate-spin`} />
      {label && <span className="text-xs text-slate-400 font-mono">{label}</span>}
    </div>
  );
}
