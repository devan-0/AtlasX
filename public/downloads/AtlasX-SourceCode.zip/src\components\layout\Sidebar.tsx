// Sidebar — persistent left navigation with collapse support
import React from 'react';
import {
  LayoutDashboard,
  Map,
  Mountain,
  Route,
  FlaskConical,
  Layers,
  Sun,
  Wind,
  Shield,
  GitCompare,
  Database,
  Bookmark,
  Settings,
  ChevronLeft,
  ChevronRight,
  Rocket,
} from 'lucide-react';
import { useAppStore } from '../../store/useAppStore';

const NAV_ITEMS = [
  { id: 'overview', icon: LayoutDashboard, label: 'Mission Overview' },
  { id: 'atlas', icon: Map, label: 'Interactive 2D Atlas' },
  { id: 'terrain3d', icon: Mountain, label: '3D Terrain Explorer' },
  { id: 'routes', icon: Route, label: 'Marswalk Routes' },
  { id: 'science', icon: FlaskConical, label: 'Science Targets' },
  { id: 'minerals', icon: Layers, label: 'Minerals & Geology' },
  { id: 'solar', icon: Sun, label: 'Solar Energy' },
  { id: 'atmosphere', icon: Wind, label: 'Atmosphere & Wind' },
  { id: 'suitability', icon: Shield, label: 'Landing Suitability' },
  { id: 'comparison', icon: GitCompare, label: 'Site Comparison' },
  { id: 'catalogue', icon: Database, label: 'Data Catalogue' },
  { id: 'missions', icon: Bookmark, label: 'Saved Missions' },
  { id: 'settings', icon: Settings, label: 'Settings' },
] as const;

type NavId = (typeof NAV_ITEMS)[number]['id'];

const SIDEBAR_EXPANDED = 220;
const SIDEBAR_COLLAPSED = 64;

const Sidebar: React.FC = () => {
  const activePage = useAppStore((s) => s.activePage);
  const setActivePage = useAppStore((s) => s.setActivePage);
  const sidebarCollapsed = useAppStore((s) => s.sidebarCollapsed);
  const toggleSidebar = useAppStore((s) => s.toggleSidebar);

  const width = sidebarCollapsed ? SIDEBAR_COLLAPSED : SIDEBAR_EXPANDED;

  return (
    <aside
      style={{ width }}
      className="flex-shrink-0 flex flex-col h-full bg-black/60 border-r border-white/10 backdrop-blur-md transition-all duration-300 overflow-hidden relative"
    >
      {/* Brand */}
      <div className="flex items-center gap-3 px-4 py-4 border-b border-white/10 flex-shrink-0 min-h-[64px]">
        <div className="flex-shrink-0 w-8 h-8 rounded-lg bg-mars-orange/20 border border-mars-orange/40 flex items-center justify-center">
          <Rocket className="w-4 h-4 text-mars-orange" />
        </div>
        {!sidebarCollapsed && (
          <div className="min-w-0">
            <p className="text-[13px] font-black tracking-[0.18em] text-white uppercase leading-tight truncate">
              Atlas<span className="text-mars-orange">X</span>
            </p>
            <span className="mt-0.5 inline-block text-[8px] font-mono text-white/30 tracking-wider truncate">
              Planetary Explorer
            </span>
          </div>
        )}
      </div>

      {/* Nav items */}
      <nav className="flex-1 overflow-y-auto overflow-x-hidden py-2 scrollbar-none">
        {NAV_ITEMS.map(({ id, icon: Icon, label }) => {
          const isActive = activePage === (id as NavId);
          return (
            <button
              key={id}
              onClick={() => setActivePage(id as NavId)}
              title={sidebarCollapsed ? label : undefined}
              className={`
                w-full flex items-center gap-3 px-4 py-2.5 text-left
                transition-all duration-150 group relative
                ${
                  isActive
                    ? 'bg-mars-orange/15 text-mars-orange'
                    : 'text-white/50 hover:text-white/90 hover:bg-white/5'
                }
              `}
            >
              {/* Active indicator bar */}
              {isActive && (
                <span className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-5 bg-mars-orange rounded-r" />
              )}

              <Icon
                className={`w-[18px] h-[18px] flex-shrink-0 transition-colors ${
                  isActive ? 'text-mars-orange' : 'text-white/40 group-hover:text-white/70'
                }`}
              />
              {!sidebarCollapsed && (
                <span className="text-[12px] font-medium tracking-wide truncate">{label}</span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="flex-shrink-0 border-t border-white/10">
        {/* Collapse toggle */}
        <button
          onClick={toggleSidebar}
          className="w-full flex items-center justify-center gap-2 py-3 text-white/30 hover:text-white/70 hover:bg-white/5 transition-all"
          title={sidebarCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {sidebarCollapsed ? (
            <ChevronRight className="w-4 h-4" />
          ) : (
            <>
              <ChevronLeft className="w-4 h-4" />
              <span className="text-[10px] font-mono tracking-wider">Collapse</span>
            </>
          )}
        </button>

        {!sidebarCollapsed && (
          <div className="px-4 pb-3 text-[9px] font-mono text-white/20 space-y-0.5">
            <p className="truncate">v1.0.0 · Desktop</p>
            <p className="truncate font-semibold text-white/40">AtlasX</p>
            <p className="truncate">© 2026 AtlasX Platform</p>
          </div>
        )}
      </div>
    </aside>
  );
};

export default Sidebar;
