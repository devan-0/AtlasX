// AtlasX — Unit Tests
// Run with: npx vitest run
// These tests verify the scientific utility modules.

import { describe, it, expect } from 'vitest';
import {
  marsDistance,
  isValidMarsCoord,
  normalizeLon,
  formatCoords,
  MARS_RADIUS_KM,
} from '../utils/marsCoordinates';
import {
  solarIrradiance,
  daylightDuration,
  dailySolarEnergy,
  earthDateToLS,
  computeSolarAnalysis,
  SOLAR_CONSTANT_MARS_W,
} from '../utils/solarGeometry';
import {
  generateTerrainGrid,
  aStarPath,
  buildRoute,
  closestCell,
  DEFAULT_WEIGHTS,
  ASTRONAUT_EVA_WEIGHTS,
} from '../utils/routePlanning';
import {
  calculateMetabolicWatts,
  calculateVO2LitersPerMin,
  calculateVCO2LitersPerMin,
  calculateHeartRateBpm,
  calculateSoilSlipPercent,
  evaluateEVARouteMetrics,
  getLiveAstronautBioState,
  MARS_GRAVITY_RATIO,
  RESPIRATORY_QUOTIENT,
} from '../utils/evaBiometrics';
import { computeEVAMeteorologicalAdvisory } from '../utils/evaWeatherHazard';
import { scienceTargetsToCSV, routeToGeoJSON } from '../utils/export';
import { SCIENCE_TARGETS, HAZARDS, CANDIDATE_SITES, MARS_2020_OUTCROPS } from '../data/sampleData';

// ── Coordinate Tests ─────────────────────────────────────────────────────────

describe('marsCoordinates', () => {
  it('MARS_RADIUS_KM should be approximately 3389.5', () => {
    expect(MARS_RADIUS_KM).toBeCloseTo(3389.5, 0);
  });

  it('marsDistance between identical points should be 0', () => {
    const a = { lat: 18.38, lon: 77.58 };
    expect(marsDistance(a, a)).toBeCloseTo(0, 5);
  });

  it('marsDistance should be positive for different points', () => {
    const a = { lat: 18.38, lon: 77.58 };
    const b = { lat: 19.0, lon: 78.0 };
    expect(marsDistance(a, b)).toBeGreaterThan(0);
  });

  it('marsDistance should be symmetric', () => {
    const a = { lat: 0, lon: 0 };
    const b = { lat: 45, lon: 90 };
    expect(marsDistance(a, b)).toBeCloseTo(marsDistance(b, a), 8);
  });

  it('marsDistance from pole to pole should be ~πR ≈ 10651 km', () => {
    const north = { lat: 90, lon: 0 };
    const south = { lat: -90, lon: 0 };
    const expected = Math.PI * MARS_RADIUS_KM;
    expect(marsDistance(north, south)).toBeCloseTo(expected, 0);
  });

  it('isValidMarsCoord should accept valid coordinates', () => {
    expect(isValidMarsCoord(18.38, 77.58)).toBe(true);
    expect(isValidMarsCoord(0, 0)).toBe(true);
    expect(isValidMarsCoord(-90, 180)).toBe(true);
    expect(isValidMarsCoord(90, 360)).toBe(true);
  });

  it('isValidMarsCoord should reject out-of-range coordinates', () => {
    expect(isValidMarsCoord(91, 0)).toBe(false);
    expect(isValidMarsCoord(-91, 0)).toBe(false);
    expect(isValidMarsCoord(0, 361)).toBe(false);
    expect(isValidMarsCoord(0, -181)).toBe(false);
  });

  it('normalizeLon should bring negative longitudes to [0, 360)', () => {
    expect(normalizeLon(-10)).toBeCloseTo(350, 5);
    expect(normalizeLon(370)).toBeCloseTo(10, 5);
    expect(normalizeLon(0)).toBeCloseTo(0, 5);
    expect(normalizeLon(180)).toBeCloseTo(180, 5);
  });

  it('formatCoords decimal should format correctly', () => {
    const result = formatCoords(18.38, 77.58, 'decimal');
    expect(result).toContain('18.38');
    expect(result).toContain('77.58');
  });
});

// ── Solar Geometry Tests ──────────────────────────────────────────────────────

describe('solarGeometry', () => {
  it('SOLAR_CONSTANT_MARS_W should be ~586 W/m²', () => {
    expect(SOLAR_CONSTANT_MARS_W).toBeCloseTo(586, 0);
  });

  it('solarIrradiance at perihelion (Ls≈251) should be higher than at aphelion (Ls≈71)', () => {
    const perihelion = solarIrradiance(251);
    const aphelion = solarIrradiance(71);
    expect(perihelion).toBeGreaterThan(aphelion);
  });

  it('solarIrradiance should be positive at all solar longitudes', () => {
    for (let ls = 0; ls <= 360; ls += 30) {
      expect(solarIrradiance(ls)).toBeGreaterThan(0);
    }
  });

  it('solarIrradiance should peak near Ls=251 (perihelion)', () => {
    const at251 = solarIrradiance(251);
    const at0 = solarIrradiance(0);
    const at180 = solarIrradiance(180);
    expect(at251).toBeGreaterThan(at0);
    expect(at251).toBeGreaterThan(at180);
  });

  it('daylightDuration at equator should be ~12 h at equinox (Ls=0)', () => {
    const hours = daylightDuration(0, 0);
    expect(hours).toBeGreaterThan(10);
    expect(hours).toBeLessThan(14);
  });

  it('daylightDuration at pole in summer should be > 12 h', () => {
    // North pole at northern summer (Ls=90)
    const hours = daylightDuration(90, 90);
    expect(hours).toBeGreaterThan(12);
  });

  it('daylightDuration should be non-negative everywhere', () => {
    for (const lat of [-90, -60, -30, 0, 30, 60, 90]) {
      for (let ls = 0; ls <= 360; ls += 60) {
        expect(daylightDuration(lat, ls)).toBeGreaterThanOrEqual(0);
      }
    }
  });

  it('dailySolarEnergy should be positive at equator at equinox', () => {
    expect(dailySolarEnergy(0, 0)).toBeGreaterThan(0);
  });

  it('earthDateToLS should return a value in [0, 360]', () => {
    const ls = earthDateToLS('2024-01-01');
    expect(ls).toBeGreaterThanOrEqual(0);
    expect(ls).toBeLessThanOrEqual(360);
  });

  it('computeSolarAnalysis should return valid analysis object', () => {
    const analysis = computeSolarAnalysis(18.38, 77.58, '2024-06-01');
    expect(analysis.estimatedIrradianceWm2).toBeGreaterThan(0);
    expect(analysis.illuminationDurationH).toBeGreaterThan(0);
    expect(analysis.illuminationDurationH).toBeLessThan(25);
    // classification is 'modelled' or 'derived' — both valid for geometric estimation
    expect(['derived', 'modelled']).toContain(analysis.classification);
    expect(analysis.assumptions.length).toBeGreaterThan(0);
  });
});

// ── Route Planning Tests ──────────────────────────────────────────────────────

describe('routePlanning', () => {
  const grid = generateTerrainGrid(19, 17, 79, 76, 16);

  it('generateTerrainGrid should return correct dimensions', () => {
    expect(grid.length).toBe(16);
    expect(grid[0].length).toBe(16);
  });

  it('generateTerrainGrid cells should have valid slopes (0–90°)', () => {
    for (const row of grid) {
      for (const cell of row) {
        expect(cell.slope).toBeGreaterThanOrEqual(0);
        expect(cell.slope).toBeLessThanOrEqual(90);
      }
    }
  });

  it('generateTerrainGrid cells should have valid hazardPenalty (0–1)', () => {
    for (const row of grid) {
      for (const cell of row) {
        expect(cell.hazardPenalty).toBeGreaterThanOrEqual(0);
        expect(cell.hazardPenalty).toBeLessThanOrEqual(1);
      }
    }
  });

  it('closestCell should return valid grid indices', () => {
    const [r, c] = closestCell(grid, 18.0, 77.5);
    expect(r).toBeGreaterThanOrEqual(0);
    expect(r).toBeLessThan(grid.length);
    expect(c).toBeGreaterThanOrEqual(0);
    expect(c).toBeLessThan(grid[0].length);
  });

  it('aStarPath from corner to corner should return a path', () => {
    const path = aStarPath(grid, 0, 0, 15, 15, DEFAULT_WEIGHTS, 35);
    expect(path.length).toBeGreaterThan(1);
  });

  it('aStarPath from start=end should return a trivial path', () => {
    const path = aStarPath(grid, 5, 5, 5, 5, DEFAULT_WEIGHTS, 35);
    // May return [startNode] or similar; at minimum, should not error
    expect(path).toBeDefined();
  });

  it('buildRoute should produce a Route with positive totalDistance', () => {
    const path = aStarPath(grid, 0, 0, 15, 15, DEFAULT_WEIGHTS, 35);
    const route = buildRoute('test-route', 'Test', 'shortest', path, grid, DEFAULT_WEIGHTS);
    expect(route.totalDistance).toBeGreaterThan(0);
    expect(route.id).toBe('test-route');
    expect(route.type).toBe('shortest');
    expect(route.profile.length).toBe(path.length);
  });

  it('buildRoute cost breakdown components should all be non-negative', () => {
    const path = aStarPath(grid, 0, 0, 15, 15, DEFAULT_WEIGHTS, 35);
    const route = buildRoute('test-2', 'Test 2', 'lower-risk', path, grid, DEFAULT_WEIGHTS);
    expect(route.costBreakdown.distance).toBeGreaterThanOrEqual(0);
    expect(route.costBreakdown.terrain).toBeGreaterThanOrEqual(0);
    expect(route.costBreakdown.hazard).toBeGreaterThanOrEqual(0);
  });

  it('buildRoute with slope cutoff of 5° should not include steep cells', () => {
    const path = aStarPath(grid, 0, 0, 15, 15, DEFAULT_WEIGHTS, 5);
    // Path should exist (fallback) and all traversed cells should respect slope
    expect(path).toBeDefined();
  });
});

// ── Data Integrity Tests ──────────────────────────────────────────────────────

describe('sampleData', () => {
  it('all science targets should have valid coordinates', () => {
    for (const t of SCIENCE_TARGETS) {
      expect(isValidMarsCoord(t.coordinates.lat, t.coordinates.lon)).toBe(true);
    }
  });

  it('all hazards should have non-zero confidence', () => {
    for (const h of HAZARDS) {
      expect(h.confidence).toBeGreaterThan(0);
      expect(h.confidence).toBeLessThanOrEqual(1);
    }
  });

  it('candidate sites should have landing suitability scores in [0, 100]', () => {
    for (const site of CANDIDATE_SITES) {
      if (site.landingSuitability) {
        expect(site.landingSuitability.overall).toBeGreaterThanOrEqual(0);
        expect(site.landingSuitability.overall).toBeLessThanOrEqual(100);
      }
    }
  });

  it('all science targets should have priorities between 1 and 5', () => {
    for (const t of SCIENCE_TARGETS) {
      expect(t.priority).toBeGreaterThanOrEqual(1);
      expect(t.priority).toBeLessThanOrEqual(5);
    }
  });
});

// ── Export Tests ──────────────────────────────────────────────────────────────

describe('export', () => {
  it('scienceTargetsToCSV should produce a non-empty string', () => {
    const csv = scienceTargetsToCSV(SCIENCE_TARGETS);
    expect(typeof csv).toBe('string');
    expect(csv.length).toBeGreaterThan(0);
    expect(csv).toContain('name');
    expect(csv).toContain('lat');
  });

  it('scienceTargetsToCSV should have correct number of rows', () => {
    const csv = scienceTargetsToCSV(SCIENCE_TARGETS);
    const lines = csv.trim().split('\n');
    // header + one line per target
    expect(lines.length).toBe(SCIENCE_TARGETS.length + 1);
  });

  it('routeToGeoJSON should produce a valid GeoJSON FeatureCollection', () => {
    const grid = generateTerrainGrid(19, 17, 79, 76, 16);
    const path = aStarPath(grid, 0, 0, 15, 15, DEFAULT_WEIGHTS, 35);
    const route = buildRoute('geojson-test', 'GeoJSON Test', 'shortest', path, grid, DEFAULT_WEIGHTS);
    const geoJSON = routeToGeoJSON(route) as any;
    expect(geoJSON.type).toBe('FeatureCollection');
    expect(Array.isArray(geoJSON.features)).toBe(true);
    expect(geoJSON.features.length).toBeGreaterThan(0);
  });
});

// ── Astronaut Physiological & EVA Survival Tests ─────────────────────────────

describe('evaBiometrics (Mars 0.38g Human EVA Modeling)', () => {
  it('MARS_GRAVITY_RATIO should be approximately 0.3794', () => {
    expect(MARS_GRAVITY_RATIO).toBeCloseTo(0.3794, 3);
  });

  it('calculateMetabolicWatts should produce realistic Martian suited walking expenditure', () => {
    const flatWalkWatts = calculateMetabolicWatts(0.95, 0, 1.3);
    expect(flatWalkWatts).toBeGreaterThan(120);
    expect(flatWalkWatts).toBeLessThan(420);

    // Incline should increase metabolic expenditure
    const uphillWatts = calculateMetabolicWatts(0.95, 12, 1.7);
    expect(uphillWatts).toBeGreaterThan(flatWalkWatts);

    // Higher speed should increase expenditure
    const fastWatts = calculateMetabolicWatts(1.2, 0, 1.3);
    expect(fastWatts).toBeGreaterThan(flatWalkWatts);
  });

  it('VO2 and VCO2 rates should be positive and follow respiratory quotient 0.85', () => {
    const watts = 250;
    const vo2 = calculateVO2LitersPerMin(watts);
    const vco2 = calculateVCO2LitersPerMin(vo2);

    expect(vo2).toBeGreaterThan(0.5);
    expect(vo2).toBeLessThan(2.5);
    expect(vco2 / vo2).toBeCloseTo(RESPIRATORY_QUOTIENT, 4);
  });

  it('calculateHeartRateBpm should respond proportionally to metabolic wattage', () => {
    const restHR = calculateHeartRateBpm(110);
    const hardHR = calculateHeartRateBpm(450);

    expect(restHR).toBeGreaterThanOrEqual(68);
    expect(hardHR).toBeGreaterThan(restHR);
    expect(hardHR).toBeLessThanOrEqual(175);
  });

  it('calculateSoilSlipPercent should model Curiosity/Perseverance non-linear slope slip', () => {
    const flatSlip = calculateSoilSlipPercent(2);
    const moderateSlip = calculateSoilSlipPercent(12);
    const steepSlip = calculateSoilSlipPercent(22);

    expect(flatSlip).toBeLessThan(10);
    expect(moderateSlip).toBeGreaterThan(flatSlip);
    expect(steepSlip).toBeGreaterThan(40);
  });

  it('evaluateEVARouteMetrics should evaluate consumables and Point of No Return (PNR)', () => {
    const profile = [
      { lat: 18.0, lon: 77.0, elevation: -2400, slope: 3 },
      { lat: 18.05, lon: 77.05, elevation: -2380, slope: 6 },
      { lat: 18.1, lon: 77.1, elevation: -2350, slope: 10 },
      { lat: 18.15, lon: 77.15, elevation: -2310, slope: 14 },
    ];
    const metrics = evaluateEVARouteMetrics(profile, 4.2, 1.3);

    expect(metrics.totalO2ConsumedLiters).toBeGreaterThan(10);
    expect(metrics.totalMetabolicEnergyKcal).toBeGreaterThan(50);
    expect(metrics.peakHeartRateBpm).toBeGreaterThan(70);
    expect(metrics.safeReturnMarginMinutes).toBeGreaterThan(0);
    expect(metrics.pointOfNoReturnWpIndex).toBeGreaterThanOrEqual(0);
    expect(metrics.pointOfNoReturnWpIndex).toBeLessThanOrEqual(profile.length - 1);
  });

  it('getLiveAstronautBioState should return consistent bio, suit, and survival states', () => {
    const state = getLiveAstronautBioState(60, 5, 'traverse');

    expect(state.bio.heartRateBpm).toBeGreaterThan(60);
    expect(state.bio.vo2LitersPerMin).toBeGreaterThan(0);
    expect(state.suit.o2TankPressureBar).toBeGreaterThan(0);
    expect(state.suit.o2TankPressureBar).toBeLessThanOrEqual(200);
    expect(state.suit.batteryChargePercent).toBeGreaterThan(0);
    expect(state.suit.batteryChargePercent).toBeLessThanOrEqual(100);
    expect(['GO_NOMINAL', 'CAUTION_MARGINAL', 'ABORT_HAZARDOUS']).toContain(state.survival.evaStatus);
  });
});

// ── Meteorological Stream & EVA Hazard Tests ─────────────────────────────────

describe('evaWeatherHazard (Planetary Meteorology Integration)', () => {
  it('nominal conditions should yield GO EVA safety rating', () => {
    const advisory = computeEVAMeteorologicalAdvisory({
      sol: 500,
      temperatureK: 220,
      dustOpticalDepth: 0.45,
      windSpeedMs: 5.5,
    });
    expect(advisory.evaSafetyRating).toBe('GO');
    expect(advisory.visibilityRangeMeters).toBeGreaterThan(5000);
    expect(advisory.stormRisk).toBe('low');
  });

  it('severe dust storms (tau >= 2.5) should yield NO_GO safety rating', () => {
    const advisory = computeEVAMeteorologicalAdvisory({
      sol: 750,
      dustOpticalDepth: 3.2,
    });
    expect(advisory.evaSafetyRating).toBe('NO_GO');
    expect(advisory.stormRisk).toBe('severe');
    expect(advisory.visibilityRangeMeters).toBeLessThan(1000);
    expect(advisory.recommendations.some(r => r.includes('NO-GO'))).toBe(true);
  });

  it('extreme wind velocities (>22 m/s) should yield NO_GO rating', () => {
    const advisory = computeEVAMeteorologicalAdvisory({
      windSpeedMs: 25.0,
    });
    expect(advisory.evaSafetyRating).toBe('NO_GO');
  });

  it('Koschmieder visibility should decrease monotonically with higher optical depth', () => {
    const clear = computeEVAMeteorologicalAdvisory({ dustOpticalDepth: 0.3 });
    const dusty = computeEVAMeteorologicalAdvisory({ dustOpticalDepth: 1.8 });
    expect(clear.visibilityRangeMeters).toBeGreaterThan(dusty.visibilityRangeMeters);
  });
});

// ── Mars 2020 Outcrop & Sample Caching Tests ──────────────────────────────────

describe('Mars 2020 & Curiosity Geological Outcrops', () => {
  it('MARS_2020_OUTCROPS should contain valid outcrops with open data sources', () => {
    expect(MARS_2020_OUTCROPS.length).toBeGreaterThanOrEqual(5);

    for (const outcrop of MARS_2020_OUTCROPS) {
      expect(outcrop.name).toBeDefined();
      expect(outcrop.coordinates.lat).toBeGreaterThanOrEqual(-90);
      expect(outcrop.coordinates.lat).toBeLessThanOrEqual(90);
      expect(outcrop.mineralogy.length).toBeGreaterThan(0);
      expect(outcrop.images.length).toBeGreaterThan(0);
      expect(outcrop.openDataSources.marsTrekUrl).toContain('trek.nasa.gov');
      expect(outcrop.openDataSources.rawImageFeedUrl).toContain('nasa.gov');

      if (outcrop.sampleTube) {
        expect(['empty', 'abraded', 'cored_sealed', 'depot_cached']).toContain(outcrop.sampleTube.status);
      }
    }
  });

  it('ASTRONAUT_EVA_WEIGHTS should prioritize slope safety and hazard avoidance', () => {
    expect(ASTRONAUT_EVA_WEIGHTS.slope).toBeGreaterThan(DEFAULT_WEIGHTS.slope);
    expect(ASTRONAUT_EVA_WEIGHTS.hazard).toBeGreaterThan(DEFAULT_WEIGHTS.hazard);

    const grid = generateTerrainGrid(19, 17, 79, 76, 16);
    const path = aStarPath(grid, 0, 0, 15, 15, ASTRONAUT_EVA_WEIGHTS, 25);
    const route = buildRoute('eva-test', 'Astronaut EVA Route', 'astronaut-eva', path, grid, ASTRONAUT_EVA_WEIGHTS);

    expect(route.type).toBe('astronaut-eva');
    expect(route.evaMetrics).toBeDefined();
    expect(route.evaMetrics!.totalO2ConsumedLiters).toBeGreaterThan(0);
    expect(route.evaMetrics!.totalMetabolicEnergyKcal).toBeGreaterThan(0);
  });
});
