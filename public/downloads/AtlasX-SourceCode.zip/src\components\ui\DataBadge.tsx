import React from 'react';
import type { DataClassification } from '../../types';

const CLASS_CONFIG: Record<DataClassification, { label: string; classes: string; dot: string }> = {
  observed:    { label: 'OBSERVED',    classes: 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/20', dot: 'bg-emerald-400' },
  derived:     { label: 'DERIVED',     classes: 'bg-blue-500/15 text-blue-400 border border-blue-500/20',         dot: 'bg-blue-400' },
  modelled:    { label: 'MODELLED',    classes: 'bg-amber-500/15 text-amber-400 border border-amber-500/20',       dot: 'bg-amber-400' },
  simulated:   { label: 'SIMULATED',   classes: 'bg-orange-500/15 text-orange-400 border border-orange-500/20',   dot: 'bg-orange-400' },
  unavailable: { label: 'UNAVAILABLE', classes: 'bg-slate-500/15 text-slate-400 border border-slate-500/20',     dot: 'bg-slate-500' },
};

interface Props {
  classification: DataClassification;
  className?: string;
}

export default function DataBadge({ classification, className = '' }: Props) {
  const cfg = CLASS_CONFIG[classification] || CLASS_CONFIG.unavailable;
  return (
    <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-mono font-medium uppercase tracking-wide ${cfg.classes} ${className}`}>
      <span className={`w-1 h-1 rounded-full ${cfg.dot}`} />
      {cfg.label}
    </span>
  );
}
