# Scientific Methods — AtlasX

> **⚠ Methodology Transparency Notice**  
> This document describes the scientific and algorithmic methods used in AtlasX. All methods are clearly labelled by their classification (observed, derived, modelled, or simulated). No fabricated measurements are presented as real observations.

---

## 1. Solar Geometry Model

**File:** `src/utils/solarGeometry.ts`  
**Classification:** DERIVED (geometric calculation)

### Mars Orbital Parameters
- Semi-major axis: 1.524 AU
- Orbital eccentricity: **e = 0.0934** (significantly elliptical)
- Axial obliquity: **25.19°** (similar to Earth's 23.44°)
- Solar day (sol): **24 hours 37 minutes**
- Orbital period: **686.97 days** (~668.6 sols)

### Solar Irradiance
Mars receives varying solar flux due to its elliptical orbit:

```
F(L_s) = F_mean × (1 + e × cos(L_s - L_perihelion))²
```

Where:
- `F_mean = 586 W/m²` (at mean Mars-Sun distance)
- `e = 0.0934` (orbital eccentricity)
- `L_perihelion ≈ 251°` (perihelion solar longitude)

The irradiance at perihelion (~L_s = 251°) is approximately **718 W/m²**, and at aphelion (~L_s = 71°) approximately **492 W/m²** — a ~46% seasonal variation, much larger than Earth's ~7%.

### Declination and Illumination
Solar declination on Mars:
```
δ = arcsin(sin(ε) × sin(L_s))
```
Where ε = 25.19° (obliquity).

Daylight duration at latitude φ:
```
ω₀ = arccos(-tan(φ) × tan(δ))
daylight_hours = (2 × ω₀ / π) × (sol_length_hours / 2)
```

### Limitations
- **No terrain shadowing:** Slope and cliff shadows are not modelled
- **No atmospheric scattering:** Dust, aerosols, and Rayleigh scattering not included
- **No diffuse irradiance:** Only direct beam irradiance is estimated
- **Temporal resolution:** Daily average only; no diurnal cycle within a sol
- **Not calibrated against MEDA measurements**

---

## 2. Route Planning Algorithm

**File:** `src/utils/routePlanning.ts`  
**Classification:** SIMULATED (synthetic terrain grid)

### Terrain Grid Generation
A 32×32 synthetic terrain grid is generated for the selected bounding box using:
```
elevation = base_elevation
  + A₁ × sin(3πx) × cos(2πy)
  + A₂ × sin(7πx + 0.5) × sin(5πy + 1.2)
  + noise
```
where x, y ∈ [0, 1] are normalized grid coordinates. The grid is reproducible via a seeded pseudo-random number generator (LCG with seed = 42).

### Cost Function
Cell-to-cell movement cost:
```
cost(from → to) = w_dist × 1.0
               + w_slope × (slope_to / 35°)
               + w_hazard × hazard_penalty_to
               − w_science × science_bonus_to
```

**Weight sets:**

| Route Type | w_dist | w_slope | w_hazard | w_science |
|-----------|--------|---------|----------|-----------|
| Shortest | 1.0 | 1.0 | 1.0 | 0.5 |
| Lower Risk | 0.6 | 2.5 | 3.0 | 0.2 |
| Science Priority | 0.8 | 0.8 | 0.8 | 2.5 |

All weights are dimensionless; slopes normalized to [0, 1] by dividing by 35°.

### A* Search
Standard A* with:
- **8-connectivity:** diagonal moves allowed (cost multiplied by √2)
- **Heuristic:** Euclidean distance in grid coordinates
- **Max iterations:** 10,000 (prevents infinite loops on impossible paths)
- **Slope cutoff:** Cells with slope > `maxSlope` parameter are impassable
- **Fallback:** Straight-line path returned if no valid path found

### Travel Time Estimation
```
time = distance_km / speed_km_h
```
where `speed_km_h = 3.5 km/h` (conservative EVA suit walking speed).

### Limitations
- Terrain is synthetic, not derived from real elevation data
- No global path optimality guarantee with 10,000 iteration cap
- Slope cutoff is a hard constraint; real terrain permits cautious traversal of steeper areas
- No consideration of EVA suit consumables, fatigue, or communication blackouts
- No multi-day traverse planning with overnight camps

---

## 3. Suitability Scoring

**File:** `src/data/sampleData.ts`  
**Classification:** SIMULATED

Suitability scores are synthetic values assigned to demonstrate the comparison interface. They are **not** computed from actual terrain data.

### Score Components (0–100)
Each score component is independently assessed and not combined via a weighted formula in the current demonstration. Real assessments would require:

| Component | Real Data Required |
|-----------|-------------------|
| Slope score | HiRISE stereo DTM, <5 m/px |
| Roughness score | Thermal inertia from THEMIS/TES |
| Elevation score | MOLA elevation + atmospheric model |
| Hazard score | Rock abundance from orbital thermal data |
| Data coverage | HiRISE image footprint database |

### Landing vs. Ascent
These are treated as separate engineering problems because:
- **Landing:** Minimize slope and roughness for touchdown stability; maximize atmospheric braking efficiency (lower elevation preferred)
- **Ascent (MAV):** Maximize elevation for less dense atmosphere to push through; flat clear terrain for launch plume; upwind direction matters

---

## 4. Atmospheric Data Model

**File:** `src/data/sampleData.ts`  
**Classification:** SIMULATED

The synthetic seasonal pattern is based on published annual averages from:
- Haberle et al. (2014), Forget et al. (2008) — General circulation model results
- MEDA preliminary results (Rodriguez-Manfredi et al. 2021)

Formula for temperature:
```
T(sol) = T_mean + A_seasonal × sin(L_s) + noise
```
where T_mean ≈ 210 K, A_seasonal ≈ 15 K.

**This is NOT actual MEDA data.** Real MEDA data requires PDS access.

---

## 5. Coordinate Conventions

**File:** `src/utils/marsCoordinates.ts`

Mars uses **planetocentric coordinates**:
- Latitude: −90° (south pole) to +90° (north pole)
- Longitude: 0° to 360° positive east (IAU 2000 convention)
- Vertical datum: MOLA areoid (gravitational equipotential)

Great circle distance uses the Haversine formula with **R_Mars = 3,389.5 km**.

Note: Mars has no magnetic poles, so "north" refers to the geographic (rotation axis) north pole.

---

## 6. Astronaut Physiological & EVA Survival Model

**File:** `src/utils/evaBiometrics.ts`  
**Classification:** MODELLED (calibrated against human planetary locomotion & NASA EVA physiological literature)

### Reduced Gravity Locomotion ($g = 3.721\text{ m/s}^2$, $0.379g$)
Human suited walking on Mars requires moving both the astronaut body mass ($M_a \approx 80\text{ kg}$) and the Exploration Extravehicular Mobility Unit (xEMU, $M_s \approx 120\text{ kg}$), totalling $200\text{ kg}$. Under Martian gravity, ground reaction forces scale down by $\gamma = \frac{g_{Mars}}{g_{Earth}} \approx 0.379$, but suit joint pressurization stiffness ($W_{joint} \approx 42\text{ W}$) and regolith surface impedance require non-linear energy expenditure.

### Pandolf-Margaria Martian Suited Work Rate
Metabolic rate $M$ (Watts):
```
M = η × [ 1.5·M_tot·γ + 2.0·(M_a + M_s)·γ·(M_s / M_a)²·0.08 + M_tot·γ·(1.5·v² + 0.35·v·G·100) ] + W_joint
```
Where:
- $\eta$: Terrain roughness coefficient ($1.1$ bedrock, $1.4$ compact regolith, $1.9$ loose sand dunes, $2.2$ boulder scree)
- $v$: Walking velocity in $\text{m/s}$ (typically $0.8 - 1.1\text{ m/s}$)
- $G$: Slope gradient rise/run ($\tan \theta$)
- $W_{joint}$: Constant pressurized joint resistance ($\approx 42\text{ W}$)

### Gas Exchange & Consumables Depletion
- **Oxygen Consumption ($VO_2$):** Based on the metabolic caloric equivalent of $20,100\text{ J}$ per liter of $O_2$:
  $$VO_2 (\text{L/min}) = \frac{M (\text{Watts}) \times 60 \text{ s/min}}{20,100 \text{ J/L}} \approx \frac{M}{335}$$
- **Carbon Dioxide Production ($VCO_2$):** Calibrated with diet respiratory quotient $RQ = 0.85$:
  $$VCO_2 = 0.85 \times VO_2$$
- **Primary Consumable Capacity:** $1.2\text{ kg}$ usable $O_2$ ($\approx 840\text{ L}$ STP), with an inviolable $30\text{-minute}$ emergency secondary reserve.

### Curiosity/Perseverance Regolith Slip Model
Curiosity and Perseverance traverse telemetry demonstrated that dry Martian drift sand undergoes acute shear failure at slopes $> 15^\circ$:
$$\text{SlipRisk} = \begin{cases}
2 + \text{roughness} \times 2 & |\theta| < 4^\circ \\
5 + (|\theta| - 4) \times 1.5 & 4^\circ \le |\theta| < 10^\circ \\
14 + (|\theta| - 10) \times 2.5 & 10^\circ \le |\theta| < 15^\circ \\
26.5 + (|\theta| - 15)^{1.6} \times 4.5 & 15^\circ \le |\theta| < 20^\circ \\
\min(95, 45 + (|\theta| - 20)^{1.8} \times 8.0) & |\theta| \ge 20^\circ
\end{cases}$$

### Point of No Return (PNR) Calculation
For an outbound path segment $0 \dots k$, the PNR algorithm solves for the maximal waypoint $k$ where:
$$\text{Outbound } O_2(0 \dots k) + \text{Return } O_2(k \dots 0) \le \text{Usable Primary } O_2 - \text{Buffer}(30\text{ min})$$
Accounting for inverted elevation slopes on return (uphill becomes downhill, downhill becomes uphill).

---

## 7. Meteorological Stream & EVA Hazard Advisory Engine

**File:** `src/utils/evaWeatherHazard.ts`  
**Classification:** MODELLED (derived from NASA MEDA & InSight APSS observations)

### Koschmieder Optical Visibility
Visibility range $V$ (meters) derived from atmospheric dust optical depth $\tau$:
$$V = \max\left(100, \min\left(25,000, \frac{4,000}{\tau^{1.85}}\right)\right)$$
- Ambient clear ($\tau \approx 0.35$): $V \approx 20 - 25\text{ km}$
- Elevated dust ($\tau \approx 1.2$): $V \approx 2.8\text{ km}$
- Dust storm ($\tau \ge 2.5$): $V < 800\text{ m}$ (NO-GO)

### Dynamic EVA Go / Caution / No-Go Thresholds
- **NO-GO Conditions:** Dust storm $\tau \ge 2.5$, wind speed $\ge 22\text{ m/s}$ (sand saltation limit), or ambient cryogenic temperature $< 175\text{ K}$.
- **CAUTION Conditions:** $\tau \ge 1.2$, wind $\ge 13\text{ m/s}$, or temperature $< 190\text{ K}$ (triggers $+25\%$ thermal suit heater battery load).
- **GO Conditions:** Nominal Martian environment; standard PNR 30-min buffer maintained.

---

## References

- Haberle, R.M. et al. (2014). *The atmosphere and climate of Mars*. Cambridge University Press.
- Rodriguez-Manfredi, J.A. et al. (2021). *The Mars Environmental Dynamics Analyzer, MEDA.* Space Science Reviews, 217(3), 48.
- Zuber, M.T. et al. (2000). *Internal structure and early thermal evolution of Mars from Mars Global Surveyor topography and gravity.* Science, 287(5459), 1788–1793.
- Fergason, R.L. et al. (2006). *High-resolution thermal inertia derived from THEMIS.* JGR Planets, 111(E12).
