/**
 * prepare-electron.mjs
 *
 * Post-build script that:
 *  1. Copies dist/ → app/  (Electron reads the Vite bundle from app/)
 *  2. Patches index.html to use relative paths (file:// compatible)
 *  3. Copies the electron/ directory so electron-builder picks it up
 *
 * Run after: npm run build
 */

import { cpSync, readFileSync, writeFileSync, mkdirSync, rmSync, existsSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const ROOT = join(__dirname, '..');

const SRC  = join(ROOT, 'dist');
const DEST = join(ROOT, 'app');

// ── 1. Clean and copy dist → app ────────────────────────────────────────────
console.log('→ Copying dist/ → app/');
if (existsSync(DEST)) rmSync(DEST, { recursive: true, force: true });
mkdirSync(DEST, { recursive: true });
cpSync(SRC, DEST, { recursive: true });

// ── 2. Patch index.html ──────────────────────────────────────────────────────
// Vite produces absolute paths (/assets/...) which fail under file://
// Switch to relative paths (./assets/...) so it works in both contexts.
const indexPath = join(DEST, 'index.html');
let html = readFileSync(indexPath, 'utf-8');

// Replace src="/assets/ and href="/assets/ with relative paths
html = html.replace(/(src|href)="\/assets\//g, '$1="./assets/');
// Also handle root-relative references
html = html.replace(/(src|href)="\//g, '$1="./');

writeFileSync(indexPath, html, 'utf-8');
console.log('→ Patched index.html for file:// compatibility');

// ── 3. Copy electron icon to app/ for the window ────────────────────────────
const iconSrc = join(ROOT, 'build-resources', 'icon.ico');
const iconDst = join(ROOT, 'electron', 'icon.ico');
if (existsSync(iconSrc) && !existsSync(iconDst)) {
  cpSync(iconSrc, iconDst);
  console.log('→ Copied icon.ico to electron/');
}

console.log('✓ Electron build preparation complete.');
console.log('  Next: npm run electron:dist  (to create the installer)');
