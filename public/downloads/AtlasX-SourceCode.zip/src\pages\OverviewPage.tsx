import React from 'react';
import {
  Map,
  Route,
  FlaskConical,
  AlertTriangle,
  Layers,
  Globe,
  Rocket,
  BookOpen,
  Clock,
  Sun,
  Compass,
  RotateCcw,
  Heart,
  Camera,
  ExternalLink,
  ShieldCheck,
  Info,
} from 'lucide-react';
import { useAppStore } from '../store/useAppStore';
import { useRealTimeMarsClock } from '../utils/marsTime';
import { useMarsEphemeris, useBackendStatus } from '../services/hooks';
import GlassPanel from '../components/ui/GlassPanel';
import StatCard from '../components/ui/StatCard';
import DataBadge from '../components/ui/DataBadge';

// ── Helpers ──────────────────────────────────────────────────────────────────

/** Format a decimal lat/lon pair as a readable string. */
function formatCoords(lat: number, lon: number): string {
  const ns = lat >= 0 ? 'N' : 'S';
  const ew = lon >= 0 ? 'E' : 'W';
  return `${Math.abs(lat).toFixed(2)}° ${ns}, ${Math.abs(lon).toFixed(2)}° ${ew}`;
}

/** Map scientific-interest level to a Tailwind colour token. */
const interestColor: Record<string, string> = {
  'very-high': 'text-red-400',
  high: 'text-amber-400',
  medium: 'text-yellow-400',
  low: 'text-emerald-400',
};

/** Severity → colour for hazard badges. */
const severityColor: Record<string, string> = {
  extreme: 'text-red-400',
  high: 'text-orange-400',
  moderate: 'text-amber-400',
  low: 'text-yellow-300',
  none: 'text-emerald-400',
};

// ── Terrain Preview ──────────────────────────────────────────────────────────

/** Simple elevation gradient mock — clearly labelled. */
const TerrainPreview: React.FC = () => (
  <div className="relative w-full h-28 rounded-lg overflow-hidden">
    {/* gradient representing elevation low→high */}
    <div className="absolute inset-0 bg-gradient-to-r from-[#313695] via-[#74add1] via-[#ffffbf] via-[#f46d43] to-[#a50026]" />
    {/* subtle topographic grid overlay */}
    <div
      className="absolute inset-0 opacity-20"
      style={{
        backgroundImage:
          'repeating-linear-gradient(0deg,transparent,transparent 19px,rgba(255,255,255,.15) 20px),repeating-linear-gradient(90deg,transparent,transparent 19px,rgba(255,255,255,.15) 20px)',
      }}
    />
    {/* label */}
    <div className="absolute inset-0 flex flex-col items-center justify-center gap-1">
      <span className="text-[10px] font-mono font-semibold text-white/80 tracking-widest uppercase">
        Terrain Elevation Preview
      </span>
      <span className="text-[9px] font-mono text-white/60">(MOLA gradient — illustrative)</span>
    </div>
    {/* legend ticks */}
    <div className="absolute bottom-1 left-2 right-2 flex justify-between">
      {['Low', '-1 km', '0', '+1 km', 'High'].map((l) => (
        <span key={l} className="text-[8px] font-mono text-white/70">
          {l}
        </span>
      ))}
    </div>
  </div>
);

// ── Main Component ───────────────────────────────────────────────────────────

const OverviewPage: React.FC = () => {
  const {
    selectedRegion,
    routes,
    scienceTargets,
    hazards,
    layers,
    selectedDate,
    isLiveDate,
    syncToLive,
    setActivePage,
    theme,
  } = useAppStore();
  const isBright = theme === 'bright';

  const clock = useRealTimeMarsClock(
    selectedRegion.coordinates.lon,
    isLiveDate ? null : selectedDate,
    1000
  );
  const ephemeris = useMarsEphemeris(selectedDate);
  const { alive } = useBackendStatus();

  const activeLayers = layers.filter((l) => l.visible);
  const highHazards = hazards.filter((h) => h.severity === 'high' || h.severity === 'extreme');

  return (
    <div className="h-full overflow-y-auto overflow-x-hidden flex flex-col gap-4 sm:gap-5 p-3 sm:p-5 w-full">

      {/* ── Page Header ── */}
      <div className="flex flex-col gap-1 w-full">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 w-full">
          <div className="flex items-center gap-3 min-w-0">
            <Globe className={`w-6 h-6 flex-shrink-0 ${isBright ? 'text-amber-600' : 'text-amber-400'}`} />
            <div className="min-w-0">
              <h1 className={`text-lg sm:text-xl font-bold leading-tight truncate ${isBright ? 'text-slate-900' : 'text-white'}`}>
                {selectedRegion.name}
              </h1>
              <p className={`text-xs font-mono ${isBright ? 'text-slate-600 font-medium' : 'text-slate-400'}`}>
                {formatCoords(selectedRegion.coordinates.lat, selectedRegion.coordinates.lon)}
              </p>
            </div>
          </div>
          <div className="flex items-center flex-wrap gap-2">
            {isLiveDate ? (
              <span className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-mono font-semibold ${
                isBright
                  ? 'bg-emerald-100 border border-emerald-300 text-emerald-800'
                  : 'bg-emerald-500/15 border border-emerald-500/30 text-emerald-300'
              }`}>
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                LIVE REAL-TIME
              </span>
            ) : (
              <button
                onClick={syncToLive}
                className={`flex items-center gap-1 px-2.5 py-1 rounded text-xs font-mono transition-colors font-semibold ${
                  isBright
                    ? 'bg-amber-100 border border-amber-300 text-amber-800 hover:bg-amber-200'
                    : 'bg-amber-500/20 border border-amber-500/35 text-amber-300 hover:bg-amber-500/30'
                }`}
              >
                <RotateCcw size={12} />
                SYNC TO LIVE CLOCK
              </button>
            )}
            <DataBadge classification={alive ? 'observed' : 'derived'} />
            <span className={`text-[11px] font-mono border rounded px-2 py-0.5 ${
              isBright ? 'text-slate-700 border-slate-300 bg-slate-100 font-medium' : 'text-slate-300 border-white/10 bg-black/40'
            }`}>
              {clock.utcDate}
            </span>
          </div>
        </div>

        {/* Region description */}
        <p className={`text-xs leading-relaxed max-w-4xl mt-1 ${isBright ? 'text-slate-700 font-normal' : 'text-slate-300'}`}>
          {selectedRegion.description}
        </p>
      </div>

      {/* ── Real-Time Mission Telemetry HUD ── */}
      <GlassPanel
        title="Astronomical Telemetry & Planetary Clocks"
        badge={
          <span className={`text-[10px] font-mono ${isBright ? 'text-cyan-800 font-semibold' : 'text-cyan-300'}`}>
            {alive ? 'Observed Ephemeris: JPL Horizons DE441' : 'Astronomical Model: GISS Mars24 Algorithm'}
          </span>
        }
      >
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3 sm:gap-4 py-1 text-xs">
          {/* Earth UTC */}
          <div className={`flex flex-col gap-1 p-2.5 rounded-lg border min-w-0 ${
            isBright ? 'bg-slate-50 border-slate-200' : 'bg-white/5 border-white/5'
          }`}>
            <span className={`text-[10px] uppercase font-mono flex items-center gap-1.5 ${isBright ? 'text-slate-600 font-semibold' : 'text-slate-400 font-medium'}`}>
              <Clock className={`w-3.5 h-3.5 flex-shrink-0 ${isBright ? 'text-blue-600' : 'text-blue-400'}`} /> Earth UTC
            </span>
            <span className={`font-mono text-base font-bold truncate ${isBright ? 'text-slate-900' : 'text-white'}`}>{clock.utcTime}</span>
            <span className={`text-[11px] font-mono truncate ${isBright ? 'text-slate-600 font-medium' : 'text-slate-400'}`}>{clock.utcDate}</span>
          </div>

          {/* Mars Sol & MTC */}
          <div className={`flex flex-col gap-1 p-2.5 rounded-lg border min-w-0 ${
            isBright ? 'bg-slate-50 border-slate-200' : 'bg-white/5 border-white/5'
          }`}>
            <span className={`text-[10px] uppercase font-mono flex items-center gap-1.5 ${isBright ? 'text-slate-600 font-semibold' : 'text-slate-400 font-medium'}`}>
              <Compass className={`w-3.5 h-3.5 flex-shrink-0 ${isBright ? 'text-orange-600' : 'text-orange-400'}`} /> Mars Sol &amp; MTC
            </span>
            <span className={`font-mono text-base font-bold truncate ${isBright ? 'text-orange-700' : 'text-orange-400'}`}>{clock.mtcFormatted}</span>
            <span className={`text-[11px] font-mono truncate ${isBright ? 'text-slate-600 font-medium' : 'text-slate-400'}`}>{clock.msdFormatted}</span>
          </div>

          {/* Local Solar Time */}
          <div className={`flex flex-col gap-1 p-2.5 rounded-lg border min-w-0 ${
            isBright ? 'bg-slate-50 border-slate-200' : 'bg-white/5 border-white/5'
          }`}>
            <span className={`text-[10px] uppercase font-mono flex items-center gap-1.5 ${isBright ? 'text-slate-600 font-semibold' : 'text-slate-400 font-medium'}`}>
              <Sun className={`w-3.5 h-3.5 flex-shrink-0 ${isBright ? 'text-amber-600' : 'text-amber-400'}`} /> Local Solar Time
            </span>
            <span className={`font-mono text-base font-bold truncate ${isBright ? 'text-amber-700' : 'text-amber-300'}`}>{clock.lmstFormatted}</span>
            <span className={`text-[11px] font-mono truncate ${isBright ? 'text-slate-600 font-medium' : 'text-slate-400'}`}>
              {selectedRegion.name} (Lon {selectedRegion.coordinates.lon.toFixed(1)}°E)
            </span>
          </div>

          {/* Heliocentric State */}
          <div className={`flex flex-col gap-1 p-2.5 rounded-lg border min-w-0 ${
            isBright ? 'bg-slate-50 border-slate-200' : 'bg-white/5 border-white/5'
          }`}>
            <span className={`text-[10px] uppercase font-mono flex items-center gap-1.5 ${isBright ? 'text-slate-600 font-semibold' : 'text-slate-400 font-medium'}`}>
              <Sun className={`w-3.5 h-3.5 flex-shrink-0 ${isBright ? 'text-amber-600' : 'text-yellow-400'}`} /> Orbit &amp; Solar Flux
            </span>
            <span className={`font-mono text-sm sm:text-base font-bold truncate ${isBright ? 'text-cyan-800' : 'text-cyan-300'}`}>
              {clock.distanceAu.toFixed(3)} AU · {clock.irradianceWm2.toFixed(1)} W/m²
            </span>
            <span className={`text-[11px] font-mono truncate ${isBright ? 'text-slate-600 font-medium' : 'text-slate-400'}`}>
              {clock.marsYearFormatted} · {clock.lsFormatted} ({clock.season.split('/')[0].trim()})
            </span>
          </div>
        </div>
      </GlassPanel>

      {/* ── Stat Cards Grid ──────────────────────────────────────────────── */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-3 w-full">
        <StatCard
          label="Saved Routes"
          value={routes.length}
          icon={<Route className="w-4 h-4" />}
          classification="simulated"
          trend="neutral"
        />
        <StatCard
          label="Science Targets"
          value={scienceTargets.length}
          icon={<FlaskConical className="w-4 h-4" />}
          classification="simulated"
          trend="neutral"
        />
        <StatCard
          label="Mapped Hazards"
          value={hazards.length}
          icon={<AlertTriangle className="w-4 h-4" />}
          classification="simulated"
          trend={highHazards.length > 0 ? 'down' : 'neutral'}
        />
        <StatCard
          label="Active Layers"
          value={activeLayers.length}
          unit={`/ ${layers.length}`}
          icon={<Layers className="w-4 h-4" />}
          classification="simulated"
          trend="neutral"
        />
      </div>

      {/* ── Terrain Preview ──────────────────────────────────────────────── */}
      <GlassPanel title="Terrain Preview" badge={<DataBadge classification="simulated" />}>
        <TerrainPreview />
      </GlassPanel>

      {/* ── Open Planetary Architecture & 4-Stream Survival Hub ───────────── */}
      <GlassPanel
        title="Open Planetary Architecture & 4-Stream Survival Framework"
        badge={<span className="text-[10px] font-mono text-cyan-400">Open Data Pipelines (NASA / USGS)</span>}
      >
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3 sm:gap-4 w-full">
          {/* Topographical Stream */}
          <div className={`p-3.5 rounded-lg border flex flex-col justify-between gap-2.5 min-w-0 ${
            isBright ? 'bg-slate-50 border-slate-200' : 'bg-white/5 border-white/5'
          }`}>
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <span className="flex items-center gap-1.5 font-bold text-xs text-cyan-500">
                  <Map size={14} className="flex-shrink-0" /> Topographical
                </span>
                <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-cyan-500/15 text-cyan-300 font-semibold">
                  GIS / WMTS
                </span>
              </div>
              <p className={`text-[11px] leading-relaxed ${isBright ? 'text-slate-700' : 'text-slate-300'}`}>
                Global tile pipelines via <strong>NASA Mars Trek</strong> &amp; <strong>USGS Astrogeology</strong> (MOLA elevation 463m/px &amp; Viking color mosaic 232m/px).
              </p>
            </div>
            <a
              href="https://trek.nasa.gov/mars/"
              target="_blank"
              rel="noreferrer"
              className="text-[10px] font-mono text-cyan-500 hover:text-cyan-600 flex items-center gap-1 hover:underline mt-1 font-semibold"
            >
              Data source: NASA Mars Trek <ExternalLink size={10} />
            </a>
          </div>

          {/* Geological Stream */}
          <div className={`p-3.5 rounded-lg border flex flex-col justify-between gap-2.5 min-w-0 ${
            isBright ? 'bg-slate-50 border-slate-200' : 'bg-white/5 border-white/5'
          }`}>
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <span className="flex items-center gap-1.5 font-bold text-xs text-purple-400">
                  <Camera size={14} className="flex-shrink-0" /> Geological &amp; Outcrops
                </span>
                <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-purple-500/15 text-purple-300 font-semibold">
                  Mars 2020 Raw
                </span>
              </div>
              <p className={`text-[11px] leading-relaxed ${isBright ? 'text-slate-700' : 'text-slate-300'}`}>
                Multispectral Mastcam-Z, SuperCam LIBS, and sample caching derived from <strong>Perseverance</strong> and <strong>Curiosity</strong> rover traverses.
              </p>
            </div>
            <a
              href="https://mars.nasa.gov/mars2020/multimedia/raw-images/"
              target="_blank"
              rel="noreferrer"
              className="text-[10px] font-mono text-purple-400 hover:text-purple-500 flex items-center gap-1 hover:underline mt-1 font-semibold"
            >
              Feeds: Mars 2020 Raw Archive <ExternalLink size={10} />
            </a>
          </div>

          {/* Physiological Stream */}
          <div className={`p-3.5 rounded-lg border flex flex-col justify-between gap-2.5 min-w-0 ${
            isBright ? 'bg-slate-50 border-slate-200' : 'bg-white/5 border-white/5'
          }`}>
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <span className="flex items-center gap-1.5 font-bold text-xs text-amber-500">
                  <Heart size={14} className="flex-shrink-0" /> Physiological
                </span>
                <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-300 font-semibold">
                  0.38g Biometrics
                </span>
              </div>
              <p className={`text-[11px] leading-relaxed ${isBright ? 'text-slate-700' : 'text-slate-300'}`}>
                Pandolf-Margaria Martian suited walking model (200 kg mass), VO2 oxygen depletion rate, and mandatory Point of No Return (PNR) margin.
              </p>
            </div>
            <span className="text-[10px] font-mono text-amber-500 font-bold">
              30-min Emergency Buffer
            </span>
          </div>

          {/* Meteorological Stream */}
          <div className={`p-3.5 rounded-lg border flex flex-col justify-between gap-2.5 min-w-0 ${
            isBright ? 'bg-slate-50 border-slate-200' : 'bg-white/5 border-white/5'
          }`}>
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <span className="flex items-center gap-1.5 font-bold text-xs text-emerald-500">
                  <ShieldCheck size={14} className="flex-shrink-0" /> Meteorological
                </span>
                <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-emerald-500/15 text-emerald-300 font-semibold">
                  MEDA / InSight
                </span>
              </div>
              <p className={`text-[11px] leading-relaxed ${isBright ? 'text-slate-700' : 'text-slate-300'}`}>
                Correlates dust optical depth (tau), diurnal cryogenic swings, and wind abrasion with real-time EVA Go / Caution / No-Go safety ratings.
              </p>
            </div>
            <a
              href="https://worldview.earthdata.nasa.gov/"
              target="_blank"
              rel="noreferrer"
              className="text-[10px] font-mono text-emerald-500 hover:text-emerald-600 flex items-center gap-1 hover:underline mt-1 font-semibold"
            >
              Framework: NASA Worldview <ExternalLink size={10} />
            </a>
          </div>
        </div>
      </GlassPanel>

      {/* ── Quick Actions ────────────────────────────────────────────────── */}
      <div className="flex flex-wrap gap-2 w-full">
        {(
          [
            { page: 'atlas', label: 'Open Atlas', icon: <Map className="w-4 h-4" /> },
            { page: 'routes', label: 'Plan Routes', icon: <Route className="w-4 h-4" /> },
            { page: 'science', label: 'Science Targets', icon: <FlaskConical className="w-4 h-4" /> },
            { page: 'catalogue', label: 'Data Catalogue', icon: <BookOpen className="w-4 h-4" /> },
            { page: 'missions', label: 'Missions', icon: <Rocket className="w-4 h-4" /> },
          ] as const
        ).map(({ page, label, icon }) => (
          <button
            key={page}
            onClick={() => setActivePage(page as Parameters<typeof setActivePage>[0])}
            className={`flex-1 min-w-[120px] sm:flex-initial flex items-center justify-center gap-2 px-3.5 py-2 rounded-lg border transition-all text-xs sm:text-sm font-semibold ${
              isBright
                ? 'bg-white border-slate-300 text-slate-800 hover:bg-slate-100 hover:border-amber-500/50 shadow-sm'
                : 'bg-white/5 border-white/10 hover:bg-white/10 hover:border-amber-400/40 text-slate-200'
            }`}
          >
            <span className={isBright ? 'text-amber-600' : 'text-amber-400'}>{icon}</span>
            <span>{label}</span>
          </button>
        ))}
      </div>

      {/* ── Three-panel row ──────────────────────────────────────────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 sm:gap-4 w-full">

        {/* Current Data Status */}
        <GlassPanel title="Current Data Status">
          <div className="flex flex-col gap-2.5 text-xs">
            <div className="flex items-center justify-between">
              <span className={isBright ? 'text-slate-600 font-medium' : 'text-slate-400'}>Observation Date</span>
              <span className={`font-mono font-semibold ${isBright ? 'text-slate-900' : 'text-white'}`}>
                {clock.utcDate} {isLiveDate ? <span className={`${isBright ? 'text-emerald-700' : 'text-emerald-400'} text-[10px] ml-1 font-bold`}>(Live)</span> : <span className={`${isBright ? 'text-amber-700' : 'text-amber-400'} text-[10px] ml-1 font-bold`}>(Custom)</span>}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className={isBright ? 'text-slate-600 font-medium' : 'text-slate-400'}>Orbital Ephemeris</span>
              <DataBadge classification={alive ? 'observed' : 'derived'} />
            </div>
            <div className="flex items-center justify-between">
              <span className={isBright ? 'text-slate-600 font-medium' : 'text-slate-400'}>Mars Year &amp; Season</span>
              <span className={`font-mono font-bold ${isBright ? 'text-cyan-800' : 'text-cyan-300'}`}>
                {clock.marsYearFormatted} · {clock.lsFormatted}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className={isBright ? 'text-slate-600 font-medium' : 'text-slate-400'}>Region Interest</span>
              <span
                className={`font-semibold capitalize ${interestColor[selectedRegion.scientificInterest] ?? (isBright ? 'text-slate-900' : 'text-white')}`}
              >
                {selectedRegion.scientificInterest}
              </span>
            </div>
            {selectedRegion.area != null && (
              <div className="flex items-center justify-between">
                <span className={isBright ? 'text-slate-600 font-medium' : 'text-slate-400'}>Region Area</span>
                <span className={`font-mono font-semibold ${isBright ? 'text-slate-800' : 'text-slate-200'}`}>
                  {selectedRegion.area.toLocaleString()} km²
                </span>
              </div>
            )}
            {selectedRegion.geologyNote && (
              <p className={`mt-1 leading-relaxed border-t pt-2 ${
                isBright ? 'text-slate-700 border-slate-200 font-normal' : 'text-slate-300 border-white/10'
              }`}>
                {selectedRegion.geologyNote}
              </p>
            )}
          </div>
        </GlassPanel>

        {/* Active Layers mini list */}
        <GlassPanel title="Active Layers" badge={
          <span className={`text-[10px] font-mono ${isBright ? 'text-slate-600 font-semibold' : 'text-slate-400'}`}>
            {activeLayers.length} / {layers.length}
          </span>
        }>
          <div className="flex flex-col gap-2">
            {layers.map((layer) => (
              <div key={layer.id} className="flex items-center gap-2 text-xs">
                <span
                  className={`w-2 h-2 rounded-full flex-shrink-0 ${layer.visible ? (isBright ? 'bg-orange-600' : 'bg-amber-400') : (isBright ? 'bg-slate-300' : 'bg-white/20')}`}
                />
                <span className={`truncate ${layer.visible ? (isBright ? 'text-slate-900 font-semibold' : 'text-slate-200 font-medium') : (isBright ? 'text-slate-500' : 'text-slate-500')}`}>
                  {layer.name}
                </span>
                {layer.visible && (
                  <DataBadge classification={layer.classification} className="ml-auto" />
                )}
              </div>
            ))}
            {layers.length === 0 && (
              <p className={`text-xs ${isBright ? 'text-slate-500' : 'text-slate-500'}`}>No layers configured.</p>
            )}
          </div>
        </GlassPanel>

        {/* Hazard Overview */}
        <GlassPanel
          title="Hazard Overview"
          badge={highHazards.length > 0 ? (
            <span className="text-[10px] font-mono text-orange-600 border border-orange-400/40 bg-orange-100 rounded px-1.5 py-0.5 font-bold">
              {highHazards.length} HIGH
            </span>
          ) : undefined}
        >
          <div className="flex flex-col gap-2.5">
            {hazards.length === 0 ? (
              <p className={`text-xs ${isBright ? 'text-slate-500' : 'text-slate-400'}`}>No hazards mapped.</p>
            ) : (
              hazards.map((h) => (
                <div key={h.id} className="flex items-start gap-2 text-xs">
                  <AlertTriangle
                    className={`w-3.5 h-3.5 flex-shrink-0 mt-0.5 ${severityColor[h.severity] ?? (isBright ? 'text-slate-500' : 'text-slate-400')}`}
                  />
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className={`font-mono capitalize ${isBright ? 'text-slate-900 font-semibold' : 'text-slate-200 font-medium'}`}>
                        {h.type.replace('-', ' ')}
                      </span>
                      <span className={`capitalize font-bold ${severityColor[h.severity]}`}>
                        {h.severity}
                      </span>
                    </div>
                    <p className={`leading-snug line-clamp-2 ${isBright ? 'text-slate-700' : 'text-slate-300'}`}>{h.description}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </GlassPanel>
      </div>

      {/* ── Season / Date Display ── */}
      <GlassPanel>
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs w-full">
          <div className="flex flex-wrap items-center gap-3 sm:gap-4">
            <div className="flex items-center gap-1.5">
              <span className={`uppercase tracking-wider font-mono text-[11px] ${isBright ? 'text-slate-600 font-semibold' : 'text-slate-400'}`}>Earth UTC:</span>
              <span className={`font-mono font-bold ${isBright ? 'text-blue-700' : 'text-blue-300'}`}>{clock.utcDate} {clock.utcTime}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className={`uppercase tracking-wider font-mono text-[11px] ${isBright ? 'text-slate-600 font-semibold' : 'text-slate-400'}`}>Mars Time:</span>
              <span className={`font-mono font-bold ${isBright ? 'text-orange-700' : 'text-orange-400'}`}>{clock.msdFormatted} · {clock.mtcFormatted}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className={`uppercase tracking-wider font-mono text-[11px] ${isBright ? 'text-slate-600 font-semibold' : 'text-slate-400'}`}>Ephemeris:</span>
              <DataBadge classification={alive ? 'observed' : 'derived'} />
              <span className={`text-[10px] font-mono font-medium ${isBright ? 'text-slate-700' : 'text-slate-300'}`}>
                {alive ? 'JPL Horizons DE441' : 'NASA GISS Mars24 Ephemeris Model'}
              </span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className={`text-[10px] font-mono ${isBright ? 'text-slate-600 font-medium' : 'text-slate-400'}`}>
              AtlasX Platform v1.0.0
            </span>
          </div>
        </div>
      </GlassPanel>

      {/* ── Formal Affiliation & Legal Disclaimer Panel ── */}
      <div className={`p-3 sm:p-4 rounded-xl border text-center space-y-1.5 ${
        isBright ? 'bg-slate-100/90 border-slate-300' : 'bg-slate-900/60 border-white/10'
      }`}>
        <p className={`text-xs font-semibold ${isBright ? 'text-slate-900' : 'text-slate-200'}`}>
          AtlasX – An Advanced Planetary Exploration, Surface Intelligence and Mission Planning Platform.
        </p>
        <p className={`text-[10px] sm:text-[11px] leading-relaxed max-w-3xl mx-auto ${isBright ? 'text-slate-600' : 'text-slate-400'}`}>
          AtlasX is an independent educational and research project. It is not affiliated with, endorsed by, or officially associated with NASA or any other space agency.
        </p>
      </div>

    </div>
  );
};

export default OverviewPage;
