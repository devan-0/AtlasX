# Data Sources — AtlasX

## Classification Legend

| Badge | Meaning |
|-------|---------|
| **OBSERVED** | Actual instrument measurements from a real mission |
| **DERIVED** | Calculated from observed data (e.g., slope from elevation) |
| **MODELLED** | Output from a scientific model, not direct measurement |
| **SIMULATED** | Synthetic demonstration data — NOT real observations |
| **UNAVAILABLE** | Dataset identified but not yet accessible in this build |

---

## Integrated Datasets (Current Build)

### 1. OpenPlanetaryMap Basemap (REAL — Observed/Derived)
- **Instrument:** CTX (Context Camera), MRO
- **Source:** [OpenPlanetary](https://openplanetary.org) / [Murray Lab CTX](https://murray-lab.caltech.edu/CTX/)
- **Tile URL:** `https://cartocdn-gusc.global.ssl.fastly.net/opmbuilder/api/v1/map/named/opm-mars-basemap-v0-2/0/{z}/{x}/{y}.png`
- **Coverage:** ~95% of Mars surface
- **Resolution:** ~6 m/px  
- **Status:** ✅ Active tile layer in Interactive 2D Atlas

### 2. MOLA Elevation Model (Metadata only — integration path documented)
- **Instrument:** MOLA (Mars Orbiter Laser Altimeter), MGS
- **PDS URL:** https://pds-geosciences.wustl.edu/mgs/mgs-m-mola-5-megdr-l3-v1/mgsl_300x/meg004/
- **Resolution:** ~463 m/px global; 128 ppd gridded product
- **Integration:** Download `.img` files, convert with GDAL: `gdal_translate -of GTiff megt90n000fb.img mola_global.tif`

### 3. CRISM Mineral Observations (SIMULATED in current build)
- **Instrument:** CRISM (Compact Reconnaissance Imaging Spectrometer for Mars), MRO
- **PDS URL:** https://pds-geosciences.wustl.edu/mro/mro-m-crism-5-rdr-v1/mrocr_3xxx/
- **Resolution:** 18 m/px (FRT mode), 200 m/px (MTRDR global maps)
- **Integration pipeline:**
  ```
  1. Download FRT .img files from PDS
  2. Process with CRISM Analysis Tool (CAT) in ENVI/IDL
  3. Apply atmospheric and photometric correction
  4. Compute spectral parameters (e.g., BD1900, SINDEX2)
  5. Export as GeoTIFF → serve via TMS
  ```

### 4. HiRISE Imagery & DTMs (Metadata only)
- **Instrument:** HiRISE (High Resolution Imaging Science Experiment), MRO
- **URL:** https://www.uahirise.org/dtm/
- **Resolution:** 25 cm/px imagery, ~1 m/px DTM
- **Integration:** Download stereo pairs, process with ISIS3 + SOCET SET or ASP

### 5. MEDA Atmospheric Data (SIMULATED in current build)
- **Instrument:** MEDA (Mars Environmental Dynamics Analyzer), Perseverance
- **PDS URL:** https://pds.nasa.gov/datasearch/subscription-service/SS-20210218.shtml
- **Format:** CSV time series
- **Integration:** Direct CSV download and parse into AtmospherePage charts

### 6. InSight SEIS/APSS (Observed — metadata only)
- **Instruments:** SEIS, APSS (Temperature, Pressure, Wind)
- **PDS URL:** https://pds.nasa.gov (InSight mission archive)
- **Coverage:** Elysium Planitia, 2018–2022
- **Format:** PDS4 table files
- **Note:** Publicly archived; APSS meteorology files are CSV-accessible

---

## Accessing NASA PDS Data

The NASA Planetary Data System (PDS) provides free access to all NASA planetary mission data.

### Search interfaces:
- **PDS Geosciences Node:** https://pds-geosciences.wustl.edu/
- **PDS Imaging Node:** https://pds-imaging.jpl.nasa.gov/
- **ODE (Online Data Explorer):** https://ode.rsl.wustl.edu/mars/

### Programmatic access:
```python
import httpx

# Example: MOLA file listing
response = httpx.get(
    "https://pds-geosciences.wustl.edu/mgs/mgs-m-mola-5-megdr-l3-v1/mgsl_300x/meg004/",
    follow_redirects=True
)
```

---

## Backend Integration (FastAPI)

A FastAPI backend (see `backend/` directory — not yet scaffolded) would:

1. **Proxy PDS requests** to avoid CORS and rate limiting
2. **Process rasters** with GDAL/rasterio into tiled GeoTIFF
3. **Serve tile endpoints** (`/tiles/{dataset}/{z}/{x}/{y}.png`)
4. **Cache results** in SQLite or filesystem
5. **Validate data** with Pydantic models

```bash
# To start backend (when scaffolded):
cd backend
pip install fastapi httpx rasterio gdal pydantic
uvicorn main:app --reload --port 8000
```

---

## Open Planetary Architecture & 4-Stream Frameworks

AtlasX directly leverages open planetary data pipelines and frameworks derived from NASA and USGS standards:

### 1. NASA Mars Trek (WMTS & REST Global Tiling)
- **Portal:** [NASA Mars Trek](https://trek.nasa.gov/mars/)
- **Tile Pipeline:** Streamed directly from NASA Solar System Treks global tile cache (`https://trek.nasa.gov/tiles/Mars/EQ/...`).
- **Layers:**
  - Viking Color Mosaic MDIM 2.1 (~232 m/px)
  - MGS MOLA Shaded Relief & Color Topography (~463 m/px)
- **Tiling Standards:** EPSG:104905 IAU 2000 Mars Simple Cylindrical, pyramid zoom levels 0–7.

### 2. USGS Astrogeology Mars Interactive Maps (WMS Services)
- **Portal:** [USGS Astrogeology Mars Interactive Maps](https://astrogeology-usgs.hub.arcgis.com/pages/interactive-maps-mars)
- **Service Endpoint:** `https://planetarymaps.usgs.gov/cgi-bin/mapserv?map=/maps/mars/mars_simp_cyl.map`
- **Layers:**
  - `MOLA_THEMIS_blend`: MOLA digital terrain blended with Odyssey THEMIS daytime thermal IR (~100 m/px)
  - `MDIM21_color`: Viking Digital Image Model 2.1 true-color
  - `HRSC_MOLA_Blend_Hillshade`: ESA Mars Express HRSC stereo topography blended with MOLA
  - `MOLA_color` & `MOLA_bw`: Topographic elevation and shaded relief

### 3. NASA Curiosity & Perseverance Traverse Methodologies
- **Research Citation:** [Curiosity's Proposed Path Up Mount Sharp](https://science.nasa.gov/resource/curiositys-proposed-path-up-mount-sharp/)
- **Traverse Algorithm:**
  - Non-linear slope cost penalization based on rover wheel slip and astronaut boot slippage
  - Critical slope threshold: `<12°` safe transit, `12°–18°` cautious traverse, `18°–25°` steep slip hazard, `>25°` impassable
  - Regolith shear failure model calibrated against Gale Crater and Jezero Crater sand drift encounters
  - Point of No Return (PNR) computation for 4th pathfinding mode: *Astronaut EVA (Life-Support Optimal)*

### 4. NASA Worldview Earth/Planetary Imagery Frameworks
- **Portal:** [NASA Worldview](https://worldview.earthdata.nasa.gov/)
- **Framework Implementations:**
  - Planetocentric graticule overlays (IAU 2000 parallels and meridians)
  - Multi-layer visual inspection and comparative telemetry
  - Solar longitude ($L_s$) and Sol scrubber synchronizing orbital ephemeris, atmospheric dust opacity, and solar incidence angles

### 5. NASA Mars 2020 Raw Image & Outcrop Feeds
- **Portal:** [NASA Mars 2020 Raw Images](https://mars.nasa.gov/mars2020/multimedia/raw-images/)
- **Instruments:** Mastcam-Z stereo multispectral, SuperCam LIBS & Raman, SHERLOC deep-UV fluorescence, PIXL micro-XRF, Navcam
- **Geological Formations:**
  - Jezero Crater: Bright Angel mudstones, Séítah olivine-cumulate, Kodiak delta front remnant, Neretva Vallis conglomerate, Skinner Ridge sulfate-bearing sandstone
  - Gale Crater: Mount Sharp layered sulfate unit, Pahrump Hills lacustrine mudstone
- **Sample Tube Management:** Interactive caching and status tracking corresponding to Perseverance Sample Return tubes (abraded, cored & sealed, surface depot cached)

---

## Coordinate Reference Systems

Mars uses different CRS conventions than Earth:

| Convention | Description |
|-----------|-------------|
| IAU 2000 Mars | Planetocentric, body-fixed; positive E longitude |
| MOLA areoid | Gravitational equipotential surface (vertical datum) |
| WGS84 | NOT applicable to Mars |
| EPSG:49900 | Mars 2000 Sphere (simple cylindrical) |
| EPSG:104903 | Mars 2000 (planetocentric) |

This application uses **planetocentric latitude, positive-east longitude** (IAU 2000 convention).
