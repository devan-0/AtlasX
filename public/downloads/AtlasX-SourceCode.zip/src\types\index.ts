// AtlasX — Core Type Definitions

export type DataClassification = 'observed' | 'derived' | 'modelled' | 'simulated' | 'unavailable';

export interface Coordinates {
  lat: number; // Planetocentric latitude, degrees N
  lon: number; // Planetocentric longitude, degrees E (0–360 or -180–180)
}

export interface BoundingBox {
  north: number;
  south: number;
  east: number;
  west: number;
}

export interface Dataset {
  id: string;
  name: string;
  instrument: string;
  mission: string;
  sourceUrl: string;
  acquisitionDate?: string;
  coverage: string;
  resolution: string;
  crs: string;
  classification: DataClassification;
  processingStatus: 'raw' | 'calibrated' | 'derived' | 'synthesized' | 'unavailable';
  lastRetrieval?: string;
  notes?: string;
}

export interface TerrainPoint {
  lat: number;
  lon: number;
  elevation: number; // meters above MOLA areoid
  slope?: number;    // degrees
  roughness?: number;
}

export type HazardLevel = 'none' | 'low' | 'moderate' | 'high' | 'extreme';

export interface Hazard {
  id: string;
  coordinates: Coordinates;
  type: 'crater' | 'steep-slope' | 'rock-field' | 'sand-trap' | 'ridge' | 'unknown';
  severity: HazardLevel;
  radius?: number; // meters
  description: string;
  dataSource: string;
  confidence: number; // 0–1
}

export type ScienceCategory =
  | 'mineralogy'
  | 'geology'
  | 'hydrology'
  | 'geomorphology'
  | 'astrobiology'
  | 'resource'
  | 'atmospheric';

export interface ScienceTarget {
  id: string;
  name: string;
  coordinates: Coordinates;
  category: ScienceCategory;
  dataSource: string;
  rationale: string;
  observations: string[];
  priority: 1 | 2 | 3 | 4 | 5; // 5 = highest
  dataQuality: 'high' | 'medium' | 'low' | 'inferred';
  uncertainty: string;
  estimatedDetourKm?: number;
  notes?: string;
  missionStatus: 'proposed' | 'planned' | 'visited' | 'completed';
}

export interface Waypoint {
  id: string;
  coordinates: Coordinates;
  name: string;
  type: 'start' | 'end' | 'science' | 'waypoint';
  scienceTargetId?: string;
  notes?: string;
}

export type RouteType = 'shortest' | 'lower-risk' | 'science-priority' | 'astronaut-eva';

export interface RouteSegment {
  from: Coordinates;
  to: Coordinates;
  distance: number; // meters
  elevationChange: number; // meters
  maxSlope: number; // degrees
  hazardLevel: HazardLevel;
  cost: number;
}

export interface Route {
  id: string;
  name: string;
  type: RouteType;
  waypoints: Waypoint[];
  segments: RouteSegment[];
  totalDistance: number; // km
  estimatedDuration: number; // hours
  maxSlope: number;
  meanSlope: number;
  totalElevationGain: number;
  totalElevationLoss: number;
  hazardCount: number;
  scienceTargetsCount: number;
  totalCost: number;
  costBreakdown: {
    distance: number;
    terrain: number;
    hazard: number;
    scienceBonus: number;
  };
  profile: TerrainPoint[];
  evaMetrics?: EVARouteMetrics;
  createdAt: string;
  notes?: string;
}

export interface MarsRegion {
  id: string;
  name: string;
  description: string;
  coordinates: Coordinates;
  boundingBox: BoundingBox;
  area?: number; // km²
  geologyNote?: string;
  scientificInterest: 'low' | 'medium' | 'high' | 'very-high';
}

export interface SolarAnalysis {
  location: Coordinates;
  date: string;
  marsSol?: number;
  solarIncidenceDeg: number;
  estimatedIrradianceWm2: number;
  illuminationDurationH: number;
  sunriseTime?: string;
  sunsetTime?: string;
  solarZenithAngle: number;
  methodology: 'geometric' | 'modelled' | 'observed';
  assumptions: string[];
  classification: DataClassification;
}

export interface AtmosphericObservation {
  timestamp: string;
  location: Coordinates;
  instrumentSource: string;
  temperatureK?: number;
  pressurePa?: number;
  windSpeedMs?: number;
  windDirectionDeg?: number;
  dustOpticalDepth?: number;
  classification: DataClassification;
}

export interface SuitabilityScore {
  overall: number; // 0–100
  slope: number;
  roughness: number;
  elevation: number;
  hazards: number;
  dataCoverage: number;
  explanation: string[];
  violations: string[];
  missingData: string[];
}

export interface CandidateSite {
  id: string;
  name: string;
  coordinates: Coordinates;
  landingSuitability?: SuitabilityScore;
  ascentSuitability?: SuitabilityScore;
  scienceValue: number; // 0–100
  nearbyTargets: string[]; // ScienceTarget ids
  dataClassification: DataClassification;
  notes?: string;
}

export interface SavedMission {
  id: string;
  name: string;
  region: MarsRegion;
  routes: Route[];
  scienceTargets: ScienceTarget[];
  candidateSites: CandidateSite[];
  activeLayerIds: string[];
  notes: string;
  createdAt: string;
  updatedAt: string;
  version: string;
}

export interface LayerConfig {
  id: string;
  name: string;
  category: 'terrain' | 'minerals' | 'solar' | 'atmosphere' | 'suitability' | 'route' | 'base';
  visible: boolean;
  opacity: number; // 0–1
  dataset?: Dataset;
  classification: DataClassification;
  legendItems?: { color: string; label: string }[];
}

// ── Astronaut Physiological & EVA Survival Modeling ─────────────────────────

export interface AstronautBioState {
  heartRateBpm: number;
  metabolicRateWatts: number;
  vo2LitersPerMin: number;
  co2OutputLitersPerMin: number;
  bodyCoreTempC: number;
  skinTempC: number;
  sweatRateMlPerHour: number;
  hydrationPercent: number;
  fatigueIndex: number; // 0–100%
}

export interface EVASuitState {
  o2TankPressureBar: number;           // Nominal 200 bar
  o2MassRemainingKg: number;           // Nominal 1.2 kg usable
  o2TimeRemainingMinutes: number;      // Primary tank consumable margin
  secondaryO2ReserveMinutes: number;   // 30 min emergency reserve
  batteryChargePercent: number;        // Suit life support battery
  batteryRemainingMinutes: number;
  liohCanisterSaturationPercent: number; // LiOH / Amine scrubber saturation
  coolingWaterRemainingLiters: number; // Sublimator feed water
  suitInternalPressureKpa: number;     // Nominal 29.6 kPa (4.3 psi) pure O2
  suitThermalMode: 'nominal' | 'high-cooling' | 'heating' | 'warning';
}

export interface EVASurvivalMetrics {
  pointOfNoReturnRadiusKm: number;     // Maximum radial distance before return is compromised
  pointOfNoReturnTimeMinutes: number;  // Time elapsed before mandatory turnaround
  evaStatus: 'GO_NOMINAL' | 'CAUTION_MARGINAL' | 'ABORT_HAZARDOUS';
  limitingFactor: 'O2' | 'BATTERY' | 'LIOH' | 'THERMAL' | 'FATIGUE' | 'METEOROLOGICAL';
  activeWarnings: string[];
}

export interface EVARouteMetrics {
  totalMetabolicEnergyKcal: number;
  totalMetabolicEnergyKwh: number;
  totalO2ConsumedLiters: number;
  peakMetabolicRateWatts: number;
  peakHeartRateBpm: number;
  soilSlipRiskPercent: number;          // Curiosity/Perseverance regolith slip index
  pointOfNoReturnWpIndex: number;       // Waypoint index where return margin triggers
  safeReturnMarginMinutes: number;      // Consumables margin remaining upon return
  limitingFactor: string;
}

// ── Meteorological Stream & EVA Hazard Advisory ─────────────────────────────

export interface EVAMeteorologicalAdvisory {
  sol: number;
  temperatureK: number;
  temperatureC: number;
  pressurePa: number;
  dustOpticalDepthTau: number;
  windSpeedMs: number;
  windGustMs: number;
  uvFluxIndex: number;
  thermalSuitPenaltyPercent: number;
  visibilityRangeMeters: number;
  stormRisk: 'low' | 'moderate' | 'high' | 'severe';
  evaSafetyRating: 'GO' | 'CAUTION' | 'NO_GO';
  recommendations: string[];
}

// ── Mars 2020 Raw Image & Outcrop Feeds ─────────────────────────────────────

export type OutcropCamera = 'Mastcam-Z' | 'Navcam' | 'SuperCam' | 'SHERLOC' | 'PIXL';

export interface OutcropImage {
  camera: OutcropCamera;
  url: string;
  thumbnailUrl: string;
  description: string;
  filterOrWavelength?: string;
  resolutionMmPx?: number;
}

export interface OutcropSpectralFeature {
  bandMicrons: number;
  mineralOrBond: string;
  intensity: 'weak' | 'moderate' | 'strong' | 'diagnostic';
}

export interface SampleTube {
  tubeId: string;
  targetName: string;
  solAcquired?: number;
  status: 'empty' | 'abraded' | 'cored_sealed' | 'depot_cached';
  lithology: string;
  biosignaturePotential: 'Low' | 'Moderate' | 'High' | 'Exceptional';
  drillingDepthMm?: number;
}

export interface MarsOutcrop {
  id: string;
  name: string;
  regionId: string;
  sol: number;
  coordinates: Coordinates;
  elevationM: number;
  formation: string;
  geologicalEra: 'Noachian' | 'Hesperian' | 'Amazonian';
  rockType: string;
  mineralogy: string[];
  compressiveStrengthMpa: number;       // RAT drillability
  strikeDip: { strikeDeg: number; dipDeg: number };
  biosignaturePotential: 'Low' | 'Moderate' | 'High' | 'Exceptional';
  sampleTube?: SampleTube;
  images: OutcropImage[];
  spectralFeatures: OutcropSpectralFeature[];
  curiosityPerseveranceAnalogy: string;
  openDataSources: {
    marsTrekUrl: string;
    pdsArchiveUrl: string;
    rawImageFeedUrl: string;
  };
}
