import React, { useState } from 'react';
import { RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer, Tooltip } from 'recharts';
import { useAppStore } from '../store/useAppStore';
import DataBadge from '../components/ui/DataBadge';
import GlassPanel from '../components/ui/GlassPanel';
import { Shield, AlertTriangle, CheckCircle, XCircle, HelpCircle, ChevronDown, ChevronRight } from 'lucide-react';
import type { CandidateSite, SuitabilityScore } from '../types';

const SCORE_COLOR = (n: number) => n >= 75 ? '#22c55e' : n >= 50 ? '#d97706' : '#ef4444';
const SCORE_LABEL = (n: number) => n >= 75 ? 'Suitable' : n >= 50 ? 'Marginal' : 'Unsuitable';

function ScoreBar({ label, value }: { label: string; value: number }) {
  return (
    <div className="space-y-0.5">
      <div className="flex justify-between text-[11px]">
        <span className="text-slate-400">{label}</span>
        <span className="font-mono" style={{ color: SCORE_COLOR(value) }}>{value}</span>
      </div>
      <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
        <div className="h-full rounded-full transition-all duration-300" style={{ width: `${value}%`, background: SCORE_COLOR(value) }} />
      </div>
    </div>
  );
}

function OverallGauge({ score }: { score: number }) {
  const color = SCORE_COLOR(score);
  const r = 36, cx = 50, cy = 52;
  const circumference = Math.PI * r;
  const offset = circumference * (1 - score / 100);
  return (
    <svg width={100} height={60} viewBox="0 0 100 60">
      <path d={`M ${cx - r} ${cy} A ${r} ${r} 0 0 1 ${cx + r} ${cy}`} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth={8} strokeLinecap="round" />
      <path d={`M ${cx - r} ${cy} A ${r} ${r} 0 0 1 ${cx + r} ${cy}`} fill="none" stroke={color} strokeWidth={8} strokeLinecap="round"
        strokeDasharray={circumference} strokeDashoffset={offset} style={{ transition: 'stroke-dashoffset 0.5s ease' }} />
      <text x={cx} y={cy - 4} textAnchor="middle" fill={color} fontSize={16} fontWeight="bold" fontFamily="monospace">{score}</text>
      <text x={cx} y={cy + 8} textAnchor="middle" fill="rgba(148,163,184,0.7)" fontSize={8} fontFamily="monospace">{SCORE_LABEL(score)}</text>
    </svg>
  );
}

function SiteSummaryCard({ site, isSelected, onClick }: { site: CandidateSite; isSelected: boolean; onClick: () => void }) {
  const ls = site.landingSuitability?.overall ?? 0;
  const as = site.ascentSuitability?.overall ?? 0;
  return (
    <button onClick={onClick}
      className={`w-full text-left p-3 rounded-lg border transition-all ${isSelected ? 'border-orange-500/40 bg-mars-600/10' : 'border-white/5 hover:border-white/10 hover:bg-white/3'}`}>
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs font-semibold text-slate-200 truncate">{site.name}</span>
        <DataBadge classification={site.dataClassification} />
      </div>
      <div className="grid grid-cols-2 gap-2 text-[11px]">
        <div><span className="text-slate-500">Landing</span><span className="ml-1 font-mono" style={{ color: SCORE_COLOR(ls) }}>{ls}/100</span></div>
        <div><span className="text-slate-500">Ascent</span><span className="ml-1 font-mono" style={{ color: SCORE_COLOR(as) }}>{as}/100</span></div>
        <div><span className="text-slate-500">Science</span><span className="ml-1 font-mono text-violet-400">{site.scienceValue}/100</span></div>
        <div><span className="text-slate-500">Targets</span><span className="ml-1 font-mono text-cyan-400">{site.nearbyTargets.length}</span></div>
      </div>
    </button>
  );
}

function SuitabilityDetail({ score, label }: { score: SuitabilityScore; label: string }) {
  const [expanded, setExpanded] = useState(false);
  return (
    <div>
      <div className="flex items-center gap-2 mb-3">
        <OverallGauge score={score.overall} />
        <div>
          <div className="text-sm font-semibold text-slate-200">{label}</div>
          <div className="text-xs text-slate-400">Overall score: {score.overall}/100</div>
        </div>
      </div>

      <div className="space-y-1.5 mb-3">
        <ScoreBar label="Slope" value={score.slope} />
        <ScoreBar label="Surface Roughness" value={score.roughness} />
        <ScoreBar label="Elevation" value={score.elevation} />
        <ScoreBar label="Hazard Clearance" value={score.hazards} />
        <ScoreBar label="Data Coverage" value={score.dataCoverage} />
      </div>

      {/* Explanation */}
      <div className="space-y-1">
        {score.explanation.map((e, i) => (
          <div key={i} className="flex items-start gap-1.5 text-[11px] text-slate-400">
            <CheckCircle size={10} className="text-emerald-400 flex-shrink-0 mt-0.5" />
            <span>{e}</span>
          </div>
        ))}
      </div>

      {/* Violations */}
      {score.violations.length > 0 && (
        <div className="mt-2 space-y-1">
          {score.violations.map((v, i) => (
            <div key={i} className="flex items-start gap-1.5 text-[11px] text-red-400">
              <XCircle size={10} className="flex-shrink-0 mt-0.5" />
              <span>{v}</span>
            </div>
          ))}
        </div>
      )}

      {/* Missing data */}
      {score.missingData.length > 0 && (
        <div className="mt-2 space-y-1">
          <div className="text-[10px] text-slate-500 uppercase tracking-wide">Missing Data</div>
          {score.missingData.map((m, i) => (
            <div key={i} className="flex items-start gap-1.5 text-[11px] text-amber-400">
              <HelpCircle size={10} className="flex-shrink-0 mt-0.5" />
              <span>{m}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default function SuitabilityPage() {
  const { candidateSites } = useAppStore();
  const [selectedId, setSelectedId] = useState<string>(candidateSites[0]?.id ?? '');
  const [mode, setMode] = useState<'landing' | 'ascent'>('landing');

  const site = candidateSites.find(s => s.id === selectedId);
  const score = mode === 'landing' ? site?.landingSuitability : site?.ascentSuitability;

  const radarData = score ? [
    { metric: 'Slope', value: score.slope },
    { metric: 'Roughness', value: score.roughness },
    { metric: 'Elevation', value: score.elevation },
    { metric: 'Hazards', value: score.hazards },
    { metric: 'Data Cover', value: score.dataCoverage },
  ] : [];

  return (
    <div className="flex h-full overflow-hidden">
      {/* Left: site list */}
      <div className="w-64 flex-shrink-0 flex flex-col gap-2 p-3 border-r border-white/5 overflow-y-auto bg-navy-900/60">
        <div className="text-[10px] text-slate-500 uppercase tracking-widest font-semibold px-1">Candidate Sites</div>
        {candidateSites.map(s => (
          <SiteSummaryCard key={s.id} site={s} isSelected={s.id === selectedId} onClick={() => setSelectedId(s.id)} />
        ))}
      </div>

      {/* Right: detail */}
      <div className="flex-1 p-4 overflow-y-auto space-y-4">
        {/* Disclaimer */}
        <div className="flex items-start gap-2 p-3 rounded-lg bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300">
          <AlertTriangle size={14} className="flex-shrink-0 mt-0.5" />
          <span>This is a preliminary research decision-support tool, not a certified spacecraft landing or launch assessment. All scores are derived from synthetic demonstration data. Real site assessments require detailed engineering analysis, high-resolution terrain data, and spacecraft-specific constraints.</span>
        </div>

        {site ? (
          <>
            {/* Site header */}
            <div className="flex items-start justify-between">
              <div>
                <h2 className="text-base font-bold text-slate-100">{site.name}</h2>
                <div className="text-xs font-mono text-slate-400 mt-0.5">
                  {site.coordinates.lat.toFixed(4)}°N · {site.coordinates.lon.toFixed(4)}°E
                </div>
              </div>
              {/* Mode toggle */}
              <div className="flex bg-white/5 rounded-lg p-0.5 gap-0.5">
                {(['landing', 'ascent'] as const).map(m => (
                  <button key={m} onClick={() => setMode(m)}
                    className={`px-3 py-1 rounded text-xs font-medium capitalize transition-colors ${mode === m ? 'bg-mars-600/30 text-orange-400' : 'text-slate-500 hover:text-slate-300'}`}>
                    {m}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {/* Score detail */}
              <GlassPanel title={`${mode === 'landing' ? 'Landing' : 'Ascent'} Suitability`} badge={<DataBadge classification="simulated" />}>
                {score ? (
                  <SuitabilityDetail score={score} label={`${mode === 'landing' ? 'Landing' : 'Ascent/Launch'} Assessment`} />
                ) : (
                  <div className="text-xs text-slate-500">No {mode} data for this site.</div>
                )}
              </GlassPanel>

              {/* Radar chart */}
              <GlassPanel title="Score Radar">
                {radarData.length > 0 ? (
                  <ResponsiveContainer width="100%" height={220}>
                    <RadarChart data={radarData} cx="50%" cy="50%" outerRadius="70%">
                      <PolarGrid stroke="rgba(255,255,255,0.08)" />
                      <PolarAngleAxis dataKey="metric" tick={{ fill: '#64748b', fontSize: 10 }} />
                      <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fill: '#4f5e8a', fontSize: 8 }} />
                      <Tooltip contentStyle={{ background: 'rgba(10,16,24,0.95)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 6, fontSize: 11, color: '#f0f4ff' }} />
                      <Radar name="Score" dataKey="value" stroke="#f46040" fill="#f46040" fillOpacity={0.2} strokeWidth={2} />
                    </RadarChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="text-xs text-slate-500">No data to display</div>
                )}
              </GlassPanel>

              {/* Nearby science targets */}
              <GlassPanel title="Nearby Science Targets" className="lg:col-span-2">
                <div className="grid grid-cols-2 lg:grid-cols-3 gap-2">
                  {site.nearbyTargets.map(tid => {
                    const t = useAppStore.getState().scienceTargets.find(x => x.id === tid);
                    if (!t) return null;
                    return (
                      <div key={tid} className="flex items-center gap-2 p-2 rounded bg-white/3 border border-white/5">
                        <span className="w-2 h-2 rounded-full flex-shrink-0 bg-violet-400" />
                        <div className="min-w-0">
                          <div className="text-[11px] text-slate-200 truncate">{t.name}</div>
                          <div className="text-[9px] text-slate-500 capitalize">{t.category} · P{t.priority}</div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </GlassPanel>
            </div>

            {site.notes && (
              <div className="p-2 rounded bg-orange-500/10 border border-orange-500/20 text-[11px] text-orange-300">{site.notes}</div>
            )}
          </>
        ) : (
          <div className="flex flex-col items-center justify-center h-full gap-3">
            <Shield size={32} className="text-slate-600" />
            <span className="text-slate-500">Select a candidate site</span>
          </div>
        )}
      </div>
    </div>
  );
}
