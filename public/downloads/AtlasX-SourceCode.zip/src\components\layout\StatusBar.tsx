// StatusBar — bottom status strip: mission, routes, targets, region, timestamp, telemetry
import React from 'react';
import { useAppStore } from '../../store/useAppStore';
import { useRealTimeMarsClock } from '../../utils/marsTime';

const StatusBar: React.FC = () => {
  const savedMissions = useAppStore((s) => s.savedMissions);
  const activeMissionId = useAppStore((s) => s.activeMissionId);
  const routes = useAppStore((s) => s.routes);
  const scienceTargets = useAppStore((s) => s.scienceTargets);
  const selectedRegion = useAppStore((s) => s.selectedRegion);
  const selectedDate = useAppStore((s) => s.selectedDate);
  const isLiveDate = useAppStore((s) => s.isLiveDate);
  const statusMessage = useAppStore((s) => s.statusMessage);

  const clock = useRealTimeMarsClock(
    selectedRegion.coordinates.lon,
    isLiveDate ? null : selectedDate,
    1000
  );

  const activeMission = activeMissionId
    ? savedMissions.find((m) => m.id === activeMissionId)
    : null;

  return (
    <footer className="flex-shrink-0 h-8 flex items-center justify-between gap-4 px-4 bg-black/70 border-t border-white/10 backdrop-blur-md z-10 overflow-hidden select-none">
      {/* Left: mission + message */}
      <div className="flex items-center gap-4 min-w-0 flex-1">
        <div className="flex items-center gap-1.5 flex-shrink-0">
          <span
            className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${
              activeMission ? 'bg-mars-orange' : 'bg-white/20'
            }`}
          />
          <span className="text-[11px] font-mono text-white/70 truncate max-w-[200px]">
            {activeMission ? activeMission.name : 'No active mission'}
          </span>
        </div>

        {statusMessage && (
          <span className="text-[10px] font-mono text-amber-300/70 truncate">
            {statusMessage}
          </span>
        )}
      </div>

      {/* Centre: stats & live clocks */}
      <div className="hidden sm:flex items-center gap-4 flex-shrink-0">
        <Pill label="Earth UTC" value={clock.utcTime} mono />
        <Pill label="Mars MTC" value={clock.mtcFormatted} mono />
        <Pill label="Local Solar" value={clock.lmstFormatted} mono />
        <Pill label="Region" value={selectedRegion.name} />
        <Pill label="Routes" value={routes.length} />
        <Pill label="Targets" value={scienceTargets.length} />
      </div>

      {/* Right: desktop version */}
      <div className="flex items-center gap-2 flex-shrink-0">
        <span className="text-[9px] font-mono font-bold tracking-widest uppercase bg-amber-400/15 border border-amber-400/30 text-amber-300 px-2 py-0.5 rounded">
          Desktop v1.0.0
        </span>
      </div>
    </footer>
  );
};

interface PillProps {
  label: string;
  value: string | number;
  mono?: boolean;
}

const Pill: React.FC<PillProps> = ({ label, value, mono }) => (
  <div className="flex items-center gap-1.5">
    <span className="text-[9px] font-mono text-white/30 uppercase tracking-wider">{label}:</span>
    <span
      className={`text-[11px] text-white/70 ${mono ? 'font-mono' : 'font-medium'} truncate max-w-[140px]`}
    >
      {value}
    </span>
  </div>
);

export default StatusBar;
