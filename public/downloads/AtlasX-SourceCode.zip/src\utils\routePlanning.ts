// AtlasX — Route Planning Utilities
// A* pathfinding on a synthetic terrain grid.
// Incorporates NASA Curiosity & Perseverance Traverse methodologies and Astronaut EVA Physiological Modeling.
// Classification: SIMULATED — Not certified navigation data.

import type { Route, RouteType, Waypoint, RouteSegment, TerrainPoint, Coordinates } from '../types';
import { evaluateEVARouteMetrics } from './evaBiometrics';
import { marsDistance } from './marsCoordinates';

// ── Terrain Grid ────────────────────────────────────────────────────────────

export interface TerrainCell {
  row: number;
  col: number;
  lat: number;
  lon: number;
  elevation: number; // meters
  slope: number;     // degrees
  roughness: number; // 0–1
  hazardPenalty: number; // 0–1
  scienceBonus: number;  // 0–1
}

export type TerrainGrid = TerrainCell[][];

/** Reproducible pseudo-random number generator (seeded). */
function seededRandom(seed: number): () => number {
  let s = seed;
  return () => {
    s = (s * 1664525 + 1013904223) & 0xffffffff;
    return (s >>> 0) / 0xffffffff;
  };
}

/**
 * Generate a synthetic terrain grid for a bounding box.
 * Uses sin/cos wave combination for plausible Martian topography.
 */
export function generateTerrainGrid(
  north: number,
  south: number,
  east: number,
  west: number,
  resolution = 32
): TerrainGrid {
  const rng = seededRandom(42);
  const rows = resolution;
  const cols = resolution;
  const dLat = (north - south) / (rows - 1);
  const dLon = (east - west) / (cols - 1);

  const grid: TerrainGrid = [];

  for (let r = 0; r < rows; r++) {
    const row: TerrainCell[] = [];
    for (let c = 0; c < cols; c++) {
      const lat = north - r * dLat;
      const lon = west + c * dLon;

      // Procedural elevation: combination of waves + noise
      const nx = c / cols;
      const ny = r / rows;
      const elevation =
        -2400 +
        400 * Math.sin(nx * Math.PI * 3) * Math.cos(ny * Math.PI * 2) +
        200 * Math.sin(nx * Math.PI * 7 + 0.5) * Math.sin(ny * Math.PI * 5 + 1.2) +
        100 * (rng() - 0.5);

      // Slope: derivative of elevation field (simplified)
      const slope = Math.abs(
        15 * Math.cos(nx * Math.PI * 3) * Math.cos(ny * Math.PI * 2) +
        10 * Math.cos(nx * Math.PI * 7 + 0.5) * Math.sin(ny * Math.PI * 5 + 1.2)
      ) + rng() * 5;

      const roughness = Math.min(1, (slope / 30) * 0.7 + rng() * 0.3);
      const hazardPenalty = slope > 20 ? 0.8 : slope > 12 ? 0.4 : rng() * 0.1;
      const scienceBonus = rng() * 0.3 + (elevation > -2200 ? 0.2 : 0);

      row.push({ row: r, col: c, lat, lon, elevation, slope, roughness, hazardPenalty, scienceBonus });
    }
    grid.push(row);
  }
  return grid;
}

// ── Cost Weights ──────────────────────────────────────────────────────────────

export interface RouteWeights {
  distance: number;
  slope: number;
  hazard: number;
  science: number; // negative = bonus
}

export const DEFAULT_WEIGHTS: RouteWeights = { distance: 1, slope: 1, hazard: 1, science: 0.5 };
export const LOWER_RISK_WEIGHTS: RouteWeights = { distance: 0.6, slope: 2.5, hazard: 3, science: 0.2 };
export const SCIENCE_PRIORITY_WEIGHTS: RouteWeights = { distance: 0.8, slope: 0.8, hazard: 0.8, science: 2.5 };
export const ASTRONAUT_EVA_WEIGHTS: RouteWeights = { distance: 1.0, slope: 3.8, hazard: 3.2, science: 1.2 };

function cellCost(from: TerrainCell, to: TerrainCell, w: RouteWeights): number {
  const distCost = w.distance;
  // Curiosity/Perseverance non-linear mobility threshold:
  // Slopes > 15° significantly escalate wheel slip and suited astronaut metabolic strain
  const slopeRatio = to.slope / 30;
  const nonLinearSlope = to.slope > 16 ? Math.pow(slopeRatio, 2.0) * 2.2 : slopeRatio;
  const slopeCost = w.slope * nonLinearSlope;
  const hazardCost = w.hazard * to.hazardPenalty;
  const scienceDeduction = w.science * to.scienceBonus;
  return Math.max(0.01, distCost + slopeCost + hazardCost - scienceDeduction);
}

// ── A* Pathfinding ────────────────────────────────────────────────────────────

interface AStarNode {
  r: number;
  c: number;
  g: number;
  h: number;
  f: number;
  parent: AStarNode | null;
}

function heuristic(r1: number, c1: number, r2: number, c2: number): number {
  return Math.sqrt((r1 - r2) ** 2 + (c1 - c2) ** 2);
}

/**
 * Run A* on the terrain grid from (startR,startC) to (endR,endC).
 * Returns array of [row, col] pairs representing the path.
 */
export function aStarPath(
  grid: TerrainGrid,
  startR: number,
  startC: number,
  endR: number,
  endC: number,
  weights: RouteWeights,
  maxSlopeDeg = 35
): Array<[number, number]> {
  const rows = grid.length;
  const cols = grid[0].length;
  const key = (r: number, c: number) => r * cols + c;

  const open = new Map<number, AStarNode>();
  const closed = new Set<number>();
  const gScore = new Map<number, number>();

  const startNode: AStarNode = {
    r: startR, c: startC, g: 0,
    h: heuristic(startR, startC, endR, endC),
    f: heuristic(startR, startC, endR, endC),
    parent: null,
  };
  open.set(key(startR, startC), startNode);
  gScore.set(key(startR, startC), 0);

  const DIRS = [[-1,0],[1,0],[0,-1],[0,1],[-1,-1],[-1,1],[1,-1],[1,1]];

  let iterations = 0;
  while (open.size > 0 && iterations < 10000) {
    iterations++;
    // Pop lowest f
    let current: AStarNode | null = null;
    for (const node of open.values()) {
      if (!current || node.f < current.f) current = node;
    }
    if (!current) break;

    if (current.r === endR && current.c === endC) {
      // Reconstruct path
      const path: Array<[number, number]> = [];
      let n: AStarNode | null = current;
      while (n) { path.unshift([n.r, n.c]); n = n.parent; }
      return path;
    }

    open.delete(key(current.r, current.c));
    closed.add(key(current.r, current.c));

    for (const [dr, dc] of DIRS) {
      const nr = current.r + dr;
      const nc = current.c + dc;
      if (nr < 0 || nr >= rows || nc < 0 || nc >= cols) continue;
      if (closed.has(key(nr, nc))) continue;

      const neighbor = grid[nr][nc];
      if (neighbor.slope > maxSlopeDeg) continue;

      const moveCost = Math.sqrt(dr * dr + dc * dc) * cellCost(grid[current.r][current.c], neighbor, weights);
      const tentativeG = current.g + moveCost;

      if (tentativeG < (gScore.get(key(nr, nc)) ?? Infinity)) {
        gScore.set(key(nr, nc), tentativeG);
        const h = heuristic(nr, nc, endR, endC);
        const node: AStarNode = {
          r: nr, c: nc, g: tentativeG,
          h, f: tentativeG + h,
          parent: current,
        };
        open.set(key(nr, nc), node);
      }
    }
  }

  // No path found — return straight line
  return [[startR, startC], [endR, endC]];
}

// ── Closest Grid Cell ─────────────────────────────────────────────────────────

export function closestCell(grid: TerrainGrid, lat: number, lon: number): [number, number] {
  let bestR = 0, bestC = 0, bestDist = Infinity;
  for (let r = 0; r < grid.length; r++) {
    for (let c = 0; c < grid[r].length; c++) {
      const d = (grid[r][c].lat - lat) ** 2 + (grid[r][c].lon - lon) ** 2;
      if (d < bestDist) { bestDist = d; bestR = r; bestC = c; }
    }
  }
  return [bestR, bestC];
}

// ── Route Builder ─────────────────────────────────────────────────────────────

/** Build a full Route object from a raw A* path through the terrain grid. */
export function buildRoute(
  id: string,
  name: string,
  type: RouteType,
  path: Array<[number, number]>,
  grid: TerrainGrid,
  weights: RouteWeights
): Route {
  const waypoints: Waypoint[] = path.map(([r, c], i) => ({
    id: `wp-${id}-${i}`,
    coordinates: { lat: grid[r][c].lat, lon: grid[r][c].lon },
    name: i === 0 ? 'Start' : i === path.length - 1 ? 'End' : `WP-${i}`,
    type: i === 0 ? 'start' : i === path.length - 1 ? 'end' : 'waypoint',
  }));

  const segments: RouteSegment[] = [];
  let totalDistM = 0;
  let totalElevGain = 0;
  let totalElevLoss = 0;
  let maxSlope = 0;
  let sumSlope = 0;
  let hazardCount = 0;

  // Accurate Martian degree-to-meter conversion using Mars mean volumetric radius R = 3389.5 km
  const MARS_METERS_PER_DEG_LAT = 59160;

  for (let i = 0; i < path.length - 1; i++) {
    const [r1, c1] = path[i];
    const [r2, c2] = path[i + 1];
    const cell1 = grid[r1][c1];
    const cell2 = grid[r2][c2];
    const midLatRad = ((cell1.lat + cell2.lat) / 2 * Math.PI) / 180;
    const dLatM = (cell2.lat - cell1.lat) * MARS_METERS_PER_DEG_LAT;
    const dLonM = (cell2.lon - cell1.lon) * MARS_METERS_PER_DEG_LAT * Math.cos(midLatRad);
    const dist = Math.sqrt(dLatM * dLatM + dLonM * dLonM);
    const elevChange = cell2.elevation - cell1.elevation;
    const sl = cell2.slope;

    totalDistM += dist;
    if (elevChange > 0) totalElevGain += elevChange;
    else totalElevLoss += Math.abs(elevChange);
    maxSlope = Math.max(maxSlope, sl);
    sumSlope += sl;
    if (cell2.hazardPenalty > 0.5) hazardCount++;

    const hz = cell2.hazardPenalty > 0.6 ? 'high' : cell2.hazardPenalty > 0.3 ? 'moderate' : 'low';
    segments.push({
      from: { lat: cell1.lat, lon: cell1.lon },
      to: { lat: cell2.lat, lon: cell2.lon },
      distance: dist,
      elevationChange: elevChange,
      maxSlope: sl,
      hazardLevel: hz,
      cost: cellCost(cell1, cell2, weights),
    });
  }

  const totalDistKm = totalDistM / 1000;
  const walkSpeedKmH = 3.2; // Suited astronaut planetary walking speed
  const estimatedDuration = totalDistKm / walkSpeedKmH;
  const meanSlope = path.length > 1 ? sumSlope / (path.length - 1) : 0;

  const distCostTotal = segments.reduce((s, seg) => s + seg.distance * weights.distance, 0);
  const terrainCostTotal = segments.reduce((s, seg) => s + (seg.maxSlope / 35) * weights.slope, 0);
  const hazardCostTotal = segments.reduce((s, seg) => s + seg.cost * weights.hazard * 0.1, 0);
  const scienceBonus = path.reduce((s, [r,c]) => s + grid[r][c].scienceBonus * weights.science, 0);

  const profile: TerrainPoint[] = path.map(([r, c]) => ({
    lat: grid[r][c].lat,
    lon: grid[r][c].lon,
    elevation: grid[r][c].elevation,
    slope: grid[r][c].slope,
  }));

  const evaMetrics = evaluateEVARouteMetrics(profile, totalDistKm, estimatedDuration);

  return {
    id,
    name,
    type,
    waypoints,
    segments,
    totalDistance: totalDistKm,
    estimatedDuration,
    maxSlope,
    meanSlope,
    totalElevationGain: totalElevGain,
    totalElevationLoss: totalElevLoss,
    hazardCount,
    scienceTargetsCount: 0,
    totalCost: distCostTotal + terrainCostTotal + hazardCostTotal - scienceBonus,
    costBreakdown: {
      distance: distCostTotal,
      terrain: terrainCostTotal,
      hazard: hazardCostTotal,
      scienceBonus,
    },
    profile,
    evaMetrics,
    createdAt: new Date().toISOString(),
  };
}

// ── Coordinate snapping helper ────────────────────────────────────────────────

/** Clamp a coordinate to a bounding box. */
export function clampCoord(coord: Coordinates, north: number, south: number, east: number, west: number): Coordinates {
  return {
    lat: Math.max(south, Math.min(north, coord.lat)),
    lon: Math.max(west, Math.min(east, coord.lon)),
  };
}
