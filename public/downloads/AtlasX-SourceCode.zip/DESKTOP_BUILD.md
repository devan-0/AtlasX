## Windows Desktop Application

AtlasX ships as a native Windows desktop application built with **Electron** wrapping the React+Vite frontend and a **bundled Python FastAPI backend** compiled with PyInstaller.

### Architecture

```
AtlasX.exe (Electron shell)
├── Renderer: Vite-built React app (loaded from app/index.html)
└── Backend:  mars_backend.exe (PyInstaller – FastAPI/uvicorn on port 8765)
              Started automatically on launch, stopped on close
```

### Pre-built Releases

Download `AtlasX-Setup.exe` from the `release/` folder or the GitHub Releases page. Run the installer and launch from the Start Menu or Desktop shortcut.

**No additional runtime required** — Python, Node.js, and all dependencies are bundled.

---

### Building from Source

#### Prerequisites

| Tool | Version | Notes |
|------|---------|-------|
| Node.js | 20.x | Portable at `C:\Users\valiy\tools\node-v20.18.0-win-x64` |
| Python | 3.11–3.14 | System Python at `C:\Users\valiy\AppData\Local\Programs\Python\Python314` |
| pip packages | latest | `pip install pyinstaller pillow fastapi uvicorn httpx pydantic` |

#### One-command build

```powershell
# From project root
.\Build-Desktop.ps1
```

This runs all 4 stages automatically and outputs to `release/`.

#### Manual step-by-step

**1 — Install npm dependencies (one-time)**
```powershell
$env:PATH = "C:\Users\valiy\tools\node-v20.18.0-win-x64;$env:PATH"
npm install
```

**2 — Build Python backend**
```powershell
cd backend
python -m PyInstaller mars_backend.spec --clean --noconfirm
cd ..
# Output: backend/dist/mars_backend/mars_backend.exe  (~7–25 MB)
```

**3 — Build Vite frontend**
```powershell
$env:BUILD_TARGET = "electron"
npm run build
```

**4 — Prepare Electron bundle**
```powershell
node scripts/prepare-electron.mjs
# Copies dist/ → app/ and patches index.html for file:// paths
```

**5 — Create Windows installer**
```powershell
npm run electron:dist
# Output: release/AtlasX-Setup.exe  (NSIS installer)
#         release/AtlasX-*.exe       (portable executable)
```

---

### Development (browser mode)

The original browser-based development workflow is fully preserved:

```powershell
# Terminal 1 — frontend dev server
$env:PATH = "C:\Users\valiy\tools\node-v20.18.0-win-x64;$env:PATH"
npm run dev   # http://localhost:5173

# Terminal 2 — backend
cd backend
python main.py   # http://localhost:8000
```

### Development (Electron mode)

```powershell
$env:PATH = "C:\Users\valiy\tools\node-v20.18.0-win-x64;$env:PATH"
npm run electron:dev
# Starts Vite dev server + Electron window simultaneously
# Backend must be running separately (python backend/main.py)
```

---

### Port Configuration

| Context | Frontend | Backend |
|---------|----------|---------|
| Browser dev | :5173 | :8000 |
| Packaged Electron | `file://` | :8765 |

The frontend auto-detects which port to use based on `window.location.protocol`.

---

### Release Structure & Tested Sizes

```
release/
├── AtlasX-Setup.exe                  ← NSIS installer (~96 MB)
├── AtlasX 1.0.0.exe                  ← Portable standalone executable (~96 MB)
└── win-unpacked/                     ← Unpacked application folder (~178 MB)
    ├── AtlasX.exe
    └── resources/
        ├── app.asar                  ← Packaged React frontend (7.7 MB)
        └── backend/
            └── mars_backend/
                └── mars_backend.exe  ← Bundled FastAPI server (7.06 MB)
```

---

### Technical Highlights & Solved Challenges

1. **CommonJS & ES Module Harmony**: The application is an ES Module (`"type": "module"` in `package.json`), while Electron's main process relies on Node CommonJS APIs. We architected the Electron process using `electron/main.cjs` and `electron/preload.cjs`, completely avoiding runtime module resolution conflicts.
2. **Automated 7za macOS Symlink Workaround**: `electron-builder` downloads a macOS signing archive (`winCodeSign`) containing symlinks which Windows without Developer Mode rejects with exit code 2. We built an intelligent C# wrapper (`scripts/7za-wrapper.cs` compiled to `node_modules/7zip-bin/win/x64/7za.exe`) that detects 0-byte symlink placeholders, populates them with real library copies, and exits cleanly.
3. **Port Isolation & Collision Prevention**: In packaged mode, the backend binds to `http://127.0.0.1:8765` (dev uses `8000`), automatically checking and cleaning stale bindings before spawning.
4. **Windows 11 Smart App Control & Code Signing**: To ensure smooth execution on Windows 11 systems running Smart App Control (SAC), all release binaries are digitally signed with a SHA256 Authenticode certificate generated specifically for AtlasX.

