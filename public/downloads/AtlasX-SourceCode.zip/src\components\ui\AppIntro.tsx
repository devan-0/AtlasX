import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Volume2, VolumeX, Sparkles, ChevronRight, Rocket, Radio, Shield, Globe } from 'lucide-react';

interface AppIntroProps {
  onComplete: () => void;
}

// Synthesize pleasant sci-fi audio effects using native Web Audio API (zero external assets)
class IntroAudioEngine {
  private ctx: AudioContext | null = null;
  public enabled = true;

  private getContext(): AudioContext | null {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  playBootTone() {
    if (!this.enabled) return;
    try {
      const ctx = this.getContext();
      if (!ctx) return;

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(140, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(320, ctx.currentTime + 0.4);
      osc.frequency.exponentialRampToValueAtTime(580, ctx.currentTime + 0.8);

      gain.gain.setValueAtTime(0.001, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0.08, ctx.currentTime + 0.3);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.2);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 1.25);
    } catch {
      // Audio autoplay policy handled silently
    }
  }

  playStepTick() {
    if (!this.enabled) return;
    try {
      const ctx = this.getContext();
      if (!ctx) return;

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(780, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.05);

      gain.gain.setValueAtTime(0.015, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.05);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.05);
    } catch {
      // Audio autoplay policy handled silently
    }
  }

  playCompletionChime() {
    if (!this.enabled) return;
    try {
      const ctx = this.getContext();
      if (!ctx) return;

      const notes = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, ctx.currentTime + idx * 0.08);

        gain.gain.setValueAtTime(0.001, ctx.currentTime + idx * 0.08);
        gain.gain.linearRampToValueAtTime(0.05, ctx.currentTime + idx * 0.08 + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + idx * 0.08 + 0.6);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(ctx.currentTime + idx * 0.08);
        osc.stop(ctx.currentTime + idx * 0.08 + 0.65);
      });
    } catch {
      // Audio autoplay policy handled silently
    }
  }

  destroy() {
    if (this.ctx) {
      try {
        this.ctx.close().catch(() => {});
      } catch {
        // cleanup ignore
      }
      this.ctx = null;
    }
  }
}

const BOOT_STEPS = [
  { progress: 15, text: 'INITIALIZING ATLASX SURFACE INTELLIGENCE CORE...' },
  { progress: 35, text: 'CALIBRATING ORBITAL EPHEMERIS & AIRY-0 MERIDIAN...' },
  { progress: 55, text: 'INGESTING MOLA TOPOGRAPHY & USGS BASEMAP DATA...' },
  { progress: 75, text: 'SYNCHRONIZING MARS 2020 GEOLOGICAL & OUTCROP FEEDS...' },
  { progress: 92, text: 'VALIDATING 0.38G ASTRONAUT EVA PATHFINDING ARRAYS...' },
  { progress: 100, text: 'ATLASX READY — COMMENCING EXPLORATION' },
];

export default function AppIntro({ onComplete }: AppIntroProps) {
  const [progress, setProgress] = useState(0);
  const [activeStepText, setActiveStepText] = useState(BOOT_STEPS[0].text);
  const [isFadingOut, setIsFadingOut] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const audioRef = useRef<IntroAudioEngine | null>(null);

  const finishedRef = useRef(false);
  const activeStepTextRef = useRef(BOOT_STEPS[0].text);

  // Initialize audio engine
  useEffect(() => {
    const audio = new IntroAudioEngine();
    audioRef.current = audio;
    audio.playBootTone();

    return () => {
      audio.destroy();
    };
  }, []);

  const toggleSound = (e: React.MouseEvent) => {
    e.stopPropagation();
    setSoundEnabled(prev => {
      const next = !prev;
      if (audioRef.current) audioRef.current.enabled = next;
      return next;
    });
  };

  const handleFinish = useCallback(() => {
    if (finishedRef.current) return;
    finishedRef.current = true;
    setIsFadingOut(true);
    if (audioRef.current && soundEnabled) {
      audioRef.current.playCompletionChime();
    }
    // Wait for fade & scale animation to complete before unmounting
    setTimeout(() => {
      onComplete();
    }, 450);
  }, [onComplete, soundEnabled]);

  // Keyboard skip
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' || e.key === ' ' || e.key === 'Enter') {
        e.preventDefault();
        handleFinish();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleFinish]);

  // Autonomous progress driver: advances to 100% and automatically enters
  useEffect(() => {
    const startTime = Date.now();
    const duration = 2400; // 2.4 seconds smooth auto-intro

    const timer = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const pct = Math.min(100, Math.round((elapsed / duration) * 100));
      setProgress(pct);

      // Check current milestone step
      const currentStep = [...BOOT_STEPS].reverse().find(s => pct >= s.progress) || BOOT_STEPS[0];
      if (currentStep.text !== activeStepTextRef.current) {
        activeStepTextRef.current = currentStep.text;
        setActiveStepText(currentStep.text);
        if (pct < 100 && pct > 10 && audioRef.current && soundEnabled) {
          audioRef.current.playStepTick();
        }
      }

      if (pct >= 100) {
        clearInterval(timer);
        setTimeout(() => {
          handleFinish();
        }, 300);
      }
    }, 25);

    return () => clearInterval(timer);
  }, [handleFinish, soundEnabled]);

  return (
    <div
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#050913] select-none overflow-y-auto px-4 py-6 transition-all duration-500 ease-out
        ${isFadingOut ? 'opacity-0 scale-105 pointer-events-none' : 'opacity-100 scale-100'}`}
      style={{
        backgroundImage: `
          radial-gradient(circle at 50% 38%, rgba(232, 64, 32, 0.18) 0%, rgba(13, 20, 36, 0.85) 50%, rgba(5, 9, 19, 0.98) 100%),
          linear-gradient(rgba(255,255,255,0.02) 1px, transparent 1px),
          linear-gradient(90deg, rgba(255,255,255,0.02) 1px, transparent 1px)
        `,
        backgroundSize: '100% 100%, 32px 32px, 32px 32px',
      }}
    >
      {/* ── Background Cosmic Starfield Elements ── */}
      <div className="absolute inset-0 pointer-events-none opacity-40">
        <div className="absolute top-[15%] left-[20%] w-1.5 h-1.5 rounded-full bg-cyan-200 animate-pulse" />
        <div className="absolute top-[28%] right-[22%] w-1 h-1 rounded-full bg-amber-200 animate-ping" />
        <div className="absolute bottom-[30%] left-[12%] w-1.5 h-1.5 rounded-full bg-white opacity-60" />
        <div className="absolute top-[42%] right-[10%] w-2 h-2 rounded-full bg-orange-400 opacity-50 blur-[0.5px]" />
        <div className="absolute bottom-[18%] right-[30%] w-1 h-1 rounded-full bg-blue-300 opacity-80" />
        <div className="absolute top-[10%] left-[45%] w-1 h-1 rounded-full bg-amber-100 opacity-70" />
      </div>

      {/* ── Top Bar Controls ── */}
      <div className="w-full max-w-xl flex items-center justify-between mb-3 px-4 py-2 rounded-xl bg-slate-900/70 backdrop-blur-md border border-white/10 text-xs font-mono shadow-lg">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shadow-[0_0_8px_#34d399]" />
          <span className="text-slate-200 tracking-wider font-semibold text-[11px]">MISSION INITIALIZATION</span>
          <span className="text-white/20">|</span>
          <span className="text-cyan-300/90 text-[10px] hidden sm:inline">STANDALONE DESKTOP RUNTIME</span>
        </div>

        <button
          onClick={toggleSound}
          type="button"
          className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-white/10 hover:bg-white/20 active:scale-95 focus:outline-none focus:ring-2 focus:ring-cyan-400/50 border border-white/15 text-slate-200 transition-all cursor-pointer"
          title={soundEnabled ? 'Mute audio feedback' : 'Enable audio feedback'}
          aria-label={soundEnabled ? 'Mute audio' : 'Unmute audio'}
        >
          {soundEnabled ? <Volume2 size={13} className="text-cyan-400" /> : <VolumeX size={13} className="text-slate-400" />}
          <span className="text-[10px] uppercase font-bold tracking-wider">{soundEnabled ? 'Audio On' : 'Muted'}</span>
        </button>
      </div>

      {/* ── Central Translucent Glassmorphism Card ── */}
      <div className="relative max-w-xl w-full px-6 py-6 sm:px-8 sm:py-7 rounded-3xl bg-slate-950/80 backdrop-blur-2xl border border-white/15 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.85),0_0_35px_rgba(232,64,32,0.15)] flex flex-col items-center text-center overflow-hidden">
        {/* Subtle top interior glow line */}
        <div className="absolute top-0 left-12 right-12 h-px bg-gradient-to-r from-transparent via-orange-400/50 to-transparent" />

        {/* ── Orbital Rings & Mars Sphere ── */}
        <div className="relative w-40 h-40 sm:w-48 sm:h-48 flex items-center justify-center mb-4 flex-shrink-0">
          {/* Outer Atmospheric Bloom */}
          <div className="absolute inset-0 rounded-full bg-orange-600/20 blur-2xl animate-pulse" />

          {/* Rotating Outer Gyro Ring */}
          <svg className="absolute inset-0 w-full h-full animate-[spin_24s_linear_infinite]" viewBox="0 0 200 200">
            <circle
              cx="100"
              cy="100"
              r="92"
              fill="none"
              stroke="#e84020"
              strokeWidth="1.2"
              strokeDasharray="6 8 2 8"
              opacity="0.55"
            />
            <circle cx="100" cy="8" r="3.5" fill="#22d3ee" className="drop-shadow-[0_0_8px_#22d3ee]" />
          </svg>

          {/* Counter-Rotating Middle Metric Ring */}
          <svg className="absolute inset-2 w-[calc(100%-16px)] h-[calc(100%-16px)] animate-[spin_18s_linear_infinite_reverse]" viewBox="0 0 180 180">
            <circle
              cx="90"
              cy="90"
              r="82"
              fill="none"
              stroke="#38bdf8"
              strokeWidth="1"
              strokeDasharray="4 12"
              opacity="0.4"
            />
            <line x1="90" y1="2" x2="90" y2="12" stroke="#38bdf8" strokeWidth="2" opacity="0.9" />
            <line x1="90" y1="168" x2="90" y2="178" stroke="#38bdf8" strokeWidth="2" opacity="0.9" />
            <line x1="2" y1="90" x2="12" y2="90" stroke="#38bdf8" strokeWidth="2" opacity="0.9" />
            <line x1="168" y1="90" x2="178" y2="90" stroke="#38bdf8" strokeWidth="2" opacity="0.9" />
          </svg>

          {/* HUD Targeting Brackets */}
          <div className="absolute inset-3 pointer-events-none">
            <div className="absolute top-0 left-0 w-3.5 h-3.5 border-t-2 border-l-2 border-orange-400" />
            <div className="absolute top-0 right-0 w-3.5 h-3.5 border-t-2 border-r-2 border-orange-400" />
            <div className="absolute bottom-0 left-0 w-3.5 h-3.5 border-b-2 border-l-2 border-orange-400" />
            <div className="absolute bottom-0 right-0 w-3.5 h-3.5 border-b-2 border-r-2 border-orange-400" />
          </div>

          {/* Core Mars Holographic Sphere */}
          <div className="relative w-24 h-24 sm:w-28 sm:h-28 rounded-full overflow-hidden shadow-[0_0_35px_rgba(232,64,32,0.6)] border border-orange-400/50 flex items-center justify-center">
            <div
              className="absolute inset-0"
              style={{
                background: 'radial-gradient(circle at 35% 32%, #ff7a45 0%, #c83d1c 45%, #7a1f0a 80%, #300802 100%)',
              }}
            />
            <div className="absolute top-1 left-1/2 -translate-x-1/2 w-9 h-3 bg-amber-100/80 rounded-full blur-[1px]" />
            <div className="absolute top-1/2 left-3 right-4 h-1.5 bg-[#420f04] rounded-full blur-[1px] opacity-75 rotate-[-4deg]" />
            <div className="absolute inset-0 rounded-full border-2 border-orange-400/40 shadow-[inset_0_0_15px_rgba(255,140,80,0.6)]" />

            <div className="relative z-10 w-10 h-10 rounded-xl bg-black/50 backdrop-blur-sm border border-white/30 flex items-center justify-center shadow-lg">
              <Rocket size={22} className="text-orange-200 drop-shadow-[0_0_8px_rgba(249,115,22,0.9)]" />
            </div>
          </div>
        </div>

        {/* ── Identity & Typography ── */}
        <div className="space-y-2 max-w-lg">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-orange-500/15 border border-orange-400/30 text-[11px] font-mono tracking-widest text-orange-200 uppercase">
            <Sparkles size={12} className="text-amber-400 animate-spin" style={{ animationDuration: '6s' }} />
            <span className="font-semibold">Planetary Cartography &amp; Surface Intelligence</span>
          </div>

          <h1 className="text-4xl sm:text-5xl font-black tracking-[0.25em] text-white leading-none font-mono drop-shadow-[0_4px_24px_rgba(0,0,0,0.9)]">
            ATLAS<span className="text-[#ff5722] drop-shadow-[0_0_25px_rgba(255,87,34,0.9)]">X</span>
          </h1>

          <p className="text-xs sm:text-sm font-medium tracking-wide text-slate-200 pt-1 leading-relaxed">
            AtlasX – An Advanced Planetary Exploration, Surface Intelligence and Mission Planning Platform.
          </p>
        </div>

        {/* ── Boot Progress & Telemetry Feed ── */}
        <div className="w-full mt-6 space-y-2">
          <div className="flex items-center justify-between text-xs font-mono">
            <span className="flex items-center gap-1.5 text-cyan-200 truncate max-w-[340px]">
              <Radio size={13} className="text-cyan-400 animate-pulse flex-shrink-0" />
              <span className="truncate font-medium">{activeStepText}</span>
            </span>
            <span className="font-bold text-amber-300 text-sm tabular-nums ml-2 flex-shrink-0">{progress}%</span>
          </div>

          {/* Progress Track */}
          <div className="relative w-full h-2 bg-slate-900/90 rounded-full overflow-hidden border border-white/15 p-0.5">
            <div
              className="h-full bg-gradient-to-r from-cyan-400 via-amber-400 to-[#ff5722] transition-all duration-75 ease-out rounded-full shadow-[0_0_12px_rgba(255,87,34,0.8)]"
              style={{ width: `${progress}%` }}
            />
          </div>

          {/* Status Sub-Badges */}
          <div className="grid grid-cols-3 gap-2 pt-1 text-[10px] font-mono font-medium text-slate-300">
            <div className="bg-white/5 border border-white/10 rounded px-2 py-1 truncate">VERSION 1.0.0</div>
            <div className="bg-white/5 border border-white/10 rounded px-2 py-1 truncate">AIRY-0 MERIDIAN</div>
            <div className="bg-white/5 border border-white/10 rounded px-2 py-1 truncate">MOLA ELEVATION</div>
          </div>
        </div>

        {/* ── Interactive Launch Button with Focus, Hover, Active States ── */}
        <div className="mt-5 w-full flex flex-col items-center gap-2.5">
          <button
            onClick={handleFinish}
            type="button"
            className="w-full sm:w-auto px-6 py-2.5 rounded-xl font-mono text-xs font-bold uppercase tracking-wider text-white bg-gradient-to-r from-orange-600 via-mars-600 to-amber-600 hover:from-orange-500 hover:via-mars-500 hover:to-amber-500 active:scale-[0.98] focus:outline-none focus:ring-2 focus:ring-orange-400 focus:ring-offset-2 focus:ring-offset-slate-950 shadow-[0_4px_16px_rgba(232,64,32,0.4)] hover:shadow-[0_6px_20px_rgba(232,64,32,0.6)] transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <span>{progress < 100 ? 'Skip to Mission Control' : 'Enter Mission Control'}</span>
            <ChevronRight size={14} className="text-white" />
          </button>

          <div className="flex items-center gap-2 text-[11px] font-mono text-slate-300">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span>Autonomous initialization · Auto-advancing</span>
          </div>
        </div>

        {/* ── Formal Affiliation & Legal Disclaimer ── */}
        <div className="mt-4 pt-3 border-t border-white/10 text-[10px] sm:text-[11px] text-slate-300/90 text-center leading-relaxed">
          AtlasX is an independent educational and research project. It is not affiliated with, endorsed by, or officially associated with NASA or any other space agency.
        </div>
      </div>

      {/* ── Bottom Corner Coordinates HUD ── */}
      <div className="w-full max-w-xl flex items-center justify-between mt-3 px-4 text-[10px] font-mono text-slate-400">
        <div className="flex items-center gap-2">
          <span>TARGET: MARS</span>
          <span>·</span>
          <span>DATUM: AREOID IAU 2000</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
          <span>DE441 EPHEMERIS</span>
        </div>
      </div>
    </div>
  );
}
