// AtlasX — Astronaut Physiological & Survival Telemetry HUD
// Real-time biometrics, suited metabolic expenditure under Martian gravity (0.38g),
// life-support consumables, and Point of No Return (PNR) margin tracking.

import React, { useState, useEffect } from 'react';
import {
  Heart,
  Activity,
  Wind,
  Battery,
  AlertTriangle,
  ShieldAlert,
  ShieldCheck,
  CheckCircle2,
  Clock,
  Compass,
  Thermometer,
  Droplets,
  ChevronDown,
  ChevronUp,
  RotateCcw,
} from 'lucide-react';
import { useAppStore } from '../../store/useAppStore';
import { getLiveAstronautBioState, PRIMARY_O2_CAPACITY_LITERS } from '../../utils/evaBiometrics';
import { computeEVAMeteorologicalAdvisory } from '../../utils/evaWeatherHazard';
import GlassPanel from '../ui/GlassPanel';
import DataBadge from '../ui/DataBadge';

interface EVAHUDProps {
  compact?: boolean;
  className?: string;
}

export const EVAHUD: React.FC<EVAHUDProps> = ({ compact = false, className = '' }) => {
  const { theme, selectedRegion } = useAppStore();
  const isBright = theme === 'bright';

  const [elapsedMinutes, setElapsedMinutes] = useState(65);
  const [currentSlope, setCurrentSlope] = useState(6);
  const [activityMode, setActivityMode] = useState<'rest' | 'traverse' | 'sampling' | 'ascent'>('traverse');
  const [isSimulating, setIsSimulating] = useState(true);
  const [expanded, setExpanded] = useState(!compact);

  // Live timer tick for physiological simulation
  useEffect(() => {
    if (!isSimulating) return;
    const interval = setInterval(() => {
      setElapsedMinutes((prev) => (prev >= 480 ? 30 : prev + 1));
    }, 4000);
    return () => clearInterval(interval);
  }, [isSimulating]);

  const { bio, suit, survival } = getLiveAstronautBioState(elapsedMinutes, currentSlope, activityMode);
  const weather = computeEVAMeteorologicalAdvisory({
    sol: 1180,
    temperatureK: 215,
    dustOpticalDepth: 0.58,
    windSpeedMs: 6.8,
  });

  const getStatusBadge = () => {
    if (survival.evaStatus === 'ABORT_HAZARDOUS') {
      return (
        <span className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-red-500/20 border border-red-500/40 text-red-400 font-mono text-xs font-bold animate-pulse">
          <ShieldAlert size={14} /> ABORT / HAZARD
        </span>
      );
    }
    if (survival.evaStatus === 'CAUTION_MARGINAL') {
      return (
        <span className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-amber-500/20 border border-amber-500/40 text-amber-400 font-mono text-xs font-bold">
          <AlertTriangle size={14} /> CAUTION (PNR APPROACH)
        </span>
      );
    }
    return (
      <span className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 font-mono text-xs font-bold">
        <ShieldCheck size={14} /> GO (NOMINAL EVA)
      </span>
    );
  };

  const o2Percent = Math.round((suit.o2TimeRemainingMinutes / (PRIMARY_O2_CAPACITY_LITERS / bio.vo2LitersPerMin)) * 100);

  return (
    <div className={`space-y-3 ${className}`}>
      {/* Header bar */}
      <div className={`p-3 rounded-lg border backdrop-blur-md flex flex-wrap items-center justify-between gap-3 ${
        isBright ? 'bg-white/90 border-slate-200 shadow-sm' : 'bg-black/60 border-white/10'
      }`}>
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-red-500/15 border border-red-500/30 flex items-center justify-center">
            <Heart className="w-5 h-5 text-red-500 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className={`text-sm font-bold tracking-wide uppercase ${isBright ? 'text-slate-900' : 'text-white'}`}>
                Astronaut EVA Survival Telemetry
              </span>
              <DataBadge classification="modelled" />
            </div>
            <p className={`text-[11px] font-mono ${isBright ? 'text-slate-500' : 'text-slate-400'}`}>
              Mars Gravity: 0.38g | Suited Mass: 200 kg | Elapsed EVA: {Math.floor(elapsedMinutes / 60)}h {elapsedMinutes % 60}m
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {getStatusBadge()}
          <button
            onClick={() => setExpanded(!expanded)}
            className={`p-1.5 rounded border transition-colors ${
              isBright ? 'border-slate-300 text-slate-600 hover:bg-slate-100' : 'border-white/10 text-white/70 hover:bg-white/5'
            }`}
            title={expanded ? 'Collapse HUD' : 'Expand HUD'}
          >
            {expanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
          </button>
        </div>
      </div>

      {expanded && (
        <>
          {/* Activity selector & slope controls */}
          <div className={`p-2.5 rounded-lg border flex flex-wrap items-center justify-between gap-3 text-xs ${
            isBright ? 'bg-slate-50 border-slate-200' : 'bg-navy-950/40 border-white/5'
          }`}>
            <div className="flex items-center gap-1.5">
              <span className={`font-mono uppercase text-[10px] ${isBright ? 'text-slate-500' : 'text-slate-400'}`}>Activity:</span>
              {(['rest', 'traverse', 'sampling', 'ascent'] as const).map((mode) => (
                <button
                  key={mode}
                  onClick={() => setActivityMode(mode)}
                  className={`px-2.5 py-1 rounded text-[11px] font-mono capitalize transition-all ${
                    activityMode === mode
                      ? 'bg-mars-orange text-white font-bold shadow'
                      : isBright
                      ? 'text-slate-600 hover:bg-slate-200'
                      : 'text-slate-400 hover:bg-white/5'
                  }`}
                >
                  {mode}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-3 font-mono text-[11px]">
              <span className={isBright ? 'text-slate-600' : 'text-slate-400'}>
                Local Slope: <strong className="text-amber-400">{currentSlope}°</strong>
              </span>
              <input
                type="range"
                min={0}
                max={25}
                value={currentSlope}
                onChange={(e) => setCurrentSlope(parseInt(e.target.value))}
                className="w-24 accent-amber-400 h-1 cursor-pointer"
              />
              <button
                onClick={() => setElapsedMinutes(45)}
                className={`p-1 rounded text-slate-400 hover:text-white transition-colors`}
                title="Reset simulation time"
              >
                <RotateCcw size={12} />
              </button>
            </div>
          </div>

          {/* Biometrics & Consumables Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {/* Heart Rate & Metabolism */}
            <div className={`p-3 rounded-lg border ${
              isBright ? 'bg-white border-slate-200' : 'bg-black/40 border-white/5'
            }`}>
              <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                <span className="flex items-center gap-1 font-mono text-[10px] uppercase">
                  <Activity size={12} className="text-red-400" /> Heart Rate
                </span>
                <span className="font-mono text-red-400 text-sm font-bold">{bio.heartRateBpm} bpm</span>
              </div>
              <div className="w-full bg-slate-700/30 h-1.5 rounded-full overflow-hidden mb-2">
                <div
                  className="bg-red-500 h-full rounded-full transition-all"
                  style={{ width: `${Math.min(100, (bio.heartRateBpm / 180) * 100)}%` }}
                />
              </div>
              <div className="flex justify-between text-[11px] font-mono">
                <span className={isBright ? 'text-slate-500' : 'text-slate-400'}>Metabolic Rate:</span>
                <span className={`font-bold ${isBright ? 'text-slate-800' : 'text-slate-200'}`}>
                  {bio.metabolicRateWatts} W
                </span>
              </div>
              <div className="flex justify-between text-[11px] font-mono mt-0.5">
                <span className={isBright ? 'text-slate-500' : 'text-slate-400'}>Core Temp:</span>
                <span className="text-amber-400 font-bold">{bio.bodyCoreTempC}°C</span>
              </div>
            </div>

            {/* Oxygen Reserves */}
            <div className={`p-3 rounded-lg border ${
              isBright ? 'bg-white border-slate-200' : 'bg-black/40 border-white/5'
            }`}>
              <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                <span className="flex items-center gap-1 font-mono text-[10px] uppercase">
                  <Wind size={12} className="text-cyan-400" /> Primary O2 Tank
                </span>
                <span className="font-mono text-cyan-400 text-sm font-bold">{suit.o2TankPressureBar} bar</span>
              </div>
              <div className="w-full bg-slate-700/30 h-1.5 rounded-full overflow-hidden mb-2">
                <div
                  className={`h-full rounded-full transition-all ${
                    suit.o2TimeRemainingMinutes < 60 ? 'bg-red-500' : 'bg-cyan-400'
                  }`}
                  style={{ width: `${Math.min(100, Math.max(5, (suit.o2TankPressureBar / 200) * 100))}%` }}
                />
              </div>
              <div className="flex justify-between text-[11px] font-mono">
                <span className={isBright ? 'text-slate-500' : 'text-slate-400'}>Time Remaining:</span>
                <span className="text-cyan-300 font-bold">{suit.o2TimeRemainingMinutes} min</span>
              </div>
              <div className="flex justify-between text-[11px] font-mono mt-0.5">
                <span className={isBright ? 'text-slate-500' : 'text-slate-400'}>VO2 Rate:</span>
                <span className={`font-bold ${isBright ? 'text-slate-800' : 'text-slate-200'}`}>
                  {bio.vo2LitersPerMin} L/min
                </span>
              </div>
            </div>

            {/* Battery & LiOH Scrubber */}
            <div className={`p-3 rounded-lg border ${
              isBright ? 'bg-white border-slate-200' : 'bg-black/40 border-white/5'
            }`}>
              <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                <span className="flex items-center gap-1 font-mono text-[10px] uppercase">
                  <Battery size={12} className="text-emerald-400" /> Suit Battery
                </span>
                <span className="font-mono text-emerald-400 text-sm font-bold">{suit.batteryChargePercent}%</span>
              </div>
              <div className="w-full bg-slate-700/30 h-1.5 rounded-full overflow-hidden mb-2">
                <div
                  className={`h-full rounded-full transition-all ${
                    suit.batteryChargePercent < 25 ? 'bg-red-500' : 'bg-emerald-400'
                  }`}
                  style={{ width: `${suit.batteryChargePercent}%` }}
                />
              </div>
              <div className="flex justify-between text-[11px] font-mono">
                <span className={isBright ? 'text-slate-500' : 'text-slate-400'}>Runtime:</span>
                <span className="text-emerald-300 font-bold">{suit.batteryRemainingMinutes} min</span>
              </div>
              <div className="flex justify-between text-[11px] font-mono mt-0.5">
                <span className={isBright ? 'text-slate-500' : 'text-slate-400'}>LiOH Saturation:</span>
                <span className={`font-bold ${suit.liohCanisterSaturationPercent > 80 ? 'text-red-400' : isBright ? 'text-slate-800' : 'text-slate-200'}`}>
                  {suit.liohCanisterSaturationPercent}%
                </span>
              </div>
            </div>

            {/* Point of No Return & PNR Radius */}
            <div className={`p-3 rounded-lg border ${
              isBright ? 'bg-white border-slate-200' : 'bg-black/40 border-white/5'
            }`}>
              <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                <span className="flex items-center gap-1 font-mono text-[10px] uppercase">
                  <Compass size={12} className="text-violet-400" /> Safe PNR Radius
                </span>
                <span className="font-mono text-violet-400 text-sm font-bold">
                  {survival.pointOfNoReturnRadiusKm} km
                </span>
              </div>
              <div className="w-full bg-slate-700/30 h-1.5 rounded-full overflow-hidden mb-2">
                <div
                  className="bg-violet-400 h-full rounded-full transition-all"
                  style={{ width: `${Math.min(100, (survival.pointOfNoReturnRadiusKm / 5) * 100)}%` }}
                />
              </div>
              <div className="flex justify-between text-[11px] font-mono">
                <span className={isBright ? 'text-slate-500' : 'text-slate-400'}>Turnaround Time:</span>
                <span className="text-violet-300 font-bold">{survival.pointOfNoReturnTimeMinutes} min</span>
              </div>
              <div className="flex justify-between text-[11px] font-mono mt-0.5">
                <span className={isBright ? 'text-slate-500' : 'text-slate-400'}>Emergency Reserve:</span>
                <span className="text-amber-400 font-bold">+{suit.secondaryO2ReserveMinutes} min safe</span>
              </div>
            </div>
          </div>

          {/* Warnings & Meteorological Advisory Banner */}
          {survival.activeWarnings.length > 0 && (
            <div className="p-2.5 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-300 flex items-start gap-2">
              <AlertTriangle size={14} className="flex-shrink-0 mt-0.5 text-red-400" />
              <div className="space-y-0.5">
                {survival.activeWarnings.map((w, idx) => (
                  <div key={idx} className="font-mono font-medium">{w}</div>
                ))}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default EVAHUD;
