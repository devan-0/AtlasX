# AtlasX — Start Backend API
# Automatically kills any existing process on port 8000 before starting.

$PORT = 8000

Write-Host "AtlasX — Backend API" -ForegroundColor Cyan
Write-Host "Real-time data: JPL Horizons + NASA InSight" -ForegroundColor DarkGray
Write-Host ""

# Kill any existing process occupying port 8000
$existing = netstat -ano | Select-String ":$PORT\s.*LISTENING" | ForEach-Object {
    ($_ -split '\s+')[-1]
} | Select-Object -First 1

if ($existing -and $existing -ne '0') {
    Write-Host "Stopping existing process on port $PORT (PID $existing)..." -ForegroundColor Yellow
    taskkill /PID $existing /F 2>$null | Out-Null
    Start-Sleep -Milliseconds 800
    Write-Host "Stopped." -ForegroundColor Green
}

Write-Host "Starting backend on http://127.0.0.1:$PORT ..." -ForegroundColor Green
Write-Host "(Press Ctrl+C to stop)" -ForegroundColor DarkGray
Write-Host ""

Set-Location "$PSScriptRoot\backend"
python main.py
