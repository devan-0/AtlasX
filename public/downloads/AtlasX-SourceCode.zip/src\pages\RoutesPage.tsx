import React, { useState, useMemo } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { useAppStore } from '../store/useAppStore';
import { SCIENCE_TARGETS } from '../data/sampleData';
import {
  generateTerrainGrid,
  aStarPath,
  buildRoute,
  closestCell,
  DEFAULT_WEIGHTS,
  LOWER_RISK_WEIGHTS,
  SCIENCE_PRIORITY_WEIGHTS,
  ASTRONAUT_EVA_WEIGHTS,
} from '../utils/routePlanning';
import DataBadge from '../components/ui/DataBadge';
import GlassPanel from '../components/ui/GlassPanel';
import EVAHUD from '../components/survival/EVAHUD';
import { Route, AlertTriangle, Minus, Heart, Compass, ShieldCheck } from 'lucide-react';
import type { RouteType, Route as RouteObj } from '../types';

const ROUTE_TYPE_CONFIG: Record<RouteType, { label: string; color: string; desc: string }> = {
  'shortest': { label: 'Shortest Distance', color: '#22d3ee', desc: 'Minimize path length. Higher slope tolerance.' },
  'lower-risk': { label: 'Lower Risk', color: '#4ade80', desc: 'Avoid hazards and steep slopes. Safer traverse.' },
  'science-priority': { label: 'Science Priority', color: '#a78bfa', desc: 'Route via high-value science targets.' },
  'astronaut-eva': { label: 'Astronaut EVA (Life-Support Optimal)', color: '#f59e0b', desc: 'Calibrated for 0.38g human walking, O2 conservation, low metabolic wattage & PNR safety margin.' },
};

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="glass-panel p-2 text-xs space-y-0.5">
      <div className="text-slate-400">Distance: {typeof label === 'number' ? label.toFixed(2) : label} km</div>
      <div className="text-orange-400">Elevation: {payload[0]?.value?.toFixed(0)} m</div>
    </div>
  );
};

export default function RoutesPage() {
  const { selectedRegion, routes, addRoute, removeRoute, activeRouteId, setActiveRoute, scienceTargets, theme } = useAppStore();
  const isBright = theme === 'bright';
  const [startLat, setStartLat] = useState(selectedRegion.boundingBox.north - 0.3);
  const [startLon, setStartLon] = useState(selectedRegion.boundingBox.west + 0.3);
  const [endLat, setEndLat] = useState(selectedRegion.boundingBox.south + 0.3);
  const [endLon, setEndLon] = useState(selectedRegion.boundingBox.east - 0.3);
  const [maxSlope, setMaxSlope] = useState(25);
  const [selectedTargets, setSelectedTargets] = useState<string[]>([]);
  const [generating, setGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const activeRoute = routes.find(r => r.id === activeRouteId);

  const handleGenerate = async () => {
    setGenerating(true);
    setError(null);
    try {
      await new Promise(r => setTimeout(r, 80));
      const bb = selectedRegion.boundingBox;
      const grid = generateTerrainGrid(bb.north, bb.south, bb.east, bb.west, 32);

      const start = { lat: startLat, lon: startLon };
      const end = { lat: endLat, lon: endLon };
      const [sR, sC] = closestCell(grid, start.lat, start.lon);
      const [eR, eC] = closestCell(grid, end.lat, end.lon);

      const configs: { type: RouteType; weights: typeof DEFAULT_WEIGHTS }[] = [
        { type: 'shortest', weights: DEFAULT_WEIGHTS },
        { type: 'lower-risk', weights: LOWER_RISK_WEIGHTS },
        { type: 'science-priority', weights: SCIENCE_PRIORITY_WEIGHTS },
        { type: 'astronaut-eva', weights: ASTRONAUT_EVA_WEIGHTS },
      ];

      for (const { type, weights } of configs) {
        const path = aStarPath(grid, sR, sC, eR, eC, weights, maxSlope);
        if (path.length < 2) { setError(`No valid path for ${type}. Try adjusting constraints.`); continue; }
        const id = `route-${type}-${Date.now()}`;
        const labels: Record<RouteType, string> = {
          'shortest': 'Shortest Distance Route',
          'lower-risk': 'Lower Risk Route',
          'science-priority': 'Science Priority Route',
          'astronaut-eva': 'Astronaut EVA Life-Support Optimal Route',
        };
        const route = buildRoute(id, labels[type], type, path, grid, weights);
        addRoute(route);
      }
    } catch (e) {
      setError('Route computation failed: ' + (e instanceof Error ? e.message : String(e)));
    } finally {
      setGenerating(false);
    }
  };

  const profileData = useMemo(() => {
    if (!activeRoute?.profile) return [];
    return activeRoute.profile.map((p, i) => ({
      dist: (i * activeRoute.totalDistance / activeRoute.profile.length).toFixed(2),
      elev: p.elevation,
    }));
  }, [activeRoute]);

  // Simple SVG route visualization
  const RouteViz = ({ route }: { route: RouteObj }) => {
    const col = ROUTE_TYPE_CONFIG[route.type]?.color ?? '#888';
    const bb = selectedRegion.boundingBox;
    const W = 280, H = 180;
    const toXY = (lat: number, lon: number) => ({
      x: ((lon - bb.west) / (bb.east - bb.west)) * W,
      y: H - ((lat - bb.south) / (bb.north - bb.south)) * H,
    });
    const pts = route.profile.map(p => toXY(p.lat, p.lon));
    const pathD = pts.map((p, i) => `${i === 0 ? 'M' : 'L'}${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' ');
    return (
      <svg width={W} height={H} className="bg-navy-900/50 rounded border border-white/5">
        {/* Slope heatmap background (simplified) */}
        {Array.from({ length: 10 }, (_, i) =>
          Array.from({ length: 10 }, (_, j) => {
            const slopeFake = Math.sin(i * 0.8 + j * 0.6) * 0.5 + 0.5;
            const col2 = `rgba(${Math.round(slopeFake * 220)}, ${Math.round((1 - slopeFake) * 80)}, 30, 0.18)`;
            return <rect key={`${i}-${j}`} x={j * W / 10} y={i * H / 10} width={W / 10} height={H / 10} fill={col2} />;
          })
        )}
        {/* Hazard circles */}
        {[{ x: W * 0.3, y: H * 0.4 }, { x: W * 0.6, y: H * 0.7 }].map((h, i) => (
          <circle key={i} cx={h.x} cy={h.y} r={14} fill="rgba(239,68,68,0.15)" stroke="#ef4444" strokeWidth={1} />
        ))}
        {/* Route path */}
        {pts.length > 1 && <path d={pathD} fill="none" stroke={col} strokeWidth={2.5} strokeLinejoin="round" opacity={0.9} />}
        {/* Start/end */}
        {pts[0] && <circle cx={pts[0].x} cy={pts[0].y} r={5} fill="#22d3ee" />}
        {pts[pts.length - 1] && <circle cx={pts[pts.length - 1].x} cy={pts[pts.length - 1].y} r={5} fill="#f59e0b" />}
      </svg>
    );
  };

  const hazardColor = (n: number) => n === 0 ? 'text-emerald-400' : n <= 2 ? 'text-amber-400' : 'text-red-400';

  return (
    <div className="flex h-full overflow-hidden">
      {/* Left panel */}
      <div className="w-80 flex-shrink-0 flex flex-col gap-3 p-3 border-r border-white/5 overflow-y-auto bg-navy-900/60">
        {/* Disclaimer */}
        <div className="flex items-start gap-2 p-2 rounded bg-orange-500/10 border border-orange-500/20 text-[10px] text-orange-300">
          <AlertTriangle size={12} className="flex-shrink-0 mt-0.5" />
          <span>Routes use A* pathfinding on synthetic terrain. NOT certified safe routes for human use.</span>
        </div>

        {/* Start/End */}
        <GlassPanel title="Waypoints" className="!p-3">
          <div className="space-y-2">
            <div>
              <div className="text-[10px] text-emerald-400 font-mono uppercase mb-1">● Start</div>
              <div className="grid grid-cols-2 gap-1">
                <div>
                  <span className="text-[9px] text-slate-500">LAT</span>
                  <input type="number" step={0.01} value={startLat}
                    onChange={e => setStartLat(parseFloat(e.target.value))}
                    className="w-full bg-navy-900 border border-white/10 rounded px-1.5 py-1 text-xs text-slate-200 font-mono" />
                </div>
                <div>
                  <span className="text-[9px] text-slate-500">LON</span>
                  <input type="number" step={0.01} value={startLon}
                    onChange={e => setStartLon(parseFloat(e.target.value))}
                    className="w-full bg-navy-900 border border-white/10 rounded px-1.5 py-1 text-xs text-slate-200 font-mono" />
                </div>
              </div>
            </div>
            <div>
              <div className="text-[10px] text-amber-400 font-mono uppercase mb-1">● End</div>
              <div className="grid grid-cols-2 gap-1">
                <div>
                  <span className="text-[9px] text-slate-500">LAT</span>
                  <input type="number" step={0.01} value={endLat}
                    onChange={e => setEndLat(parseFloat(e.target.value))}
                    className="w-full bg-navy-900 border border-white/10 rounded px-1.5 py-1 text-xs text-slate-200 font-mono" />
                </div>
                <div>
                  <span className="text-[9px] text-slate-500">LON</span>
                  <input type="number" step={0.01} value={endLon}
                    onChange={e => setEndLon(parseFloat(e.target.value))}
                    className="w-full bg-navy-900 border border-white/10 rounded px-1.5 py-1 text-xs text-slate-200 font-mono" />
                </div>
              </div>
            </div>
          </div>
        </GlassPanel>

        {/* Constraints */}
        <GlassPanel title="Constraints" className="!p-3">
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-400">Max slope</span>
              <span className="font-mono text-orange-400">{maxSlope}°</span>
            </div>
            <input type="range" min={5} max={35} value={maxSlope}
              onChange={e => setMaxSlope(parseInt(e.target.value))}
              className="w-full h-1.5 accent-orange-500" />
            <div className="flex justify-between text-[9px] text-slate-600 mt-0.5">
              <span>5° (safest)</span><span>35° (extreme)</span>
            </div>
          </div>
        </GlassPanel>

        {/* Science waypoints */}
        <GlassPanel title="Science Waypoints" className="!p-3">
          <div className="space-y-1 max-h-36 overflow-y-auto">
            {SCIENCE_TARGETS.map(t => (
              <label key={t.id} className="flex items-center gap-2 cursor-pointer">
                <input type="checkbox"
                  checked={selectedTargets.includes(t.id)}
                  onChange={e => setSelectedTargets(prev =>
                    e.target.checked ? [...prev, t.id] : prev.filter(x => x !== t.id)
                  )}
                  className="w-3 h-3 accent-violet-400" />
                <span className="text-xs text-slate-300 truncate">{t.name}</span>
                <span className="text-[9px] text-slate-500 flex-shrink-0">P{t.priority}</span>
              </label>
            ))}
          </div>
        </GlassPanel>

        {/* Cost function info */}
        <div className={`p-2 rounded border text-[10px] space-y-1 ${
          isBright ? 'bg-blue-50 border-blue-200 text-blue-900' : 'bg-blue-500/10 border-blue-500/20 text-blue-300'
        }`}>
          <div className="font-semibold">Curiosity / Perseverance Traverse Cost Function</div>
          <div>Total = distance × w₁ + nonLinearSlope × w₂ + hazard × w₃ + soilSlip × w₄ − science × w₅</div>
          <div className={isBright ? 'text-slate-600' : 'text-slate-400'}>
            Incorporates Martian 0.38g gravity, suited metabolic cost, and wheel slip thresholds (&gt;15° penalty).
          </div>
        </div>

        {/* Generate button */}
        <button
          onClick={handleGenerate}
          disabled={generating}
          className="w-full py-2.5 bg-mars-600 hover:bg-mars-500 disabled:opacity-50 text-white text-sm font-semibold rounded-lg transition-colors flex items-center justify-center gap-2 shadow"
        >
          {generating ? <><div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /> Computing 4 Traverses…</> : <><Route size={14} /> Generate 4 Traverses</>}
        </button>

        {error && (
          <div className="p-2 rounded bg-red-500/10 border border-red-500/20 text-xs text-red-400">{error}</div>
        )}
      </div>

      {/* Right panel */}
      <div className="flex-1 flex flex-col gap-3 p-3 overflow-y-auto">
        {/* Real-time Astronaut EVA Telemetry HUD */}
        <EVAHUD compact />

        {routes.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center text-center gap-3 py-10">
            <div className="w-16 h-16 rounded-full bg-mars-600/10 border border-mars-600/20 flex items-center justify-center">
              <Route size={28} className="text-mars-400" />
            </div>
            <div className={`text-sm font-bold ${isBright ? 'text-slate-900' : 'text-slate-300'}`}>No traverses generated yet</div>
            <div className="text-slate-500 text-xs max-w-sm">
              Click <strong>Generate 4 Traverses</strong> to compute Shortest, Lower Risk, Science Priority, and Astronaut EVA (Life-Support Optimal) paths using Curiosity & Perseverance routing algorithms.
            </div>
          </div>
        ) : (
          <>
            {/* Route cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-3">
              {routes.map(route => {
                const cfg = ROUTE_TYPE_CONFIG[route.type] || { label: route.type, color: '#888', desc: '' };
                const isActive = route.id === activeRouteId;
                return (
                  <div
                    key={route.id}
                    onClick={() => setActiveRoute(route.id)}
                    className={`glass-panel p-3 cursor-pointer transition-all ${isActive ? 'border-2' : 'hover:border-white/20'}`}
                    style={isActive ? { borderColor: cfg.color } : {}}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <div className="flex items-center gap-1.5">
                        <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: cfg.color }} />
                        <span className={`text-xs font-bold truncate ${isBright ? 'text-slate-900' : 'text-slate-100'}`}>{cfg.label}</span>
                      </div>
                      <button onClick={e => { e.stopPropagation(); removeRoute(route.id); }}
                        className="text-slate-500 hover:text-red-400 transition-colors">
                        <Minus size={12} />
                      </button>
                    </div>
                    <div className="text-[10px] text-slate-500 mb-2 line-clamp-2">{cfg.desc}</div>

                    <div className="grid grid-cols-2 gap-1 text-[11px] mb-2">
                      <div><span className="text-slate-500">Distance </span><span className={`font-mono ${isBright ? 'text-slate-800 font-semibold' : 'text-slate-200'}`}>{route.totalDistance.toFixed(2)} km</span></div>
                      <div><span className="text-slate-500">Duration </span><span className={`font-mono ${isBright ? 'text-slate-800 font-semibold' : 'text-slate-200'}`}>{route.estimatedDuration.toFixed(1)} h</span></div>
                      <div><span className="text-slate-500">Max slope </span><span className="font-mono text-orange-400">{route.maxSlope.toFixed(1)}°</span></div>
                      <div><span className="text-slate-500">Hazards </span><span className={`font-mono ${hazardColor(route.hazardCount)}`}>{route.hazardCount}</span></div>
                      <div><span className="text-slate-500">Sci. tgts </span><span className="font-mono text-violet-400">{route.scienceTargetsCount}</span></div>
                      <div><span className="text-slate-500">Cost </span><span className={`font-mono ${isBright ? 'text-slate-800' : 'text-slate-200'}`}>{route.totalCost.toFixed(1)}</span></div>
                    </div>

                    {/* Astronaut EVA & Mobility Metrics */}
                    {route.evaMetrics && (
                      <div className={`p-2 rounded text-[10px] space-y-1 mb-2 font-mono ${
                        isBright ? 'bg-slate-100 border border-slate-200' : 'bg-black/40 border border-white/5'
                      }`}>
                        <div className="flex justify-between">
                          <span className="text-slate-500">O2 Consumed:</span>
                          <span className="text-cyan-400 font-bold">{route.evaMetrics.totalO2ConsumedLiters} L</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Metabolic:</span>
                          <span className="text-amber-400 font-bold">{route.evaMetrics.totalMetabolicEnergyKcal} kcal</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-500">Soil Slip Risk:</span>
                          <span className={route.evaMetrics.soilSlipRiskPercent > 30 ? 'text-red-400 font-bold' : 'text-emerald-400 font-bold'}>
                            {route.evaMetrics.soilSlipRiskPercent}%
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-500">PNR Margin:</span>
                          <span className="text-violet-400 font-bold">+{route.evaMetrics.safeReturnMarginMinutes} min</span>
                        </div>
                      </div>
                    )}

                    {/* Cost breakdown */}
                    <div className="pt-1.5 border-t border-white/5 text-[9px] text-slate-500 space-y-0.5 font-mono">
                      <div className="flex justify-between"><span>Distance Cost</span><span>{route.costBreakdown.distance.toFixed(2)}</span></div>
                      <div className="flex justify-between"><span>Terrain Cost</span><span>{route.costBreakdown.terrain.toFixed(2)}</span></div>
                      <div className="flex justify-between"><span>Hazard Cost</span><span className="text-red-400">{route.costBreakdown.hazard.toFixed(2)}</span></div>
                    </div>

                    {isActive && (
                      <div className="mt-2">
                        <RouteViz route={route} />
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Terrain profile */}
            {activeRoute && profileData.length > 1 && (
              <GlassPanel
                title={`Terrain Profile — ${activeRoute.name} (${activeRoute.totalDistance.toFixed(2)} km)`}
                badge={<DataBadge classification="simulated" />}
              >
                <div className="flex items-center justify-between text-xs mb-2 px-1 text-slate-400 font-mono">
                  <span>Max Slope: <strong className="text-orange-400">{activeRoute.maxSlope.toFixed(1)}°</strong></span>
                  <span>Elevation Gain: <strong className="text-emerald-400">+{activeRoute.totalElevationGain.toFixed(0)} m</strong></span>
                  <span>Elevation Loss: <strong className="text-red-400">-{activeRoute.totalElevationLoss.toFixed(0)} m</strong></span>
                  {activeRoute.evaMetrics && (
                    <span>PNR Turnaround: <strong className="text-amber-400">WP #{activeRoute.evaMetrics.pointOfNoReturnWpIndex}</strong></span>
                  )}
                </div>
                <ResponsiveContainer width="100%" height={160}>
                  <AreaChart data={profileData} margin={{ top: 5, right: 10, bottom: 5, left: 30 }}>
                    <CartesianGrid strokeDasharray="3,3" stroke="rgba(255,255,255,0.05)" />
                    <XAxis dataKey="dist" tick={{ fill: '#64748b', fontSize: 10 }} label={{ value: 'Distance (km)', position: 'insideBottom', offset: -2, fill: '#64748b', fontSize: 10 }} />
                    <YAxis tick={{ fill: '#64748b', fontSize: 10 }} label={{ value: 'Elevation (m)', angle: -90, position: 'insideLeft', fill: '#64748b', fontSize: 10 }} />
                    <Tooltip content={<CustomTooltip />} />
                    <Area type="monotone" dataKey="elev" stroke={ROUTE_TYPE_CONFIG[activeRoute.type]?.color ?? '#f97316'} fill="rgba(232,64,32,0.15)" strokeWidth={2} dot={false} />
                  </AreaChart>
                </ResponsiveContainer>
              </GlassPanel>
            )}
          </>
        )}
      </div>
    </div>
  );
}
