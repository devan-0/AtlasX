# AtlasX — Architecture

## Overview

AtlasX is a single-page application (SPA) built with React + TypeScript + Vite. It uses a modular page architecture with lazy loading, a Zustand global store for state, and a layered utility system for scientific calculations.

```
┌─────────────────────────────────────────────────────────────┐
│                         index.html                           │
│                    └── main.tsx (React root)                 │
│                         └── App.tsx                          │
│                    ┌───────────┬────────────┐               │
│                    │  Sidebar  │  TopToolbar│               │
│                    └───────────┴────────────┘               │
│                    ┌───────────────────────────────────┐     │
│                    │    <Suspense> + Lazy Pages         │     │
│                    │  OverviewPage, AtlasPage, ...      │     │
│                    └───────────────────────────────────┘     │
│                    ┌───────────────────────────────────┐     │
│                    │           StatusBar                │     │
│                    └───────────────────────────────────┘     │
└─────────────────────────────────────────────────────────────┘
```

---

## Directory Structure

```
src/
├── App.tsx                  # Root: shell layout + lazy page routing
├── main.tsx                 # React DOM entry point
├── index.css                # Design system, Tailwind utilities, glass morphism
│
├── types/
│   └── index.ts             # All TypeScript domain types
│
├── store/
│   └── useAppStore.ts       # Zustand store (single source of truth)
│
├── data/
│   └── sampleData.ts        # Demonstration datasets (all SIMULATED)
│
├── utils/
│   ├── marsCoordinates.ts   # Haversine, DMS, coordinate validation
│   ├── solarGeometry.ts     # Mars orbital mechanics, irradiance model
│   ├── routePlanning.ts     # Terrain grid, A* pathfinding, route building
│   └── export.ts            # GeoJSON, JSON, CSV, HTML report generation
│
├── components/
│   ├── ui/
│   │   ├── DataBadge.tsx    # Data classification badge (observed/derived/modelled/simulated/unavailable)
│   │   ├── GlassPanel.tsx   # Frosted glass card wrapper
│   │   ├── StatCard.tsx     # Key metric display card
│   │   └── LoadingSpinner.tsx
│   └── layout/              # (Unused — layout is inlined in App.tsx)
│
├── pages/
│   ├── OverviewPage.tsx     # Mission dashboard
│   ├── AtlasPage.tsx        # Leaflet 2D map
│   ├── Terrain3DPage.tsx    # Three.js 3D terrain
│   ├── RoutesPage.tsx       # A* route planner
│   ├── SciencePage.tsx      # Science targets manager
│   ├── MineralsPage.tsx     # Mineralogy + geology
│   ├── SolarPage.tsx        # Solar energy analysis
│   ├── AtmospherePage.tsx   # Atmospheric data charts
│   ├── SuitabilityPage.tsx  # Landing/ascent scoring
│   ├── ComparisonPage.tsx   # Multi-site comparison
│   ├── CataloguePage.tsx    # Dataset catalogue
│   ├── MissionsPage.tsx     # Saved missions
│   └── SettingsPage.tsx     # Settings + attribution
│
└── tests/
    └── scientific.test.ts   # 35 unit tests for utility functions
```

---

## State Management

All application state lives in a single [Zustand](https://zustand.dev/) store at `src/store/useAppStore.ts`. State is persisted to `localStorage` via Zustand's `persist` middleware.

```
AppState
├── activePage: NavPage            # current navigation page
├── sidebarCollapsed: boolean
│
├── selectedRegion: MarsRegion     # active study region
├── regions: MarsRegion[]          # all available regions
├── selectedDate: string           # ISO date string
│
├── mapCenter: [lat, lon]          # Leaflet map center
├── mapZoom: number
│
├── layers: LayerConfig[]          # GIS layer visibility/opacity
│
├── scienceTargets: ScienceTarget[] # user-managed targets
├── selectedTargetId: string | null
│
├── routes: Route[]                # A*-computed routes
├── activeRouteId: string | null
│
├── candidateSites: CandidateSite[]
├── selectedSiteIds: string[]
│
├── savedMissions: SavedMission[]
├── activeMissionId: string | null
│
└── settings: AppSettings          # units, coord format, etc.
```

---

## Data Flow

```
User interaction
      │
      ▼
Page component (e.g. RoutesPage)
      │  calls
      ▼
Zustand store action (e.g. addRoute)
      │  triggers
      ▼
Re-render of subscribed components
      │  reads from
      ▼
sampleData.ts (static) or utility fn (calculated)
```

For calculated data (solar analysis, route planning):
```
Page component
      │  calls
      ▼
Utility function (solarGeometry.ts / routePlanning.ts)
      │  returns
      ▼
Local component state (useState)
      │  displayed in
      ▼
Charts / visualizations
```

---

## Key Technical Decisions

### Lazy Page Loading
All 13 pages are loaded via `React.lazy()` with `<Suspense>`. This splits the bundle into per-page chunks, keeping initial load fast. Vendor libraries (Three.js, Leaflet, Recharts) are in separate chunks via Vite's `manualChunks`.

### Data Classification System
Every data value displayed carries an explicit classification:
- `observed` — from real instrument measurements
- `derived` — calculated from real observations
- `modelled` — from GCM/physics model
- `simulated` — synthetic demonstration data
- `unavailable` — data not accessible in this build

The `DataBadge` component renders these consistently. No simulated value is ever presented without its badge.

### Route Planning Architecture
```
generateTerrainGrid(north, south, east, west, resolution)
      │ returns TerrainGrid (resolution × resolution cells)
      │
aStarPath(grid, startRow, startCol, endRow, endCol, weights, maxSlope)
      │ returns [row, col][] path
      │
buildRoute(id, name, type, path, grid, weights)
      │ returns Route with:
      │   - waypoints (Coordinates[])
      │   - profile (elevation vs distance)
      │   - metrics (distance, duration, hazards, slope)
      │   - costBreakdown
```

A* uses 8-connectivity with a combined cost function:
```
cost = w.distance × Δdist + w.terrain × slope_penalty + w.hazard × hazard_penalty − w.scienceBonus × science_bonus
```

### Solar Geometry
Mars-specific orbital mechanics with eccentricity 0.0934:
- Solar longitude computed from Earth calendar date
- Irradiance scaled by r⁻² where r varies with eccentric anomaly
- Declination and day length computed per latitude and Ls
- No terrain shadowing (clearly labelled limitation)

### 3D Terrain
The Three.js terrain is procedural (not MOLA data). It uses seeded sin/cos wave combinations to produce visually plausible topography. Elevation exaggeration is adjustable 1–10×. Science targets and hazards are projected as marker spheres at terrain-height positions.

---

## Build System

- **Vite 5** with React plugin
- **TypeScript** with relaxed unused-variable checking (`noUnusedLocals: false`) to allow page component development without blocking builds
- **Tailwind CSS 3** with a custom Mars color palette extension
- **Vitest** for unit tests

Chunk budget:
| Chunk | Size (gz) |
|-------|----------|
| three-vendor | 227 KB |
| chart-vendor | 112 KB |
| map-vendor | 89 KB |
| index (core) | 15 KB |
| per-page chunks | 2–6 KB each |

---

## Extension Points

### Adding a Real Data Source
1. Create a loader in `src/data/` that fetches from the PDS or an API endpoint
2. Implement the `DataSource` interface from `src/types`
3. Update the relevant page to call the loader and show a `DataBadge` with `'observed'` or `'derived'`
4. Add the dataset to `CataloguePage` and `DATA_SOURCES.md`

### Adding a Page
1. Create `src/pages/MyPage.tsx`
2. Add a lazy import and entry in `PAGE_MAP` in `App.tsx`
3. Add a nav item in `NAV_ITEMS`

### Adding a Test
Tests live in `src/tests/`. Vitest is configured in `vite.config.ts`. Tests can import any utility function directly—no mocking infrastructure required for pure functions.
