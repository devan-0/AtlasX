# AtlasX — Testing Guide

## Running Tests

```powershell
# Add portable Node.js to PATH first:
$env:PATH = "C:\Users\valiy\tools\node-v20.18.0-win-x64;$env:PATH"

# Run all tests once:
npm test

# Run in watch mode during development:
npx vitest

# Run with verbose output:
npx vitest run --reporter=verbose
```

Expected output:
```
 RUN  v4.x.x

 ✓ src/tests/scientific.test.ts (35 tests) 32ms

 Test Files  1 passed (1)
      Tests  35 passed (35)
   Duration  ~300ms
```

---

## Test Coverage

All tests are in [`src/tests/scientific.test.ts`](./src/tests/scientific.test.ts).

### Coordinate Utilities (9 tests)
Tests for `src/utils/marsCoordinates.ts`:

| Test | Description |
|------|-------------|
| Mars radius constant | `MARS_RADIUS_KM === 3389.5` |
| DMS positive | `(18.4446, true)` → `"18° 26' 40.56" N"` |
| DMS negative | `(-18.4446, true)` → `"18° 26' 40.56" S"` |
| Haversine same point | distance = 0 |
| Haversine known pair | 18.44°N/77.45°E → 18.10°N/76.90°E ≈ 56 km |
| Valid Mars coord | `(0, 0)` → true |
| Invalid latitude | `(95, 0)` → false |
| Lon normalization +ve | `normalizeLon(10)` = 10 |
| Lon normalization -ve | `normalizeLon(-10)` = 350 |

### Solar Geometry (9 tests)
Tests for `src/utils/solarGeometry.ts`:

| Test | Description |
|------|-------------|
| Solar constant | `SOLAR_CONSTANT_MARS_W === 586` |
| Perihelion irradiance | Ls=251° gives higher irradiance than mean |
| Aphelion irradiance | Ls=71° gives lower irradiance than mean |
| Equator daylight | Ls=0° at equator ≈ 12 hours |
| Daily energy positive | `dailySolarEnergy(0, 0)` > 0 |
| computeSolarAnalysis returns | complete SolarAnalysis object |
| Irradiance non-negative | always ≥ 0 |
| Latitude effect | higher latitudes get less daily energy (Ls=0) |
| Classification check | returns 'modelled' or 'derived' |

### Route Planning (9 tests)
Tests for `src/utils/routePlanning.ts`:

| Test | Description |
|------|-------------|
| Grid dimensions | 32×32 by default |
| Grid coordinates | cells span north–south and east–west |
| Grid cells non-zero | elevation values present |
| Path found | A* returns ≥ 2 cells |
| Path terminates | start cell appears at path start |
| Route metrics | distance > 0, duration > 0 |
| Route waypoints | waypoints array non-empty |
| Slope constraint respected | no cell slope exceeds maxSlope in route |
| Profile points | elevation profile non-empty |

### Sample Data Integrity (4 tests)

| Test | Description |
|------|-------------|
| Regions count | 5 regions defined |
| Science targets | each has required fields |
| Datasets classification | all have valid DataClassification value |
| Hazards | valid severity values |

### Export Functions (4 tests)

| Test | Description |
|------|-------------|
| GeoJSON type | `routeToGeoJSON` returns FeatureCollection |
| CSV headers | `scienceTargetsToCSV` includes "name,lat,lon" |
| Mission JSON | `missionToJSON` produces parseable JSON |
| Report HTML | `generateMissionReport` includes mission name |

---

## Adding New Tests

Create additional test files in `src/tests/`. Vitest picks up any `*.test.ts` or `*.spec.ts` file.

```typescript
// src/tests/myFeature.test.ts
import { describe, it, expect } from 'vitest';
import { myFunction } from '../utils/myModule';

describe('My Feature', () => {
  it('does what expected', () => {
    expect(myFunction(input)).toBe(expectedOutput);
  });
});
```

### Testing Guidelines

1. **Pure utility functions only** — Page components require a DOM environment. Test logic in utility modules (`src/utils/`) and data modules (`src/data/`), not React components.

2. **No real network calls** — All tests run offline. Utility functions must not make HTTP requests.

3. **Scientific correctness** — Where a calculation has a known analytical answer, test against that value with appropriate tolerance (`toBeCloseTo`).

4. **Data integrity** — Test that sample data conforms to type constraints (required fields, valid enum values, sensible ranges).

5. **Classification honesty** — Tests should verify that simulated data is not accidentally labelled as `'observed'`.

---

## Test Configuration

Tests are configured in `vite.config.ts`:

```typescript
test: {
  globals: true,
  environment: 'node',
  include: ['src/tests/**/*.test.ts'],
}
```

No browser environment or DOM is needed because all tests target pure utility functions.
