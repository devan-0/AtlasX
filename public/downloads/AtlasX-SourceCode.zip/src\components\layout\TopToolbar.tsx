// TopToolbar — region/date selectors, layer toggles, export, connectivity & real-time astronomical clock
import React, { useState } from 'react';
import {
  Search,
  Calendar,
  Layers,
  Download,
  Wifi,
  Globe,
  Clock,
  RotateCcw,
} from 'lucide-react';
import { useAppStore } from '../../store/useAppStore';
import { useRealTimeMarsClock } from '../../utils/marsTime';
import { useBackendStatus } from '../../services/hooks';

const TopToolbar: React.FC = () => {
  const regions = useAppStore((s) => s.regions);
  const selectedRegion = useAppStore((s) => s.selectedRegion);
  const setSelectedRegion = useAppStore((s) => s.setSelectedRegion);
  const selectedDate = useAppStore((s) => s.selectedDate);
  const setSelectedDate = useAppStore((s) => s.setSelectedDate);
  const isLiveDate = useAppStore((s) => s.isLiveDate);
  const syncToLive = useAppStore((s) => s.syncToLive);
  const layers = useAppStore((s) => s.layers);
  const setLayerVisible = useAppStore((s) => s.setLayerVisible);
  const mapCenter = useAppStore((s) => s.mapCenter);

  const { alive, checking } = useBackendStatus();
  const [layerPanelOpen, setLayerPanelOpen] = useState(false);

  const clock = useRealTimeMarsClock(
    selectedRegion.coordinates.lon,
    isLiveDate ? null : selectedDate,
    1000
  );

  const handleRegionChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const region = regions.find((r) => r.id === e.target.value);
    if (region) setSelectedRegion(region);
  };

  const handleExport = () => {
    const blob = new Blob(
      [
        JSON.stringify(
          {
            exportedAt: new Date().toISOString(),
            earthUTC: clock.utcFull,
            marsSolDate: clock.msdFormatted,
            coordinatedMarsTime: clock.mtcFormatted,
            region: selectedRegion,
            date: selectedDate,
            activeLayers: layers.filter((l) => l.visible).map((l) => l.name),
          },
          null,
          2
        ),
      ],
      { type: 'application/json' }
    );
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `mars-atlas-export-${selectedDate}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const visibleCount = layers.filter((l) => l.visible).length;

  return (
    <header className="flex-shrink-0 h-14 flex items-center gap-2.5 px-3 bg-black/50 border-b border-white/10 backdrop-blur-md z-20 relative select-none overflow-x-auto">
      {/* Region selector */}
      <div className="flex items-center gap-1.5 bg-white/5 border border-white/10 rounded-lg px-2.5 h-9">
        <Globe className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
        <select
          value={selectedRegion.id}
          onChange={handleRegionChange}
          className="bg-transparent text-[12px] text-white/90 font-medium outline-none cursor-pointer min-w-0 max-w-[130px] truncate"
        >
          {regions.map((r) => (
            <option key={r.id} value={r.id} className="bg-gray-900 text-white">
              {r.name}
            </option>
          ))}
        </select>
        <span
          className="text-[9px] font-mono text-cyan-300 bg-cyan-950/60 border border-cyan-800/40 px-1 py-0.5 rounded whitespace-nowrap"
          title="Local Mean Solar Time"
        >
          {clock.lmstFormatted}
        </span>
      </div>

      {/* Live Astronomical Telemetry */}
      <div className="hidden md:flex items-center gap-2 bg-black/40 border border-white/5 rounded-lg px-2.5 h-9 text-[11px] font-mono">
        <div className="flex items-center gap-1 text-slate-300">
          <Clock size={11} className="text-blue-400" />
          <span>{clock.utcDate}</span>
          <span className="text-blue-300 font-semibold">{clock.utcTime}</span>
        </div>
        <span className="text-white/20">|</span>
        <div className="flex items-center gap-1">
          <span className="text-orange-400 font-bold">{clock.msdFormatted}</span>
          <span className="text-white/30">·</span>
          <span className="text-amber-300 font-semibold">{clock.mtcFormatted}</span>
        </div>
        <span className="text-white/20 hidden lg:inline">|</span>
        <div className="hidden lg:flex items-center gap-1 text-slate-400 text-[10px]">
          <span className="text-orange-300">{clock.marsYearFormatted}</span>
          <span>·</span>
          <span className="text-slate-300">{clock.lsFormatted}</span>
        </div>
      </div>

      {/* Date selector with Live Sync */}
      <div className="flex items-center gap-1.5 bg-white/5 border border-white/10 rounded-lg px-2 h-9">
        {isLiveDate ? (
          <span className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-emerald-500/15 border border-emerald-500/30 text-[9px] font-mono text-emerald-300 font-semibold">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            LIVE
          </span>
        ) : (
          <button
            onClick={syncToLive}
            className="flex items-center gap-1 px-1.5 py-0.5 rounded bg-amber-500/20 border border-amber-500/40 text-[9px] font-mono text-amber-300 hover:bg-amber-500/30 font-semibold"
            title="Return to real-time clock"
          >
            <RotateCcw size={9} />
            SYNC
          </button>
        )}
        <input
          type="date"
          value={selectedDate}
          onChange={(e) => setSelectedDate(e.target.value)}
          className="bg-transparent text-[11px] text-white/90 font-mono outline-none cursor-pointer w-[114px]"
          style={{ colorScheme: 'dark' }}
        />
      </div>

      {/* Layer toggles */}
      <div className="relative">
        <button
          onClick={() => setLayerPanelOpen((o) => !o)}
          className={`flex items-center gap-1.5 h-9 px-2.5 rounded-lg border text-[12px] font-medium transition-all ${
            layerPanelOpen
              ? 'bg-mars-orange/20 border-mars-orange/50 text-mars-orange'
              : 'bg-white/5 border-white/10 text-white/70 hover:text-white/90 hover:bg-white/10'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>Layers</span>
          {visibleCount > 0 && (
            <span className="bg-mars-orange text-black text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center leading-none">
              {visibleCount}
            </span>
          )}
        </button>

        {layerPanelOpen && (
          <div className="absolute top-full left-0 mt-2 w-64 bg-gray-950/95 border border-white/15 rounded-xl shadow-2xl backdrop-blur-sm z-50 overflow-hidden">
            <div className="px-3 py-2 border-b border-white/10">
              <p className="text-[10px] font-mono text-white/40 uppercase tracking-wider">
                Active Layers
              </p>
            </div>
            <div className="max-h-72 overflow-y-auto py-1">
              {layers.map((layer) => (
                <label
                  key={layer.id}
                  className="flex items-center gap-3 px-3 py-2 cursor-pointer hover:bg-white/5 transition-colors"
                >
                  <input
                    type="checkbox"
                    checked={layer.visible}
                    onChange={(e) => setLayerVisible(layer.id, e.target.checked)}
                    className="accent-mars-orange w-3.5 h-3.5 flex-shrink-0"
                  />
                  <span className="text-[12px] text-white/70 truncate flex-1">{layer.name}</span>
                  <span className="text-[9px] font-mono text-white/30 flex-shrink-0">
                    {layer.category}
                  </span>
                </label>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Spacer */}
      <div className="flex-1" />

      {/* Coordinate display */}
      <div className="hidden xl:flex items-center gap-1.5 bg-white/5 border border-white/10 rounded-lg px-2.5 h-9">
        <Search className="w-3.5 h-3.5 text-white/30 flex-shrink-0" />
        <span className="text-[11px] font-mono text-white/50">
          {mapCenter.lat.toFixed(3)}°{mapCenter.lat >= 0 ? 'N' : 'S'}&nbsp;
          {mapCenter.lon.toFixed(3)}°{mapCenter.lon >= 0 ? 'E' : 'W'}
        </span>
      </div>

      {/* Connectivity status */}
      {checking ? (
        <div className="flex items-center gap-1.5 px-2.5 h-9 rounded-lg bg-slate-800/40 border border-slate-700/40">
          <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-pulse" />
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">Checking…</span>
        </div>
      ) : alive ? (
        <div className="flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/25 rounded-lg px-2.5 h-9">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse flex-shrink-0" />
          <Wifi className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
          <span className="text-[10px] font-mono font-semibold text-emerald-300 tracking-wider uppercase hidden sm:block">
            Live Telemetry (JPL)
          </span>
        </div>
      ) : (
        <div className="flex items-center gap-2 bg-cyan-500/10 border border-cyan-500/25 rounded-lg px-2.5 h-9">
          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse flex-shrink-0" />
          <Wifi className="w-3.5 h-3.5 text-cyan-400 flex-shrink-0" />
          <span className="text-[10px] font-mono font-semibold text-cyan-300 tracking-wider uppercase hidden sm:block">
            Astro Engine (DE441)
          </span>
        </div>
      )}

      {/* Export */}
      <button
        onClick={handleExport}
        className="flex items-center gap-2 h-9 px-3 rounded-lg bg-white/5 border border-white/10 text-white/60 hover:text-white hover:bg-white/10 transition-all text-[12px] font-medium"
        title="Export current state as JSON"
      >
        <Download className="w-3.5 h-3.5" />
        <span className="hidden sm:block">Export</span>
      </button>
    </header>
  );
};

export default TopToolbar;
