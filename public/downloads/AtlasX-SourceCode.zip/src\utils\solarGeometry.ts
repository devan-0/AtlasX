// AtlasX — Mars Solar Geometry Utilities
//
// References:
//   Allison & McEwen (2000) "A post-Pathfinder evaluation of areocentric solar
//   coordinates with improved timing recipes for Mars seasonal/diurnal climate
//   studies", Planet. Space Sci. 48, 215-235.
//   Laskar et al. (2002) Mars obliquity and orbital evolution.

import { SolarAnalysis } from '../types';
import { MARS_AXIAL_TILT_DEG, MARS_ORBITAL_PERIOD_DAYS } from './marsCoordinates';

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

/** Solar irradiance at Mars's mean distance from the Sun (W/m²) */
export const SOLAR_CONSTANT_MARS_W = 586;

/** Mars orbital eccentricity */
const MARS_ECCENTRICITY = 0.0934;

/** Solar longitude of Mars perihelion (Ls ≈ 251°) */
const LS_PERIHELION = 251.0;

/** J2000 epoch as Julian Date */
const J2000_JD = 2451545.0;

/** Julian date of Mars perihelion reference epoch (2000-01-06 ≈ JD 2451550.0) */
const MARS_PERIHELION_EPOCH_JD = 2451507.5; // 1999-11-28

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

const toRad = (deg: number): number => (deg * Math.PI) / 180;
const toDeg = (rad: number): number => (rad * 180) / Math.PI;
const clamp = (v: number, lo: number, hi: number): number => Math.max(lo, Math.min(hi, v));

/** Parse an ISO date string (YYYY-MM-DD or full ISO) and return Julian Date */
function isoToJD(dateStr: string): number {
  const d = new Date(dateStr);
  // Julian date from Unix timestamp
  return d.getTime() / 86400000 + 2440587.5;
}

/**
 * Mean anomaly of Mars at a given JD.
 * M = (JD - T_peri) / T_orbit × 360°  (mod 360)
 */
function meanAnomaly(jd: number): number {
  const daysSincePeri = jd - MARS_PERIHELION_EPOCH_JD;
  let M = (daysSincePeri / MARS_ORBITAL_PERIOD_DAYS) * 360;
  M = M % 360;
  if (M < 0) M += 360;
  return M;
}

/**
 * Solve Kepler's equation M = E - e·sin(E) by iteration.
 * Accurate to < 10⁻⁸ rad in < 15 iterations for Mars eccentricity.
 */
function solveKepler(M_rad: number, e: number): number {
  let E = M_rad + e * Math.sin(M_rad); // initial guess
  for (let i = 0; i < 50; i++) {
    const dE = (M_rad - (E - e * Math.sin(E))) / (1 - e * Math.cos(E));
    E += dE;
    if (Math.abs(dE) < 1e-8) break;
  }
  return E;
}

/**
 * True anomaly ν from eccentric anomaly E and eccentricity e.
 * tan(ν/2) = sqrt((1+e)/(1-e)) · tan(E/2)
 */
function trueAnomaly(E_rad: number, e: number): number {
  return (
    2 *
    Math.atan2(
      Math.sqrt(1 + e) * Math.sin(E_rad / 2),
      Math.sqrt(1 - e) * Math.cos(E_rad / 2),
    )
  );
}

// ---------------------------------------------------------------------------
// Exported functions
// ---------------------------------------------------------------------------

/**
 * Estimate solar irradiance at Mars at a given solar longitude (Ls).
 *
 * The orbit is elliptical; the inverse-square law gives:
 *   r(ν) = a(1 - e²) / (1 + e·cos ν)
 *   I = S₀ · (a/r)²
 *
 * We convert Ls → true anomaly ν by: ν = Ls - Ls_perihelion (mod 360)
 * This is an approximation; a full ephemeris would include perturbations.
 *
 * @param ls_deg - Solar longitude in degrees (0 = northern spring equinox)
 * @returns Estimated irradiance in W/m²
 */
export function solarIrradiance(ls_deg: number): number {
  // True anomaly ν relative to perihelion
  const nu_deg = ((ls_deg - LS_PERIHELION) % 360 + 360) % 360;
  const nu = toRad(nu_deg);
  const e = MARS_ECCENTRICITY;

  // Heliocentric distance ratio r/a = (1 - e²) / (1 + e·cos ν)
  const rOverA = (1 - e * e) / (1 + e * Math.cos(nu));

  // Irradiance scales as (a/r)² = 1/rOverA²
  return SOLAR_CONSTANT_MARS_W / (rOverA * rOverA);
}

/**
 * Estimate the areocentric solar longitude Ls (degrees) for a given Earth date.
 *
 * Method: convert date → JD → mean anomaly → eccentric anomaly (Kepler) →
 *         true anomaly → Ls = ν + Ls_perihelion.
 *
 * This is an approximation (~1–2° accuracy) suitable for mission planning.
 *
 * @param dateStr - ISO date string, e.g. "2030-04-15"
 * @returns Solar longitude Ls in degrees [0, 360)
 */
export function earthDateToLS(dateStr: string): number {
  const jd = isoToJD(dateStr);
  const M_deg = meanAnomaly(jd);
  const M_rad = toRad(M_deg);
  const E_rad = solveKepler(M_rad, MARS_ECCENTRICITY);
  const nu_rad = trueAnomaly(E_rad, MARS_ECCENTRICITY);
  const nu_deg = toDeg(nu_rad);

  let ls = ((nu_deg + LS_PERIHELION) % 360 + 360) % 360;
  return ls;
}

/**
 * Solar hour angle for a given local time of day.
 *
 * The hour angle h is the angular displacement of the Sun from the local
 * meridian:  h = (t_hours - 12) × 15°/hour
 *
 * @param hourOfDay - Local true solar time in hours (0-24)
 * @returns Hour angle in degrees (negative before noon, positive after)
 */
export function solarHourAngle(hourOfDay: number): number {
  return (hourOfDay - 12) * 15;
}

/**
 * Solar incidence angle θ on a flat horizontal surface.
 *
 * cos θ = sin φ · sin δ + cos φ · cos δ · cos h
 *
 * where:
 *   φ = latitude
 *   δ = solar declination = ε · sin(Ls)   (ε = axial tilt)
 *   h = hour angle
 *
 * Returns 90° when the Sun is below the horizon.
 *
 * @param lat      - Planetocentric latitude in degrees
 * @param ls       - Solar longitude in degrees
 * @param hourAngle - Hour angle in degrees
 * @returns Incidence angle in degrees [0°, 90°]
 */
export function solarIncidenceAngle(lat: number, ls: number, hourAngle: number): number {
  const φ = toRad(lat);
  const δ = toRad(MARS_AXIAL_TILT_DEG * Math.sin(toRad(ls)));
  const h = toRad(hourAngle);

  const cosZenith = Math.sin(φ) * Math.sin(δ) + Math.cos(φ) * Math.cos(δ) * Math.cos(h);
  // Zenith angle Z; incidence angle on horizontal surface = Z
  const Z_rad = Math.acos(clamp(cosZenith, -1, 1));
  // Clamp to 90° (no illumination below horizon)
  return Math.min(toDeg(Z_rad), 90);
}

/**
 * Estimate daylight duration in hours for a given latitude and solar longitude.
 *
 * The sunrise/sunset hour angle H₀ satisfies:
 *   cos H₀ = -tan φ · tan δ
 *
 * Daylight = 2 · H₀ / 15  (hours in a 24-hour day)
 * Scaled to a Martian sol (24.6597 h) by the sol/24-h ratio.
 *
 * Returns 0 h (polar night) or 24.6597 h (midnight sun) for extreme latitudes.
 *
 * @param lat - Planetocentric latitude in degrees
 * @param ls  - Solar longitude in degrees
 * @returns Daylight duration in hours (Martian hours)
 */
export function daylightDuration(lat: number, ls: number): number {
  const φ = toRad(lat);
  const δ = toRad(MARS_AXIAL_TILT_DEG * Math.sin(toRad(ls)));

  const cosH0 = -Math.tan(φ) * Math.tan(δ);

  if (cosH0 >= 1) {
    // Polar night — Sun never rises
    return 0;
  }
  if (cosH0 <= -1) {
    // Midnight sun — Sun never sets
    return 24.6597;
  }

  const H0_deg = toDeg(Math.acos(cosH0)); // sunrise/sunset hour angle in degrees
  // Daylength in Earth hours = 2 × H₀ / 15 (since 1 hour = 15°)
  const daylightEarthH = (2 * H0_deg) / 15;
  // Scale to Martian sol fraction
  return daylightEarthH * (24.6597 / 24);
}

/**
 * Estimate the daily integrated solar energy on a flat horizontal surface.
 *
 * Integration of I·cos(θ) over the daylit period, using a simple trapezoidal
 * approximation with 24 timesteps per sol.
 *
 * E_day ≈ Σ I(Ls) · max(0, cos θ(t)) · Δt
 *
 * @param lat - Planetocentric latitude in degrees
 * @param ls  - Solar longitude in degrees
 * @returns Daily solar energy in Wh/m²
 */
export function dailySolarEnergy(lat: number, ls: number): number {
  const irradiance = solarIrradiance(ls);
  const solHours = 24.6597;
  const steps = 240; // 10-minute intervals per sol
  const dtHours = solHours / steps;
  let total = 0;

  for (let i = 0; i <= steps; i++) {
    const t = (i / steps) * solHours; // local hour (0 → solHours)
    const h = solarHourAngle((t / solHours) * 24); // map sol time to 24-h clock
    const θ_deg = solarIncidenceAngle(lat, ls, h);
    const cosTheta = Math.max(0, Math.cos(toRad(θ_deg)));
    const weight = i === 0 || i === steps ? 0.5 : 1; // trapezoidal
    total += weight * irradiance * cosTheta * dtHours;
  }

  return total;
}

/**
 * Classify solar illumination quality based on effective daylight hours per sol.
 *
 * Thresholds derived from typical solar power requirements for surface
 * operations (charge time needed for rover battery buffers, ISRU, etc.):
 *   < 4 h  → 'poor'
 *   4–8 h  → 'marginal'
 *   8–14 h → 'adequate'
 *   ≥ 14 h → 'good'
 */
export function illuminationCategory(
  hoursPerSol: number,
): 'poor' | 'marginal' | 'adequate' | 'good' {
  if (hoursPerSol < 4) return 'poor';
  if (hoursPerSol < 8) return 'marginal';
  if (hoursPerSol < 14) return 'adequate';
  return 'good';
}

/**
 * Compute a complete solar analysis object for a surface location and date.
 *
 * @param lat     - Planetocentric latitude in degrees
 * @param lon     - Planetocentric longitude in degrees
 * @param dateStr - Earth date string (ISO 8601)
 */
export function computeSolarAnalysis(
  lat: number,
  lon: number,
  dateStr: string,
): SolarAnalysis {
  const ls = earthDateToLS(dateStr);
  const irradiance = solarIrradiance(ls);
  const daylightH = daylightDuration(lat, ls);

  // Noon incidence angle (hour angle = 0)
  const noonIncidenceDeg = solarIncidenceAngle(lat, ls, 0);
  const solarZenithAngle = noonIncidenceDeg; // zenith = incidence on flat surface

  // Sunrise / sunset times in Martian local solar time
  // hour angle H₀ → time offset from noon: H₀/15 hours
  const δ = toRad(MARS_AXIAL_TILT_DEG * Math.sin(toRad(ls)));
  const φ = toRad(lat);
  const cosH0 = -Math.tan(φ) * Math.tan(δ);
  let sunriseTime: string | undefined;
  let sunsetTime: string | undefined;

  if (cosH0 > -1 && cosH0 < 1) {
    const H0_deg = toDeg(Math.acos(cosH0));
    const hoursFromNoon = H0_deg / 15;
    // Scale to sol hours
    const solScale = 24.6597 / 24;
    const sunriseH = (12 - hoursFromNoon) * solScale;
    const sunsetH = (12 + hoursFromNoon) * solScale;
    const fmt = (h: number) => {
      const hh = Math.floor(h);
      const mm = Math.round((h - hh) * 60);
      return `${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')} LTST`;
    };
    sunriseTime = fmt(sunriseH);
    sunsetTime = fmt(sunsetH);
  } else if (cosH0 >= 1) {
    sunriseTime = 'Never rises (polar night)';
    sunsetTime = 'Never sets (polar night)';
  } else {
    sunriseTime = 'Never rises (midnight sun)';
    sunsetTime = 'Never sets (midnight sun)';
  }

  return {
    location: { lat, lon },
    date: dateStr,
    solarIncidenceDeg: noonIncidenceDeg,
    estimatedIrradianceWm2: Math.round(irradiance * 10) / 10,
    illuminationDurationH: Math.round(daylightH * 100) / 100,
    sunriseTime,
    sunsetTime,
    solarZenithAngle: Math.round(solarZenithAngle * 100) / 100,
    methodology: 'geometric',
    assumptions: [
      'Flat horizontal surface; no terrain shadowing',
      'Clear atmosphere (no dust attenuation)',
      'Orbital eccentricity e = 0.0934',
      `Solar longitude estimated from Earth date via Keplerian orbit (Ls ≈ ${ls.toFixed(1)}°)`,
      `Solar declination δ = ε·sin(Ls), ε = ${MARS_AXIAL_TILT_DEG}°`,
    ],
    classification: 'modelled',
  };
}
