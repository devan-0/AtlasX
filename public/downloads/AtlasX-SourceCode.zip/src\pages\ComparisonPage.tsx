import React, { useMemo } from 'react';
import { RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer, Legend } from 'recharts';
import { useAppStore } from '../store/useAppStore';
import DataBadge from '../components/ui/DataBadge';
import GlassPanel from '../components/ui/GlassPanel';
import { GitCompare, HelpCircle, CheckCircle, AlertTriangle } from 'lucide-react';
import type { CandidateSite } from '../types';

const SITE_COLORS = ['#f46040', '#22d3ee', '#a78bfa', '#34d399'];
const SCORE_COLOR = (n: number) => n >= 75 ? '#22c55e' : n >= 50 ? '#d97706' : n > 0 ? '#ef4444' : '#64748b';

function MetricCell({ value, best }: { value: number | null; best: boolean }) {
  if (value === null) return (
    <td className="px-3 py-2 text-center">
      <span className="flex items-center justify-center gap-1 text-slate-600 text-xs"><HelpCircle size={10} /> N/A</span>
    </td>
  );
  return (
    <td className={`px-3 py-2 text-center font-mono text-sm ${best ? 'font-bold' : ''}`} style={{ color: SCORE_COLOR(value) }}>
      {value}
      {best && <span className="ml-1 text-[9px] text-emerald-400">▲</span>}
    </td>
  );
}

export default function ComparisonPage() {
  const { candidateSites, selectedSiteIds, toggleSiteSelection } = useAppStore();
  const selected = candidateSites.filter(s => selectedSiteIds.includes(s.id));

  const METRICS: { label: string; key: string; getValue: (s: CandidateSite) => number | null; unit?: string }[] = [
    { label: 'Landing Score', key: 'landing', getValue: s => s.landingSuitability?.overall ?? null },
    { label: 'Ascent Score', key: 'ascent', getValue: s => s.ascentSuitability?.overall ?? null },
    { label: 'Science Value', key: 'science', getValue: s => s.scienceValue },
    { label: 'Slope Score', key: 'slope', getValue: s => s.landingSuitability?.slope ?? null },
    { label: 'Roughness Score', key: 'roughness', getValue: s => s.landingSuitability?.roughness ?? null },
    { label: 'Hazard Clearance', key: 'hazards', getValue: s => s.landingSuitability?.hazards ?? null },
    { label: 'Data Coverage', key: 'coverage', getValue: s => s.landingSuitability?.dataCoverage ?? null },
    { label: 'Nearby Targets', key: 'targets', getValue: s => s.nearbyTargets.length * 20 },
  ];

  const bestValues = useMemo(() => {
    return METRICS.reduce((acc, m) => {
      const vals = selected.map(s => m.getValue(s)).filter((v): v is number => v !== null);
      acc[m.key] = vals.length ? Math.max(...vals) : null;
      return acc;
    }, {} as Record<string, number | null>);
  }, [selected]);

  const radarData = useMemo(() =>
    METRICS.map(m => ({
      metric: m.label.split(' ')[0],
      ...Object.fromEntries(selected.map(s => [s.name.split(' ')[0], m.getValue(s) ?? 0])),
    })), [selected]);

  return (
    <div className="h-full overflow-y-auto p-4 space-y-4">
      {/* Site selector */}
      <GlassPanel title="Compare Sites (select up to 4)">
        <div className="flex flex-wrap gap-2">
          {candidateSites.map((s, i) => (
            <button key={s.id}
              onClick={() => toggleSiteSelection(s.id)}
              className={`flex items-center gap-2 px-3 py-1.5 rounded border text-xs font-medium transition-all ${selectedSiteIds.includes(s.id) ? 'border-opacity-50' : 'border-white/10 text-slate-400 hover:text-slate-200 hover:border-white/20'}`}
              style={selectedSiteIds.includes(s.id) ? { borderColor: SITE_COLORS[i % SITE_COLORS.length] + '80', background: SITE_COLORS[i % SITE_COLORS.length] + '18', color: SITE_COLORS[i % SITE_COLORS.length] } : {}}>
              <span className="w-2 h-2 rounded-full" style={{ background: SITE_COLORS[i % SITE_COLORS.length] }} />
              {s.name}
            </button>
          ))}
        </div>
      </GlassPanel>

      {/* Disclaimer */}
      <div className="flex items-start gap-2 p-2 rounded bg-orange-500/10 border border-orange-500/20 text-[10px] text-orange-300">
        <AlertTriangle size={10} className="flex-shrink-0 mt-0.5" />
        <span>Comparison uses synthetic demonstration data. ▲ indicates best available value for each metric. N/A = insufficient data to score. Rankings do not reflect certified site assessments.</span>
      </div>

      {selected.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 gap-3">
          <GitCompare size={32} className="text-slate-600" />
          <span className="text-slate-500">Select at least one site to compare</span>
        </div>
      ) : (
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
          {/* Comparison table */}
          <GlassPanel title="Metric Comparison" badge={<DataBadge classification="simulated" />} noPad>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-white/5">
                    <th className="px-3 py-2 text-left text-slate-500 font-medium">Metric</th>
                    {selected.map((s, i) => (
                      <th key={s.id} className="px-3 py-2 text-center font-medium" style={{ color: SITE_COLORS[i] }}>
                        {s.name.split(' ').slice(0, 2).join(' ')}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {METRICS.map(m => {
                    const vals = selected.map(s => m.getValue(s));
                    return (
                      <tr key={m.key} className="hover:bg-white/3 transition-colors">
                        <td className="px-3 py-2 text-slate-400">{m.label}</td>
                        {vals.map((v, i) => (
                          <MetricCell key={i} value={v} best={v !== null && v === bestValues[m.key]} />
                        ))}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </GlassPanel>

          {/* Radar comparison */}
          <GlassPanel title="Radar Comparison">
            <ResponsiveContainer width="100%" height={260}>
              <RadarChart data={radarData} cx="50%" cy="50%" outerRadius="65%">
                <PolarGrid stroke="rgba(255,255,255,0.08)" />
                <PolarAngleAxis dataKey="metric" tick={{ fill: '#64748b', fontSize: 10 }} />
                <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fill: '#4f5e8a', fontSize: 8 }} />
                {selected.map((s, i) => (
                  <Radar key={s.id} name={s.name.split(' ')[0]} dataKey={s.name.split(' ')[0]}
                    stroke={SITE_COLORS[i]} fill={SITE_COLORS[i]} fillOpacity={0.12} strokeWidth={2} />
                ))}
                <Legend wrapperStyle={{ fontSize: 10, color: '#94a3b8' }} />
              </RadarChart>
            </ResponsiveContainer>
          </GlassPanel>

          {/* Site notes */}
          {selected.map((s, i) => s.notes && (
            <div key={s.id} className="glass-panel p-3 text-xs">
              <div className="flex items-center gap-2 mb-1">
                <span className="w-2 h-2 rounded-full" style={{ background: SITE_COLORS[i] }} />
                <span className="font-medium" style={{ color: SITE_COLORS[i] }}>{s.name}</span>
              </div>
              <p className="text-orange-300/70">{s.notes}</p>
            </div>
          ))}

          {/* Methodology */}
          <GlassPanel title="Scoring Methodology" className="xl:col-span-2">
            <div className="grid grid-cols-2 gap-4 text-xs text-slate-400">
              <div className="space-y-1">
                <div className="text-slate-300 font-medium mb-1">Score Components</div>
                <div><span className="text-slate-500">Slope:</span> Based on MOLA-derived slope statistics within 1-km radius</div>
                <div><span className="text-slate-500">Roughness:</span> Thermal inertia proxy for boulder density (simulated)</div>
                <div><span className="text-slate-500">Elevation:</span> Atmospheric density for EDL and MAV performance</div>
                <div><span className="text-slate-500">Hazards:</span> Distance-weighted hazard count within 2 km</div>
                <div><span className="text-slate-500">Data Coverage:</span> Fraction of area with ≥1 HiRISE observation</div>
              </div>
              <div className="space-y-1">
                <div className="text-slate-300 font-medium mb-1">Limitations</div>
                <div>▸ All scores are synthetic — not based on actual measurements</div>
                <div>▸ Landing and ascent require separate spacecraft-specific analysis</div>
                <div>▸ Wind shear, dust storms, and soil strength not modelled</div>
                <div>▸ Sub-meter terrain features below DTM resolution</div>
                <div>▸ Missing data degrades reliability of any affected score</div>
              </div>
            </div>
          </GlassPanel>
        </div>
      )}
    </div>
  );
}
