// AtlasX — Mars 2020 & Curiosity Geological Outcrop & Raw Image Feed
// Derived from NASA Mars 2020 (Perseverance at Jezero Crater) & Curiosity (Gale Crater).
// Open planetary pipelines: NASA Mars Trek, USGS Astrogeology Mars Maps, and NASA Raw Image Archive.

import React, { useState, useMemo } from 'react';
import {
  Camera,
  Layers,
  Sparkles,
  ExternalLink,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  Compass,
  Hammer,
  Database,
  Eye,
  Check,
} from 'lucide-react';
import { useAppStore } from '../../store/useAppStore';
import type { MarsOutcrop, OutcropCamera, SampleTube } from '../../types';
import DataBadge from '../ui/DataBadge';
import GlassPanel from '../ui/GlassPanel';

export const OutcropFeed: React.FC = () => {
  const { outcrops, updateSampleTube, theme, selectedRegion } = useAppStore();
  const isBright = theme === 'bright';

  const [selectedCamera, setSelectedCamera] = useState<OutcropCamera | 'all'>('all');
  const [selectedEra, setSelectedEra] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeOutcropId, setActiveOutcropId] = useState<string>(outcrops[0]?.id ?? '');

  // Filter outcrops
  const filteredOutcrops = useMemo(() => {
    return outcrops.filter((o) => {
      const matchesSearch =
        o.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        o.rockType.toLowerCase().includes(searchQuery.toLowerCase()) ||
        o.mineralogy.some((m) => m.toLowerCase().includes(searchQuery.toLowerCase()));

      const matchesEra = selectedEra === 'all' || o.geologicalEra === selectedEra;
      const matchesCamera =
        selectedCamera === 'all' || o.images.some((img) => img.camera === selectedCamera);

      return matchesSearch && matchesEra && matchesCamera;
    });
  }, [outcrops, searchQuery, selectedEra, selectedCamera]);

  const activeOutcrop = outcrops.find((o) => o.id === activeOutcropId) ?? filteredOutcrops[0];

  const handleAdvanceSampleStatus = (outcrop: MarsOutcrop) => {
    if (!outcrop.sampleTube) return;
    const current = outcrop.sampleTube.status;
    let next: SampleTube['status'] = 'abraded';
    if (current === 'empty') next = 'abraded';
    else if (current === 'abraded') next = 'cored_sealed';
    else if (current === 'cored_sealed') next = 'depot_cached';
    else if (current === 'depot_cached') next = 'depot_cached';

    updateSampleTube(outcrop.id, {
      status: next,
      solAcquired: outcrop.sampleTube.solAcquired ?? outcrop.sol,
      drillingDepthMm: next === 'cored_sealed' ? 65 : outcrop.sampleTube.drillingDepthMm,
    });
  };

  const getTubeBadge = (status: SampleTube['status']) => {
    switch (status) {
      case 'cored_sealed':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-500/15 border border-emerald-500/30 text-emerald-400">
            CORED & SEALED
          </span>
        );
      case 'depot_cached':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-violet-500/15 border border-violet-500/30 text-violet-400">
            DEPOT CACHED
          </span>
        );
      case 'abraded':
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-500/15 border border-amber-500/30 text-amber-400">
            RAT ABRADED
          </span>
        );
      default:
        return (
          <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-500/15 border border-slate-500/30 text-slate-400">
            SAMPLE TUBE READY
          </span>
        );
    }
  };

  return (
    <div className="flex flex-col gap-4 h-full">
      {/* Top Controls & Search Bar */}
      <div className={`p-3 rounded-lg border flex flex-wrap items-center justify-between gap-3 ${
        isBright ? 'bg-white border-slate-200' : 'bg-black/50 border-white/10'
      }`}>
        <div className="flex items-center gap-2 flex-1 min-w-[200px]">
          <Search size={14} className="text-slate-400" />
          <input
            type="text"
            placeholder="Search outcrops, lithologies, minerals..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className={`w-full bg-transparent text-xs outline-none ${
              isBright ? 'text-slate-900 placeholder-slate-400' : 'text-white placeholder-slate-500'
            }`}
          />
        </div>

        {/* Camera filters */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className={`text-[10px] font-mono uppercase ${isBright ? 'text-slate-500' : 'text-slate-400'}`}>Camera:</span>
          {(['all', 'Mastcam-Z', 'SuperCam', 'SHERLOC', 'PIXL', 'Navcam'] as const).map((cam) => (
            <button
              key={cam}
              onClick={() => setSelectedCamera(cam as any)}
              className={`px-2 py-0.5 rounded text-[10px] font-mono transition-colors ${
                selectedCamera === cam
                  ? 'bg-mars-orange text-white font-bold'
                  : isBright
                  ? 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  : 'bg-white/5 text-slate-400 hover:text-white hover:bg-white/10'
              }`}
            >
              {cam}
            </button>
          ))}
        </div>

        {/* Era filters */}
        <div className="flex items-center gap-1.5">
          <span className={`text-[10px] font-mono uppercase ${isBright ? 'text-slate-500' : 'text-slate-400'}`}>Era:</span>
          {(['all', 'Noachian', 'Hesperian', 'Amazonian'] as const).map((era) => (
            <button
              key={era}
              onClick={() => setSelectedEra(era)}
              className={`px-2 py-0.5 rounded text-[10px] font-mono transition-colors ${
                selectedEra === era
                  ? 'bg-cyan-600 text-white font-bold'
                  : isBright
                  ? 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                  : 'bg-white/5 text-slate-400 hover:text-white hover:bg-white/10'
              }`}
            >
              {era}
            </button>
          ))}
        </div>
      </div>

      {/* Main Outcrops List & Detailed Inspection Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 flex-1 min-h-0 overflow-y-auto">
        {/* Outcrop Cards List */}
        <div className="lg:col-span-5 flex flex-col gap-2.5 overflow-y-auto pr-1">
          {filteredOutcrops.map((outcrop) => {
            const isSelected = outcrop.id === activeOutcrop?.id;
            return (
              <div
                key={outcrop.id}
                onClick={() => setActiveOutcropId(outcrop.id)}
                className={`p-3 rounded-lg border cursor-pointer transition-all ${
                  isSelected
                    ? isBright
                      ? 'bg-orange-50/80 border-mars-orange shadow'
                      : 'bg-mars-orange/15 border-mars-orange'
                    : isBright
                    ? 'bg-white border-slate-200 hover:border-slate-300'
                    : 'bg-black/40 border-white/5 hover:border-white/15'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-mars-orange" />
                    <span className={`text-xs font-bold ${isBright ? 'text-slate-900' : 'text-white'}`}>
                      {outcrop.name}
                    </span>
                  </div>
                  <span className="text-[10px] font-mono text-cyan-400">Sol {outcrop.sol}</span>
                </div>

                <div className={`text-[11px] line-clamp-1 mb-2 ${isBright ? 'text-slate-600' : 'text-slate-300'}`}>
                  {outcrop.rockType}
                </div>

                <div className="flex items-center justify-between text-[10px] font-mono">
                  <span className={`px-1.5 py-0.5 rounded ${
                    outcrop.geologicalEra === 'Noachian'
                      ? 'bg-purple-500/15 text-purple-400'
                      : 'bg-blue-500/15 text-blue-400'
                  }`}>
                    {outcrop.geologicalEra}
                  </span>

                  <span className="text-amber-400">
                    Astrobiology: <strong>{outcrop.biosignaturePotential}</strong>
                  </span>
                </div>

                {outcrop.sampleTube && (
                  <div className="mt-2 pt-2 border-t border-white/5 flex items-center justify-between">
                    <span className="text-[9px] font-mono text-slate-400">{outcrop.sampleTube.tubeId}</span>
                    {getTubeBadge(outcrop.sampleTube.status)}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Selected Outcrop Detail Viewer */}
        {activeOutcrop && (
          <div className="lg:col-span-7 flex flex-col gap-3 overflow-y-auto">
            {/* Outcrop Header Card */}
            <div className={`p-4 rounded-lg border ${
              isBright ? 'bg-white border-slate-200' : 'bg-black/50 border-white/10'
            }`}>
              <div className="flex items-start justify-between gap-3 mb-2">
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className={`text-base font-bold ${isBright ? 'text-slate-900' : 'text-white'}`}>
                      {activeOutcrop.name}
                    </h2>
                    <DataBadge classification="observed" />
                  </div>
                  <p className={`text-xs mt-0.5 ${isBright ? 'text-slate-500' : 'text-slate-400'}`}>
                    {activeOutcrop.formation} | Sol {activeOutcrop.sol} | Elevation: {activeOutcrop.elevationM} m
                  </p>
                </div>

                <div className="text-right">
                  <div className="text-[10px] font-mono text-slate-400 uppercase">Compressive Strength</div>
                  <div className="text-sm font-mono font-bold text-amber-400">
                    {activeOutcrop.compressiveStrengthMpa} MPa (RAT Corable)
                  </div>
                </div>
              </div>

              {/* Curiosity/Perseverance Traverse Analogy */}
              <div className={`p-2.5 rounded border text-xs font-mono mb-3 ${
                isBright ? 'bg-slate-50 border-slate-200 text-slate-700' : 'bg-navy-950/40 border-white/5 text-slate-300'
              }`}>
                <span className="text-mars-orange font-bold mr-1">Rover Traverse Analogy:</span>
                {activeOutcrop.curiosityPerseveranceAnalogy}
              </div>

              {/* Sample Tube Workflow Interactive Box */}
              {activeOutcrop.sampleTube && (
                <div className={`p-3 rounded-lg border flex flex-wrap items-center justify-between gap-3 ${
                  isBright ? 'bg-amber-50/70 border-amber-200' : 'bg-amber-500/10 border-amber-500/30'
                }`}>
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-amber-500/20 flex items-center justify-center">
                      <Hammer className="w-4 h-4 text-amber-500" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className={`text-xs font-bold ${isBright ? 'text-slate-900' : 'text-white'}`}>
                          Sample Caching: {activeOutcrop.sampleTube.targetName}
                        </span>
                        {getTubeBadge(activeOutcrop.sampleTube.status)}
                      </div>
                      <div className="text-[11px] font-mono text-slate-400">
                        Lithology: {activeOutcrop.sampleTube.lithology} | Tube ID: {activeOutcrop.sampleTube.tubeId}
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => handleAdvanceSampleStatus(activeOutcrop)}
                    className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-black text-xs font-bold rounded shadow transition-all flex items-center gap-1.5"
                  >
                    <CheckCircle2 size={13} />
                    {activeOutcrop.sampleTube.status === 'empty'
                      ? 'Initiate RAT Abrasion'
                      : activeOutcrop.sampleTube.status === 'abraded'
                      ? 'Core & Seal Tube'
                      : activeOutcrop.sampleTube.status === 'cored_sealed'
                      ? 'Cache at Surface Depot'
                      : 'Sample Tube Sealed & Deposited'}
                  </button>
                </div>
              )}
            </div>

            {/* Mineralogy & Spectral Features */}
            <div className={`p-3.5 rounded-lg border ${
              isBright ? 'bg-white border-slate-200' : 'bg-black/50 border-white/10'
            }`}>
              <div className="text-xs font-bold font-mono uppercase text-slate-400 mb-2 flex items-center gap-1.5">
                <Sparkles size={13} className="text-purple-400" />
                Detected Mineral Signatures & Absorption Bands
              </div>

              <div className="flex flex-wrap gap-1.5 mb-3">
                {activeOutcrop.mineralogy.map((m, i) => (
                  <span
                    key={i}
                    className="px-2 py-0.5 rounded text-[11px] font-mono bg-purple-500/15 border border-purple-500/30 text-purple-300"
                  >
                    {m}
                  </span>
                ))}
              </div>

              {/* Spectral bands table */}
              <div className="space-y-1 font-mono text-xs">
                {activeOutcrop.spectralFeatures.map((spec, i) => (
                  <div
                    key={i}
                    className={`flex items-center justify-between p-1.5 rounded ${
                      isBright ? 'bg-slate-50' : 'bg-white/5'
                    }`}
                  >
                    <span className="text-cyan-400 font-bold">{spec.bandMicrons.toFixed(2)} µm</span>
                    <span className={isBright ? 'text-slate-700' : 'text-slate-300'}>{spec.mineralOrBond}</span>
                    <span className="text-[10px] text-amber-400 uppercase">{spec.intensity}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Raw Camera Feeds & Images */}
            <div className={`p-3.5 rounded-lg border ${
              isBright ? 'bg-white border-slate-200' : 'bg-black/50 border-white/10'
            }`}>
              <div className="text-xs font-bold font-mono uppercase text-slate-400 mb-2 flex items-center gap-1.5">
                <Camera size={13} className="text-cyan-400" />
                NASA Mars 2020 Raw Image Feeds ({activeOutcrop.images.length} feeds)
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {activeOutcrop.images.map((img, idx) => (
                  <div
                    key={idx}
                    className={`p-2.5 rounded border flex flex-col justify-between gap-2 ${
                      isBright ? 'bg-slate-50 border-slate-200' : 'bg-navy-950/30 border-white/5'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span className="px-1.5 py-0.5 rounded text-[10px] font-mono font-bold bg-cyan-500/20 text-cyan-300">
                          {img.camera}
                        </span>
                        {img.resolutionMmPx && (
                          <span className="text-[10px] font-mono text-slate-400">
                            {img.resolutionMmPx} mm/px
                          </span>
                        )}
                      </div>
                      <p className={`text-[11px] ${isBright ? 'text-slate-600' : 'text-slate-300'}`}>
                        {img.description}
                      </p>
                    </div>

                    <div className="text-[10px] font-mono text-slate-500">
                      Filter: {img.filterOrWavelength ?? 'Broadband RGB'}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Open Planetary Pipelines & Framework Citations */}
            <div className={`p-3 rounded-lg border text-xs font-mono flex flex-wrap items-center justify-between gap-3 ${
              isBright ? 'bg-slate-100/70 border-slate-200 text-slate-600' : 'bg-black/40 border-white/5 text-slate-400'
            }`}>
              <div className="flex items-center gap-2">
                <Database size={13} className="text-mars-orange" />
                <span>Open Data Pipelines:</span>
              </div>

              <div className="flex items-center gap-3">
                <a
                  href={activeOutcrop.openDataSources.marsTrekUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-1 text-cyan-400 hover:underline"
                >
                  NASA Mars Trek <ExternalLink size={10} />
                </a>
                <a
                  href={activeOutcrop.openDataSources.pdsArchiveUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-1 text-purple-400 hover:underline"
                >
                  NASA PDS Geosciences <ExternalLink size={10} />
                </a>
                <a
                  href={activeOutcrop.openDataSources.rawImageFeedUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-1 text-amber-400 hover:underline"
                >
                  Mars 2020 Raw Feed <ExternalLink size={10} />
                </a>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default OutcropFeed;
