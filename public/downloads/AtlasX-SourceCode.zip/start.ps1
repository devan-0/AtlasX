# Windows PowerShell startup script for AtlasX
# Double-click or run from PowerShell

$NODE = "C:\Users\valiy\tools\node-v20.18.0-win-x64"
$PROJECT = Split-Path -Parent $MyInvocation.MyCommand.Path

if (-not (Get-Command "node" -ErrorAction SilentlyContinue)) {
    if (Test-Path $NODE) {
        $env:PATH = "$NODE;$env:PATH"
        Write-Host "Using portable Node.js from $NODE" -ForegroundColor Cyan
    } else {
        Write-Error "Node.js not found. Please install from https://nodejs.org/"
        exit 1
    }
}

Write-Host ""
Write-Host "  ATLASX — Planetary Explorer" -ForegroundColor Red
Write-Host "  NASA Space Apps Challenge 2026" -ForegroundColor DarkRed
Write-Host ""

Set-Location $PROJECT

if (-not (Test-Path "node_modules")) {
    Write-Host "Installing dependencies..." -ForegroundColor Yellow
    npm install
}

Write-Host "Starting development server..." -ForegroundColor Green
Write-Host "Opening http://localhost:5173 in your browser..." -ForegroundColor Cyan
Write-Host ""
Write-Host "Press Ctrl+C to stop the server." -ForegroundColor Gray
Write-Host ""

# Try to open browser after short delay
Start-Job -ScriptBlock { Start-Sleep 3; Start-Process "http://localhost:5173" } | Out-Null

npm run dev
