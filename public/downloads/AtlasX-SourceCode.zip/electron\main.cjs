/**
 * AtlasX — Electron Main Process
 *
 * Responsibilities:
 *  1. Locate and spawn the bundled Python backend (mars_backend.exe)
 *  2. Wait until the backend is ready (health-check polling)
 *  3. Open the BrowserWindow loading the bundled frontend (dist/index.html)
 *  4. Shut the backend down cleanly when the app closes
 */

const { app, BrowserWindow, shell, ipcMain, dialog } = require('electron');
const path  = require('path');
const fs    = require('fs');
const http  = require('http');
const { spawn, execSync } = require('child_process');

// ── Constants ────────────────────────────────────────────────────────────────

const BACKEND_PORT = 8765;          // use non-standard port to avoid conflict
const BACKEND_URL  = `http://127.0.0.1:${BACKEND_PORT}`;
const HEALTH_ENDPOINT = `${BACKEND_URL}/api/health`;
const HEALTH_POLL_MS  = 500;
const HEALTH_TIMEOUT_MS = 30000;    // give backend 30s to start

const isDev  = !app.isPackaged;
const ROOT   = isDev
  ? path.join(__dirname, '..')           // project root during dev
  : path.join(process.resourcesPath);   // packaged: extra-resources land here

// ── State ────────────────────────────────────────────────────────────────────

let mainWindow   = null;
let backendProc  = null;
let backendReady = false;

// ── Helpers ──────────────────────────────────────────────────────────────────

// Write log next to the executable so we can find it regardless of userData path
const LOG_FILE = path.join(path.dirname(process.execPath), 'mars-debug.log');

function log(...args) {
  const ts = new Date().toISOString();
  const msg = `[${ts}] ${args.join(' ')}`;
  console.log(msg);
  try { fs.appendFileSync(LOG_FILE, msg + '\n'); } catch (e) {
    // fallback: try desktop
    try { fs.appendFileSync(path.join(require('os').homedir(), 'Desktop', 'mars-debug.log'), msg + '\n'); } catch (_) {}
  }
}

/** Kill any process already occupying BACKEND_PORT (Windows). */
function killPort(port) {
  try {
    const out = execSync(`netstat -ano | findstr :${port}`, { encoding: 'utf8' });
    const pids = [...new Set(
      out.split('\n')
        .map(l => l.trim().split(/\s+/).pop())
        .filter(p => /^\d+$/.test(p) && p !== '0')
    )];
    pids.forEach(pid => {
      try { execSync(`taskkill /PID ${pid} /F`); log(`Killed PID ${pid} on port ${port}`); }
      catch (_) { /* already dead */ }
    });
  } catch (_) { /* port was free */ }
}

/** Resolve path to the backend binary or Python script. */
function resolveBackend() {
  // 1. Packaged Windows exe (PyInstaller one-folder mode)
  const exePath = path.join(ROOT, 'backend', 'mars_backend', 'mars_backend.exe');
  if (fs.existsSync(exePath)) return { cmd: exePath, args: [], cwd: path.dirname(exePath) };

  // 2. Single-file PyInstaller exe
  const onefile = path.join(ROOT, 'backend', 'mars_backend.exe');
  if (fs.existsSync(onefile)) return { cmd: onefile, args: [], cwd: ROOT };

  // 3. Dev fallback — run Python directly
  const script = path.join(ROOT, 'backend', 'main.py');
  if (fs.existsSync(script)) {
    const python = process.platform === 'win32' ? 'python' : 'python3';
    return { cmd: python, args: [script], cwd: path.join(ROOT, 'backend') };
  }

  return null;
}

/** Start the FastAPI backend process. */
function startBackend() {
  killPort(BACKEND_PORT);

  const backend = resolveBackend();
  log(`ROOT=${ROOT} resourcesPath=${process.resourcesPath} isPackaged=${app.isPackaged}`);
  if (!backend) {
    log('WARNING: No backend binary found — continuing without real-time NASA data.');
    return;
  }

  const env = {
    ...process.env,
    MARS_BACKEND_PORT: String(BACKEND_PORT),
    NASA_API_KEY: process.env.NASA_API_KEY || 'DEMO_KEY',
  };

  log(`Spawning backend: ${backend.cmd} ${backend.args.join(' ')} cwd=${backend.cwd}`);
  try {
    backendProc = spawn(backend.cmd, backend.args, {
      cwd: backend.cwd,
      env,
      stdio: ['ignore', 'pipe', 'pipe'],
      detached: false,
    });

    backendProc.stdout.on('data', d => log('[backend]', d.toString().trim()));
    backendProc.stderr.on('data', d => log('[backend:err]', d.toString().trim()));
    backendProc.on('error', (err) => {
      log(`[backend:spawn-error] ${err.message}`);
    });
    backendProc.on('exit', (code, signal) => {
      log(`Backend exited: code=${code} signal=${signal}`);
      backendReady = false;
      backendProc  = null;
    });
  } catch (err) {
    log(`[backend:spawn-exception] ${err.message}`);
  }
}

/** Poll /api/health until the backend responds or timeout. */
function waitForBackend(timeoutMs = HEALTH_TIMEOUT_MS) {
  return new Promise((resolve) => {
    const deadline = Date.now() + timeoutMs;
    function poll() {
      if (Date.now() > deadline) {
        log('Backend did not respond within timeout — continuing without it.');
        resolve(false);
        return;
      }
      const req = http.get(HEALTH_ENDPOINT, { timeout: 1000 }, (res) => {
        if (res.statusCode === 200) {
          backendReady = true;
          log('Backend is ready ✓');
          resolve(true);
        } else {
          setTimeout(poll, HEALTH_POLL_MS);
        }
      });
      req.on('error', () => setTimeout(poll, HEALTH_POLL_MS));
      req.on('timeout', () => { req.destroy(); setTimeout(poll, HEALTH_POLL_MS); });
    }
    poll();
  });
}

/** Stop the backend process gracefully. */
function stopBackend() {
  if (!backendProc) return;
  log('Stopping backend…');
  try {
    if (process.platform === 'win32') {
      execSync(`taskkill /PID ${backendProc.pid} /T /F`);
    } else {
      backendProc.kill('SIGTERM');
    }
  } catch (_) { /* already gone */ }
  backendProc = null;
}

// ── Window ───────────────────────────────────────────────────────────────────

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1024,
    minHeight: 600,
    title: 'AtlasX',
    icon: path.join(__dirname, 'icon.ico'),
    backgroundColor: '#0d1421',
    show: false,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.cjs'),
      webSecurity: false, // Required for file:// ES module chunk imports & external NASA map tiles
      allowRunningInsecureContent: true,
    },
  });

  // Add renderer diagnostic logging
  mainWindow.webContents.on('did-fail-load', (event, errorCode, errorDescription, validatedURL) => {
    log(`[renderer:fail-load] code=${errorCode} error=${errorDescription} url=${validatedURL}`);
  });
  mainWindow.webContents.on('render-process-gone', (event, details) => {
    log(`[renderer:crashed] reason=${details.reason} exitCode=${details.exitCode}`);
  });
  mainWindow.webContents.on('console-message', (event, level, message, line, sourceId) => {
    log(`[renderer:console:${level}] ${message} (${sourceId}:${line})`);
  });

  // F12 or Ctrl+Shift+I toggle DevTools for debugging
  mainWindow.webContents.on('before-input-event', (event, input) => {
    if (input.key === 'F12' || (input.control && input.shift && (input.key === 'I' || input.key === 'i'))) {
      mainWindow.webContents.toggleDevTools();
    }
  });

  // Load the bundled Vite dist or dev server
  if (isDev) {
    mainWindow.loadURL('http://localhost:5173');
    mainWindow.webContents.openDevTools();
  } else {
    // In packaged app, __dirname is inside app.asar/electron, so .. goes to app.asar root
    const asarIndexPath = path.join(__dirname, '..', 'app', 'index.html');
    log(`Loading index.html from: ${asarIndexPath}`);
    mainWindow.loadFile(asarIndexPath).catch(err => {
      log(`[loadFile:error] ${err.message} — trying fallback relative load`);
      mainWindow.loadFile('app/index.html');
    });
  }

  // Show window after it's ready (avoids white flash)
  mainWindow.once('ready-to-show', () => {
    log('Window ready-to-show — displaying window');
    mainWindow.show();
    mainWindow.focus();
  });

  // Open external links in default browser, not in Electron
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });

  mainWindow.on('closed', () => { mainWindow = null; });
}


// ── App lifecycle ────────────────────────────────────────────────────────────

app.whenReady().then(() => {
  log('App ready — creating window & initializing backend…');
  createWindow();
  startBackend();
  waitForBackend().then(ready => {
    log(`Backend initialization finished: ready=${ready}`);
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send('backend-ready', { ready });
    }
  });

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  stopBackend();
  if (process.platform !== 'darwin') app.quit();
});

app.on('before-quit', () => stopBackend());
app.on('will-quit', () => stopBackend());

// IPC: let renderer query backend status
ipcMain.handle('backend-status', () => ({
  ready: backendReady,
  url: BACKEND_URL,
  port: BACKEND_PORT,
}));
