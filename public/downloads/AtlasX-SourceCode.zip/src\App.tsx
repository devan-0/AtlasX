import React, { Suspense, lazy, useEffect } from 'react';
import { useAppStore } from './store/useAppStore';
import LoadingSpinner from './components/ui/LoadingSpinner';
import AppIntro from './components/ui/AppIntro';
import { useBackendStatus } from './services/hooks';

// Lazy-loaded page components
const OverviewPage = lazy(() => import('./pages/OverviewPage'));
const AtlasPage = lazy(() => import('./pages/AtlasPage'));
const Terrain3DPage = lazy(() => import('./pages/Terrain3DPage'));
const RoutesPage = lazy(() => import('./pages/RoutesPage'));
const SciencePage = lazy(() => import('./pages/SciencePage'));
const MineralsPage = lazy(() => import('./pages/MineralsPage'));
const SolarPage = lazy(() => import('./pages/SolarPage'));
const AtmospherePage = lazy(() => import('./pages/AtmospherePage'));
const SuitabilityPage = lazy(() => import('./pages/SuitabilityPage'));
const ComparisonPage = lazy(() => import('./pages/ComparisonPage'));
const CataloguePage = lazy(() => import('./pages/CataloguePage'));
const MissionsPage = lazy(() => import('./pages/MissionsPage'));
const SettingsPage = lazy(() => import('./pages/SettingsPage'));

// Icons
import {
  LayoutDashboard, Map, Mountain, Route, FlaskConical,
  Layers, Sun, Wind, Shield, GitCompare, Database,
  Bookmark, Settings, ChevronLeft, ChevronRight, Rocket,
  Globe, AlertTriangle, Circle, Clock, RotateCcw, Calendar, Radio, Moon
} from 'lucide-react';
import { useRealTimeMarsClock } from './utils/marsTime';

type NavPage =
  | 'overview' | 'atlas' | 'terrain3d' | 'routes' | 'science'
  | 'minerals' | 'solar' | 'atmosphere' | 'suitability' | 'comparison'
  | 'catalogue' | 'missions' | 'settings';

const NAV_ITEMS: { id: NavPage; icon: React.ElementType; label: string; group?: string }[] = [
  { id: 'overview', icon: LayoutDashboard, label: 'Mission Overview' },
  { id: 'atlas', icon: Map, label: 'Interactive Atlas', group: 'Mapping' },
  { id: 'terrain3d', icon: Mountain, label: '3D Terrain', group: 'Mapping' },
  { id: 'routes', icon: Route, label: 'Marswalk Routes', group: 'Planning' },
  { id: 'science', icon: FlaskConical, label: 'Science Targets', group: 'Planning' },
  { id: 'minerals', icon: Layers, label: 'Minerals & Geology', group: 'Science' },
  { id: 'solar', icon: Sun, label: 'Solar Energy', group: 'Science' },
  { id: 'atmosphere', icon: Wind, label: 'Atmosphere & Wind', group: 'Science' },
  { id: 'suitability', icon: Shield, label: 'Landing Suitability', group: 'Analysis' },
  { id: 'comparison', icon: GitCompare, label: 'Site Comparison', group: 'Analysis' },
  { id: 'catalogue', icon: Database, label: 'Data Catalogue', group: 'Data' },
  { id: 'missions', icon: Bookmark, label: 'Saved Missions', group: 'Data' },
  { id: 'settings', icon: Settings, label: 'Settings & About' },
];

const PAGE_MAP: Record<NavPage, React.LazyExoticComponent<React.ComponentType<Record<string, unknown>>>> = {
  overview: OverviewPage,
  atlas: AtlasPage,
  terrain3d: Terrain3DPage,
  routes: RoutesPage,
  science: SciencePage,
  minerals: MineralsPage,
  solar: SolarPage,
  atmosphere: AtmospherePage,
  suitability: SuitabilityPage,
  comparison: ComparisonPage,
  catalogue: CataloguePage,
  missions: MissionsPage,
  settings: SettingsPage,
};

function Sidebar({ collapsed, onToggle }: { collapsed: boolean; onToggle: () => void }) {
  const { activePage, setActivePage, routes, scienceTargets, theme } = useAppStore();
  const isBright = theme === 'bright';

  const groups = [...new Set(NAV_ITEMS.map(n => n.group).filter(Boolean))];
  const ungrouped = NAV_ITEMS.filter(n => !n.group);

  const renderItem = (item: typeof NAV_ITEMS[0]) => {
    const active = activePage === item.id;
    const Icon = item.icon;
    return (
      <button
        key={item.id}
        onClick={() => setActivePage(item.id)}
        title={collapsed ? item.label : undefined}
        className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-md text-sm font-medium transition-all duration-150 group relative
          ${active
            ? isBright
              ? 'bg-orange-50 border border-orange-200 text-orange-600 font-semibold shadow-sm'
              : 'bg-mars-600/20 border border-mars-600/30 text-orange-400 font-semibold'
            : isBright
              ? 'text-slate-600 hover:text-slate-900 hover:bg-slate-100 border border-transparent'
              : 'text-slate-400 hover:text-slate-100 hover:bg-white/5 border border-transparent'
          }`}
      >
        <Icon size={16} className={`flex-shrink-0 ${active ? (isBright ? 'text-orange-600' : 'text-mars-400') : ''}`} />
        {!collapsed && <span className="truncate">{item.label}</span>}
        {collapsed && (
          <span className={`absolute left-full ml-2 px-2 py-1 text-xs rounded shadow-lg whitespace-nowrap pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity z-50 ${
            isBright ? 'bg-white border border-slate-200 text-slate-800' : 'bg-navy-900 border border-white/10 text-slate-200'
          }`}>
            {item.label}
          </span>
        )}
      </button>
    );
  };

  return (
    <aside
      className={`flex flex-col border-r transition-all duration-200 flex-shrink-0 ${
        isBright ? 'bg-white border-slate-200 shadow-sm' : 'bg-navy-900 border-white/5'
      }`}
      style={{ width: collapsed ? 64 : 220 }}
    >
      {/* Brand */}
      <div className={`flex items-center gap-2.5 px-3 py-4 border-b ${isBright ? 'border-slate-200' : 'border-white/5'} ${collapsed ? 'justify-center' : ''}`}>
        <div className="flex-shrink-0 w-8 h-8 rounded-lg bg-mars-600/30 border border-mars-600/40 flex items-center justify-center">
          <Rocket size={16} className="text-mars-400" />
        </div>
        {!collapsed && (
          <div>
            <div className={`text-sm font-black tracking-widest leading-none ${isBright ? 'text-slate-800' : 'text-slate-100'}`}>ATLAS<span className="text-mars-400">X</span></div>
            <div className={`text-[9px] font-semibold tracking-wider leading-none mt-1 ${isBright ? 'text-slate-500' : 'text-slate-400'}`}>SURFACE INTELLIGENCE PLATFORM</div>
          </div>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-2 px-2 space-y-0.5">
        {ungrouped.filter(n => n.id !== 'settings').map(renderItem)}

        {groups.map(group => (
          <div key={group} className="mt-3">
            {!collapsed && (
              <div className="px-3 mb-1">
                <span className={`text-[10px] font-semibold uppercase tracking-widest ${isBright ? 'text-slate-400' : 'text-slate-600'}`}>{group}</span>
              </div>
            )}
            {!collapsed && <div className={`h-px mb-1.5 mx-1 ${isBright ? 'bg-slate-200' : 'bg-white/5'}`} />}
            {NAV_ITEMS.filter(n => n.group === group).map(renderItem)}
          </div>
        ))}
      </nav>

      {/* Footer */}
      <div className={`border-t px-2 py-2 space-y-0.5 ${isBright ? 'border-slate-200' : 'border-white/5'}`}>
        {renderItem(NAV_ITEMS.find(n => n.id === 'settings')!)}
        {!collapsed && (
          <div className="px-3 pt-1">
            <div className={`text-[9px] font-mono ${isBright ? 'text-slate-500 font-medium' : 'text-slate-400'}`}>AtlasX v1.0.0 · Independent Research Platform</div>
          </div>
        )}
      </div>

      {/* Collapse toggle */}
      <button
        onClick={onToggle}
        className={`flex items-center justify-center py-2 border-t transition-colors ${
          isBright
            ? 'border-slate-200 text-slate-500 hover:text-slate-800 hover:bg-slate-100'
            : 'border-white/5 text-slate-500 hover:text-slate-300 hover:bg-white/5'
        }`}
      >
        {collapsed ? <ChevronRight size={14} /> : <ChevronLeft size={14} />}
      </button>
    </aside>
  );
}

function TopToolbar() {
  const {
    selectedRegion,
    setSelectedRegion,
    regions,
    selectedDate,
    setSelectedDate,
    isLiveDate,
    syncToLive,
    layers,
    routes,
    scienceTargets,
    theme,
    toggleTheme,
  } = useAppStore();
  const { alive, checking } = useBackendStatus();
  const isBright = theme === 'bright';

  // Live Mars clock ticking every second
  const clock = useRealTimeMarsClock(
    selectedRegion.coordinates.lon,
    isLiveDate ? null : selectedDate,
    1000
  );

  return (
    <header className={`h-12 flex items-center gap-2.5 px-3 border-b flex-shrink-0 z-20 overflow-x-auto select-none backdrop-blur-md ${
      isBright
        ? 'border-slate-200 bg-white/95 text-slate-800 shadow-sm'
        : 'border-white/10 bg-navy-900/90 text-slate-100'
    }`}>
      {/* ── Region Selector + Local Mars Time (LMST) ── */}
      <div className={`flex items-center gap-1.5 border rounded-md px-2.5 py-1 ${
        isBright ? 'bg-slate-50 border-slate-200' : 'bg-white/5 border-white/10'
      }`}>
        <Globe size={13} className="text-amber-500 flex-shrink-0" />
        <select
          value={selectedRegion.id}
          onChange={(e) => {
            const r = regions.find((rg) => rg.id === e.target.value);
            if (r) setSelectedRegion(r);
          }}
          className={`bg-transparent text-xs font-semibold outline-none cursor-pointer max-w-[130px] truncate ${
            isBright ? 'text-slate-800' : 'text-slate-100'
          }`}
        >
          {regions.map((r) => (
            <option key={r.id} value={r.id} style={isBright ? { background: '#fff', color: '#0f172a' } : { background: '#0a1018', color: '#fff' }}>
              {r.name}
            </option>
          ))}
        </select>
        <span
          className={`text-[10px] font-mono px-1.5 py-0.5 rounded whitespace-nowrap ${
            isBright
              ? 'text-cyan-700 bg-cyan-50 border border-cyan-200 font-medium'
              : 'text-cyan-300 bg-cyan-950/60 border border-cyan-800/40'
          }`}
          title={`Local Mean Solar Time at longitude ${selectedRegion.coordinates.lon.toFixed(1)}°E`}
        >
          {clock.lmstFormatted}
        </span>
      </div>

      <div className={`h-5 w-px hidden md:block ${isBright ? 'bg-slate-200' : 'bg-white/10'}`} />

      {/* ── Live Astronomical Mission Telemetry ── */}
      <div className={`flex items-center gap-2.5 px-2.5 py-1 rounded-md border ${
        isBright ? 'bg-slate-50 border-slate-200' : 'bg-black/40 border-white/5'
      }`}>
        {/* Earth UTC */}
        <div className={`flex items-center gap-1 text-[11px] font-mono ${isBright ? 'text-slate-600' : 'text-slate-300'}`} title="Coordinated Universal Time (Earth UTC)">
          <Clock size={11} className={isBright ? 'text-blue-600 flex-shrink-0' : 'text-blue-400 flex-shrink-0'} />
          <span>{clock.utcDate}</span>
          <span className={isBright ? 'text-blue-700 font-semibold' : 'text-blue-300 font-semibold'}>{clock.utcTime}</span>
        </div>

        <span className={isBright ? 'text-slate-300' : 'text-white/20'}>|</span>

        {/* Mars Sol Date & MTC */}
        <div className="flex items-center gap-1.5 text-[11px] font-mono" title="Mars Sol Date (MSD) & Coordinated Mars Time (Airy-0 meridian)">
          <span className={`${isBright ? 'text-orange-600' : 'text-orange-400'} font-bold tracking-tight`}>{clock.msdFormatted}</span>
          <span className={isBright ? 'text-slate-400' : 'text-slate-400'}>·</span>
          <span className={`${isBright ? 'text-amber-600 font-semibold' : 'text-amber-300 font-semibold'}`}>{clock.mtcFormatted}</span>
        </div>

        <span className={`${isBright ? 'text-slate-300' : 'text-white/20'} hidden lg:inline`}>|</span>

        {/* Mars Year & Season */}
        <div className={`hidden lg:flex items-center gap-1 text-[11px] font-mono ${isBright ? 'text-slate-600' : 'text-slate-400'}`} title={`Mars Year and Areocentric Solar Longitude: ${clock.season}`}>
          <span className={`${isBright ? 'text-orange-600' : 'text-orange-300'} font-semibold`}>{clock.marsYearFormatted}</span>
          <span className="text-slate-400">·</span>
          <span className={isBright ? 'text-slate-700' : 'text-slate-300'}>{clock.lsFormatted}</span>
          <span className="text-[10px] text-slate-400 truncate max-w-[90px]">({clock.season.split('/')[0].trim()})</span>
        </div>
      </div>

      <div className={`h-5 w-px ${isBright ? 'bg-slate-200' : 'bg-white/10'}`} />

      {/* ── Live / Custom Date Picker & Sync ── */}
      <div className={`flex items-center gap-1.5 border rounded-md px-2 py-0.5 ${
        isBright ? 'bg-slate-50 border-slate-200' : 'bg-white/5 border-white/10'
      }`}>
        {isLiveDate ? (
          <div className={`flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-mono tracking-wider font-semibold ${
            isBright
              ? 'bg-emerald-100/70 border border-emerald-300 text-emerald-800'
              : 'bg-emerald-500/15 border border-emerald-500/30 text-emerald-300'
          }`}>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            LIVE
          </div>
        ) : (
          <button
            onClick={syncToLive}
            className={`flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-mono transition-colors font-semibold tracking-wider ${
              isBright
                ? 'bg-amber-100 border border-amber-300 text-amber-800 hover:bg-amber-200'
                : 'bg-amber-500/20 border border-amber-500/40 text-amber-300 hover:bg-amber-500/30'
            }`}
            title="Date is modified. Click to return to real-time clock."
          >
            <RotateCcw size={9} />
            SYNC LIVE
          </button>
        )}

        <input
          type="date"
          value={selectedDate}
          onChange={(e) => setSelectedDate(e.target.value)}
          className={`bg-transparent text-xs border-none outline-none cursor-pointer font-mono ${
            isBright ? 'text-slate-800' : 'text-slate-200'
          }`}
          style={{ colorScheme: isBright ? 'light' : 'dark' }}
          title="Jump to date or pick historical/future Mars sol"
        />
      </div>

      <div className="flex-1" />

      {/* ── Theme Switcher (Dark / Bright) ── */}
      <button
        onClick={toggleTheme}
        title={isBright ? 'Switch to Dark Mode' : 'Switch to Bright Mode'}
        className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md border text-xs font-mono font-medium transition-all ${
          isBright
            ? 'bg-amber-100/70 border-amber-300 text-amber-800 hover:bg-amber-200/70 shadow-sm'
            : 'bg-white/5 border-white/10 text-slate-300 hover:bg-white/10 hover:text-slate-100'
        }`}
      >
        {isBright ? (
          <>
            <Sun size={13} className="text-amber-600 flex-shrink-0" />
            <span className="font-semibold text-[11px] tracking-wide">BRIGHT</span>
          </>
        ) : (
          <>
            <Moon size={13} className="text-indigo-300 flex-shrink-0" />
            <span className="font-semibold text-[11px] tracking-wide">DARK</span>
          </>
        )}
      </button>

      {/* ── Counters ── */}
      <div className={`hidden xl:flex items-center gap-2.5 text-[11px] font-mono ${isBright ? 'text-slate-500' : 'text-slate-400'}`}>
        <span>{routes.length} routes</span>
        <span>·</span>
        <span>{scienceTargets.length} targets</span>
        <span>·</span>
        <span>{layers.filter((l) => l.visible).length} layers</span>
      </div>

      {/* ── Real-Time Planetary Telemetry Connectivity ── */}
      {checking ? (
        <div className={`flex items-center gap-1.5 px-2 py-1 rounded ${
          isBright ? 'bg-slate-100 border border-slate-200' : 'bg-slate-800/40 border border-slate-700/40'
        }`}>
          <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-pulse" />
          <span className={`text-[10px] font-mono uppercase tracking-wider ${isBright ? 'text-slate-600' : 'text-slate-400'}`}>Telemetry Sync…</span>
        </div>
      ) : alive ? (
        <div
          className={`flex items-center gap-1.5 px-2 py-1 rounded ${
            isBright ? 'bg-emerald-50 border border-emerald-300' : 'bg-emerald-500/10 border border-emerald-500/25'
          }`}
          title="FastAPI Desktop Service connected — Real-time JPL Horizons DE441 Ephemeris & InSight APSS active"
        >
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
          <span className={`text-[10px] font-mono font-semibold uppercase tracking-wider ${isBright ? 'text-emerald-700' : 'text-emerald-400'}`}>Live Telemetry (JPL)</span>
        </div>
      ) : (
        <div
          className={`flex items-center gap-1.5 px-2 py-1 rounded ${
            isBright ? 'bg-blue-50 border border-blue-200' : 'bg-blue-500/10 border border-blue-500/25'
          }`}
          title="Local precision engine active — running standard GISS Mars24 astronomical model"
        >
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-500 animate-pulse" />
          <span className={`text-[10px] font-mono font-semibold uppercase tracking-wider ${isBright ? 'text-cyan-700' : 'text-cyan-300'}`}>Astro Engine (DE441)</span>
        </div>
      )}
    </header>
  );
}

function StatusBar() {
  const { selectedRegion, routes, scienceTargets, activeMissionId, savedMissions, isLiveDate, selectedDate, theme } = useAppStore();
  const activeMission = savedMissions.find((m) => m.id === activeMissionId);
  const clock = useRealTimeMarsClock(selectedRegion.coordinates.lon, isLiveDate ? null : selectedDate, 1000);
  const isBright = theme === 'bright';

  return (
    <footer className={`h-7 flex items-center gap-3 px-4 border-t flex-shrink-0 text-[10px] font-mono select-none overflow-x-auto ${
      isBright
        ? 'border-slate-200 bg-white/95 text-slate-600 shadow-sm'
        : 'border-white/5 bg-navy-950/95 text-slate-400'
    }`}>
      <span className="flex items-center gap-1.5 flex-shrink-0">
        <span className={`w-1.5 h-1.5 rounded-full ${activeMission ? 'bg-emerald-500' : 'bg-slate-400'}`} />
        <span className={isBright ? 'text-slate-800 font-medium' : 'text-slate-300'}>{activeMission ? activeMission.name : 'No active mission'}</span>
      </span>

      <span className={isBright ? 'text-slate-300' : 'text-slate-700'}>|</span>

      <span className="flex-shrink-0">
        Region: <span className={`${isBright ? 'text-slate-900' : 'text-slate-200'} font-semibold`}>{selectedRegion.name}</span>{' '}
        <span className={isBright ? 'text-slate-400' : 'text-slate-500'}>
          ({Math.abs(selectedRegion.coordinates.lat).toFixed(2)}°{selectedRegion.coordinates.lat >= 0 ? 'N' : 'S'},{' '}
          {Math.abs(selectedRegion.coordinates.lon).toFixed(2)}°{selectedRegion.coordinates.lon >= 0 ? 'E' : 'W'})
        </span>
      </span>

      <span className={isBright ? 'text-slate-300' : 'text-slate-700'}>|</span>

      <span className={`flex-shrink-0 ${isBright ? 'text-cyan-700 font-semibold' : 'text-cyan-400'}`}>
        Local Solar: {clock.lmstFormatted}
      </span>

      <span className={isBright ? 'text-slate-300' : 'text-slate-700'}>|</span>

      <span className={`flex-shrink-0 ${isBright ? 'text-slate-700' : 'text-slate-300'}`}>
        {routes.length} routes · {scienceTargets.length} targets
      </span>

      <div className="flex-1" />

      <span className={`flex items-center gap-1.5 flex-shrink-0 ${isBright ? 'text-slate-500' : 'text-slate-400'}`}>
        <span>Sun Distance: <strong className={isBright ? 'text-slate-800' : 'text-slate-200'}>{clock.distanceAu.toFixed(3)} AU</strong></span>
        <span className={isBright ? 'text-slate-300' : 'text-slate-700'}>·</span>
        <span>Solar Flux: <strong className={isBright ? 'text-amber-600' : 'text-amber-300'}>{clock.irradianceWm2.toFixed(1)} W/m²</strong></span>
      </span>

      <span className={isBright ? 'text-slate-300' : 'text-slate-700'}>|</span>

      <span className={`${isBright ? 'text-orange-600 font-semibold' : 'text-orange-400/80'} uppercase tracking-wider flex-shrink-0`}>
        AtlasX · Independent Research Platform
      </span>
    </footer>
  );
}

interface ErrorBoundaryProps {
  children: React.ReactNode;
  page: string;
  onNavigateHome: () => void;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
  errorInfo: React.ErrorInfo | null;
}

class PageErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error: Error): Partial<ErrorBoundaryState> {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error(`[App:ErrorBoundary] Error rendering page "${this.props.page}":`, error, errorInfo);
    this.setState({ errorInfo });
  }

  componentDidUpdate(prevProps: ErrorBoundaryProps) {
    if (prevProps.page !== this.props.page && this.state.hasError) {
      this.setState({ hasError: false, error: null, errorInfo: null });
    }
  }

  handleRetry = () => {
    this.setState({ hasError: false, error: null, errorInfo: null });
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="flex flex-col items-center justify-center h-full p-6 text-center select-none overflow-y-auto">
          <div className="max-w-md w-full glass-panel p-6 border border-red-500/30 text-left space-y-4 shadow-2xl">
            <div className="flex items-center gap-2.5 text-red-400">
              <AlertTriangle size={20} className="flex-shrink-0" />
              <div>
                <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wider">Module Loading Notice</h3>
                <p className="text-[11px] text-red-300 font-mono">Module: {this.props.page}</p>
              </div>
            </div>

            <div className="text-xs text-slate-300 leading-relaxed">
              An unexpected condition occurred while rendering this module. You can retry loading or return to Mission Overview.
            </div>

            {this.state.error && (
              <div className="bg-navy-950/80 p-2.5 rounded border border-white/10 font-mono text-[10px] text-red-300 break-words max-h-32 overflow-y-auto">
                {this.state.error.message || String(this.state.error)}
              </div>
            )}

            <div className="flex items-center gap-2 pt-2 border-t border-white/10">
              <button
                onClick={this.handleRetry}
                className="flex-1 py-1.5 px-3 rounded text-xs font-semibold bg-mars-600/30 border border-mars-500/50 text-orange-200 hover:bg-mars-600/40 transition-colors"
              >
                Retry Module
              </button>
              <button
                onClick={this.props.onNavigateHome}
                className="flex-1 py-1.5 px-3 rounded text-xs font-semibold bg-white/10 border border-white/20 text-slate-200 hover:bg-white/15 transition-colors"
              >
                Mission Overview
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

export default function App() {
  const { activePage, setActivePage, sidebarCollapsed, toggleSidebar, showIntro, setShowIntro, theme } = useAppStore();
  const ActivePage = PAGE_MAP[activePage] || PAGE_MAP.overview;
  const isBright = theme === 'bright';

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    if (theme === 'bright') {
      document.documentElement.classList.add('theme-bright');
      document.documentElement.classList.remove('theme-dark');
    } else {
      document.documentElement.classList.add('theme-dark');
      document.documentElement.classList.remove('theme-bright');
    }
  }, [theme]);

  return (
    <div className={`flex flex-col h-screen overflow-hidden relative ${
      isBright ? 'theme-bright bg-slate-100 text-slate-800' : 'theme-dark bg-navy-950 text-slate-100'
    }`}>
      {showIntro && <AppIntro onComplete={() => setShowIntro(false)} />}
      <TopToolbar />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar collapsed={sidebarCollapsed} onToggle={toggleSidebar} />
        <main className={`flex-1 overflow-hidden flex flex-col min-h-0 ${isBright ? 'bg-slate-50' : 'bg-grid-fine'}`}>
          <PageErrorBoundary page={activePage} onNavigateHome={() => setActivePage('overview')}>
            <Suspense fallback={
              <div className="flex items-center justify-center h-full">
                <div className="flex flex-col items-center gap-3">
                  <div className="w-8 h-8 border-2 border-mars-500 border-t-transparent rounded-full animate-spin" />
                  <span className={`text-sm font-mono ${isBright ? 'text-slate-600' : 'text-slate-400'}`}>Loading module...</span>
                </div>
              </div>
            }>
              <ActivePage />
            </Suspense>
          </PageErrorBoundary>
        </main>
      </div>
      <StatusBar />
    </div>
  );
}
