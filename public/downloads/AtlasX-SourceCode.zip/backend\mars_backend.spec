# -*- mode: python ; coding: utf-8 -*-
"""
PyInstaller spec for AtlasX backend.
Produces: backend/dist/mars_backend/mars_backend.exe
Run with:  pyinstaller mars_backend.spec  (from the backend/ directory)
"""

import sys
import os

block_cipher = None

a = Analysis(
    ['main.py'],
    pathex=['.'],
    binaries=[],
    datas=[],
    hiddenimports=[
        # FastAPI / Starlette internals
        'fastapi',
        'fastapi.middleware.cors',
        'fastapi.responses',
        'starlette',
        'starlette.middleware',
        'starlette.middleware.cors',
        'starlette.responses',
        'starlette.routing',
        # Uvicorn
        'uvicorn',
        'uvicorn.main',
        'uvicorn.protocols',
        'uvicorn.protocols.http',
        'uvicorn.protocols.http.h11_impl',
        'uvicorn.protocols.http.httptools_impl',
        'uvicorn.protocols.websockets',
        'uvicorn.protocols.websockets.auto',
        'uvicorn.protocols.websockets.websockets_impl',
        'uvicorn.protocols.websockets.wsproto_impl',
        'uvicorn.lifespan',
        'uvicorn.lifespan.on',
        'uvicorn.logging',
        'uvicorn.config',
        'uvicorn.loops',
        'uvicorn.loops.auto',
        'uvicorn.loops.asyncio',
        # HTTP client
        'httpx',
        'httpcore',
        # Pydantic v2
        'pydantic',
        'pydantic.main',
        'pydantic_core',
        # Encoders
        'anyio',
        'anyio.abc',
        'anyio._backends._asyncio',
        'sniffio',
        'h11',
        'email_validator',
        # Standard library helpers
        'asyncio',
        'json',
        'math',
        're',
        'os',
        'datetime',
        'typing',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=['tkinter', 'matplotlib', 'numpy', 'scipy', 'PIL', 'cv2'],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='mars_backend',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,       # UPX can trigger AV false positives — skip for now
    console=True,    # keep console for log visibility; set False for silent
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=False,
    upx_exclude=[],
    name='mars_backend',
)
