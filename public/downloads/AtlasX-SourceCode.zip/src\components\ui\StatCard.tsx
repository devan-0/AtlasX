import React from 'react';
import type { DataClassification } from '../../types';

interface Props {
  label: string;
  value: string | number;
  unit?: string;
  icon?: React.ReactNode;
  trend?: 'up' | 'down' | 'neutral';
  classification?: DataClassification;
  className?: string;
}

const TREND_ICONS = {
  up: '↑',
  down: '↓',
  neutral: '→',
};

const TREND_COLORS = {
  up: 'text-emerald-400',
  down: 'text-red-400',
  neutral: 'text-slate-400',
};

export default function StatCard({ label, value, unit, icon, trend, classification, className = '' }: Props) {
  return (
    <div className={`glass-panel p-3 flex flex-col gap-1 ${className}`}>
      <div className="flex items-center gap-1.5">
        {icon && <span className="text-slate-500">{icon}</span>}
        <span className="text-[10px] text-slate-500 uppercase tracking-widest font-medium">{label}</span>
      </div>
      <div className="flex items-end gap-1.5">
        <span className="text-xl font-bold font-mono text-slate-100 leading-none">
          {typeof value === 'number' ? value.toLocaleString() : value}
        </span>
        {unit && <span className="text-xs text-slate-500 mb-0.5">{unit}</span>}
        {trend && (
          <span className={`text-sm mb-0.5 ${TREND_COLORS[trend]}`}>
            {TREND_ICONS[trend]}
          </span>
        )}
      </div>
    </div>
  );
}
