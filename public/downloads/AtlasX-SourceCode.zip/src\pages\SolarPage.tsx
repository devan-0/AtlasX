import React, { useMemo } from 'react';
import { LineChart, Line, AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import { useAppStore } from '../store/useAppStore';
import { computeSolarAnalysis, earthDateToLS, daylightDuration, dailySolarEnergy } from '../utils/solarGeometry';
import { useMarsEphemeris, useSeasonalCurve } from '../services/hooks';
import DataBadge from '../components/ui/DataBadge';
import GlassPanel from '../components/ui/GlassPanel';
import { Sun, AlertTriangle, Info, RefreshCw, Wifi, WifiOff } from 'lucide-react';

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="glass-panel p-2 text-xs space-y-0.5">
      <div className="text-slate-500">L_s = {label}°</div>
      {payload.map((p: any, i: number) => (
        <div key={i} style={{ color: p.color }}>{p.name}: {typeof p.value === 'number' ? p.value.toFixed(1) : p.value}</div>
      ))}
    </div>
  );
};

function LiveDataBanner({
  loading, error, source, retrievedAt, onRefetch,
}: {
  loading: boolean;
  error: string | null;
  source: string;
  retrievedAt: string | null;
  onRefetch: () => void;
}) {
  if (loading) {
    return (
      <div className="flex items-center gap-2 p-2.5 rounded-lg bg-blue-500/10 border border-blue-500/20 text-xs text-blue-300">
        <div className="w-3 h-3 border border-blue-400 border-t-transparent rounded-full animate-spin" />
        Fetching live orbital data from JPL Horizons…
      </div>
    );
  }

  if (error || source === 'unavailable') {
    return (
      <div className="flex items-center gap-2 p-2.5 rounded-lg bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300">
        <WifiOff size={13} className="flex-shrink-0" />
        <span>
          Backend unreachable — showing geometric fallback (DERIVED).{' '}
          <span className="text-slate-400">Start the API server: <code className="font-mono bg-black/30 px-1 rounded">cd backend && python main.py</code></span>
        </span>
        <button onClick={onRefetch} className="ml-auto flex-shrink-0 text-blue-400 hover:text-blue-300">
          <RefreshCw size={12} />
        </button>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-2 p-2.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-xs text-emerald-300">
      <Wifi size={13} className="flex-shrink-0" />
      <span>
        <strong>LIVE</strong> — Real Mars orbital data from JPL Horizons (DE441 ephemeris).
        {retrievedAt && <span className="text-slate-500 ml-2">Retrieved {new Date(retrievedAt).toLocaleTimeString()}</span>}
      </span>
      <button onClick={onRefetch} className="ml-auto flex-shrink-0 text-emerald-400 hover:text-emerald-300">
        <RefreshCw size={12} />
      </button>
    </div>
  );
}

export default function SolarPage() {
  const { mapCenter, selectedDate } = useAppStore();
  const lat = mapCenter.lat;
  const lon = mapCenter.lon;

  // ── Real-time data from JPL Horizons via backend ──────────────────────────
  const ephemeris = useMarsEphemeris(selectedDate);
  const seasonal = useSeasonalCurve();

  // ── Geometric fallback (always computed) ──────────────────────────────────
  const analysis = useMemo(() => computeSolarAnalysis(lat, lon, selectedDate), [lat, lon, selectedDate]);
  const ls_fallback = earthDateToLS(selectedDate);

  // Use live Ls if available, otherwise fall back to geometric
  const ls: number = ephemeris.data?.derived.solar_longitude_deg ?? ls_fallback;
  const irradiance: number = ephemeris.data?.derived.solar_irradiance_w_m2 ?? analysis.estimatedIrradianceWm2;
  const distAu: number = ephemeris.data?.derived.mars_sun_distance_au ?? 1.524;
  const season: string = ephemeris.data?.derived.season ?? 'Unknown';
  const eccentricity: number = ephemeris.data?.orbital_elements.eccentricity ?? 0.0934;
  const trueAnomaly: number = ephemeris.data?.orbital_elements.true_anomaly_deg ?? 0;
  const isLive = ephemeris.source === 'live';

  // Annual curve: use live data from backend if available, else compute locally
  const annualData = useMemo(() => {
    if (seasonal.data?.data && !seasonal.loading) {
      return seasonal.data.data.map(pt => ({
        ls: pt.ls_deg,
        irradiance: pt.irradiance_w_m2,
        daylight: parseFloat(daylightDuration(lat, pt.ls_deg).toFixed(2)),
        energy: parseFloat(dailySolarEnergy(lat, pt.ls_deg).toFixed(0)),
      }));
    }
    // fallback: local calculation every 10°
    return Array.from({ length: 37 }, (_, i) => {
      const l = i * 10;
      const ta_deg = ((l - 251.12) % 360 + 360) % 360;
      const ta_rad = (ta_deg * Math.PI) / 180;
      const r_au = 1.523662 * (1 - 0.0934123 ** 2) / (1 + 0.0934123 * Math.cos(ta_rad));
      return {
        ls: l,
        irradiance: parseFloat((1361 / r_au ** 2).toFixed(1)),
        daylight: parseFloat(daylightDuration(lat, l).toFixed(2)),
        energy: parseFloat(dailySolarEnergy(lat, l).toFixed(0)),
      };
    });
  }, [seasonal.data, seasonal.loading, lat]);

  // Daylight by latitude at current Ls
  const latData = useMemo(() =>
    Array.from({ length: 19 }, (_, i) => {
      const la = -90 + i * 10;
      return { lat: `${la}°`, daylight: parseFloat(daylightDuration(la, ls).toFixed(2)) };
    }), [ls]);

  const illumination = analysis.illuminationDurationH;
  const dataClassification = isLive ? 'observed' : 'derived';

  return (
    <div className="h-full overflow-y-auto p-4 space-y-4">
      {/* Live data banner */}
      <LiveDataBanner
        loading={ephemeris.loading}
        error={ephemeris.error}
        source={ephemeris.source}
        retrievedAt={ephemeris.retrievedAt}
        onRefetch={ephemeris.refetch}
      />

      {/* Real orbital facts panel — shown when live data is available */}
      {isLive && ephemeris.data && (
        <GlassPanel
          title="Live JPL Horizons Orbital Data"
          badge={<DataBadge classification="observed" />}
        >
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-x-6 gap-y-2 text-xs">
            {[
              { label: 'True Anomaly (ν)', value: `${trueAnomaly.toFixed(2)}°` },
              { label: 'Eccentricity (e)', value: eccentricity.toFixed(6) },
              { label: 'Mars–Sun Distance', value: `${distAu.toFixed(4)} AU` },
              { label: 'Semi-major Axis', value: `${(ephemeris.data.orbital_elements.semi_major_axis_km / 1e6).toFixed(4)} ×10⁶ km` },
            ].map(f => (
              <div key={f.label}>
                <div className="text-[9px] text-slate-600 uppercase tracking-wide">{f.label}</div>
                <div className="font-mono text-slate-200 font-semibold mt-0.5">{f.value}</div>
              </div>
            ))}
          </div>
          <div className="mt-2 text-[10px] text-slate-600">
            Source: JPL Horizons DE441 ephemeris · Date: {ephemeris.data.date} · {ephemeris.data.notes}
          </div>
        </GlassPanel>
      )}

      {/* Key metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          {
            label: 'Solar Longitude (Ls)',
            value: `${ls.toFixed(1)}°`,
            sub: season,
            badge: isLive ? 'derived' : 'derived',
          } as const,
          {
            label: 'Solar Irradiance (TOA)',
            value: `${irradiance.toFixed(0)} W/m²`,
            sub: `At ${distAu.toFixed(3)} AU from Sun`,
            badge: isLive ? 'derived' : 'derived',
          } as const,
          {
            label: 'Illumination',
            value: `${illumination.toFixed(1)} h/sol`,
            sub: illumination > 10 ? '✓ Good solar' : illumination > 6 ? '⚡ Adequate' : '⚠ Poor solar',
            badge: 'derived',
          } as const,
          {
            label: 'Solar Incidence',
            value: `${analysis.solarIncidenceDeg.toFixed(1)}°`,
            sub: `at ${lat.toFixed(2)}°N`,
            badge: 'derived',
          } as const,
        ].map((s, i) => (
          <div key={i} className="glass-panel p-3">
            <div className="flex items-center justify-between mb-1">
              <div className="text-[10px] text-slate-500 uppercase tracking-wide">{s.label}</div>
              <DataBadge classification={s.badge} />
            </div>
            <div className="text-lg font-bold font-mono text-slate-100 leading-tight">{s.value}</div>
            <div className="text-[10px] text-slate-500 mt-0.5">{s.sub}</div>
          </div>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <GlassPanel
          title={`Irradiance vs Solar Longitude${isLive ? ' — Live Horizons Curve' : ' — Geometric Model'}`}
          badge={
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] font-mono font-semibold text-amber-300 bg-amber-500/15 border border-amber-500/30 px-2 py-0.5 rounded">
                Ls {ls.toFixed(1)}° · {isLive ? 'Now (JPL Horizons)' : 'Now (Estimated)'}
              </span>
              <DataBadge classification={dataClassification} />
            </div>
          }
        >
          <ResponsiveContainer width="100%" height={180}>
            <AreaChart data={annualData} margin={{ top: 22, right: 15, bottom: 8, left: 35 }}>
              <CartesianGrid strokeDasharray="3,3" stroke="rgba(255,255,255,0.04)" />
              <XAxis dataKey="ls" tick={{ fill: '#64748b', fontSize: 9 }} label={{ value: 'Solar Longitude L_s (°)', position: 'insideBottom', offset: -2, fill: '#64748b', fontSize: 9 }} />
              <YAxis tick={{ fill: '#64748b', fontSize: 9 }} label={{ value: 'W/m²', angle: -90, position: 'insideLeft', fill: '#64748b', fontSize: 9 }} />
              <Tooltip content={<CustomTooltip />} />
              <ReferenceLine
                x={Math.round(ls / 10) * 10}
                stroke="#f59e0b"
                strokeWidth={1.5}
                strokeDasharray="4,2"
                label={{
                  value: `▶ Now (Ls ${ls.toFixed(1)}°)`,
                  fill: '#f59e0b',
                  fontSize: 10,
                  fontWeight: 600,
                  position: ls < 180 ? 'insideTopRight' : 'insideTopLeft',
                  offset: 8,
                }}
              />
              <Area type="monotone" dataKey="irradiance" name="Irradiance (W/m²)" stroke="#fbbf24" fill="rgba(251,191,36,0.15)" strokeWidth={2} dot={false} />
            </AreaChart>
          </ResponsiveContainer>
        </GlassPanel>

        <GlassPanel title="Illumination Hours per Sol vs L_s" badge={<DataBadge classification="derived" />}>
          <ResponsiveContainer width="100%" height={180}>
            <LineChart data={annualData} margin={{ top: 22, right: 15, bottom: 8, left: 25 }}>
              <CartesianGrid strokeDasharray="3,3" stroke="rgba(255,255,255,0.04)" />
              <XAxis dataKey="ls" tick={{ fill: '#64748b', fontSize: 9 }} />
              <YAxis tick={{ fill: '#64748b', fontSize: 9 }} domain={[0, 15]} />
              <Tooltip content={<CustomTooltip />} />
              <ReferenceLine y={6} stroke="#f59e0b" strokeDasharray="2,2" label={{ value: '6h min', fill: '#f59e0b', fontSize: 8, position: 'right' }} />
              <ReferenceLine
                x={Math.round(ls / 10) * 10}
                stroke="#f59e0b"
                strokeWidth={1.5}
                strokeDasharray="4,2"
                label={{
                  value: `▶ Now (Ls ${ls.toFixed(1)}°)`,
                  fill: '#f59e0b',
                  fontSize: 10,
                  fontWeight: 600,
                  position: ls < 180 ? 'insideTopRight' : 'insideTopLeft',
                  offset: 8,
                }}
              />
              <Line type="monotone" dataKey="daylight" name="Daylight (h/sol)" stroke="#22d3ee" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </GlassPanel>

        <GlassPanel title="Daily Solar Energy vs Latitude" badge={<DataBadge classification="derived" />}>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={latData} margin={{ top: 12, right: 10, bottom: 5, left: 30 }}>
              <CartesianGrid strokeDasharray="3,3" stroke="rgba(255,255,255,0.04)" />
              <XAxis dataKey="lat" tick={{ fill: '#64748b', fontSize: 8 }} />
              <YAxis tick={{ fill: '#64748b', fontSize: 9 }} label={{ value: 'h/sol', angle: -90, position: 'insideLeft', fill: '#64748b', fontSize: 9 }} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="daylight" name="Daylight (h/sol)" fill="#f46040" opacity={0.8} radius={[2, 2, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
          <div className="text-[10px] text-slate-400 mt-1 font-mono">
            Martian Solar Position: <span className="text-amber-400 font-semibold">L_s ≈ {ls.toFixed(1)}°</span> ({isLive ? 'JPL Horizons Ephemeris' : 'Keplerian Estimate'})
          </div>
        </GlassPanel>

        {/* Methodology */}
        <GlassPanel title="Methodology & Limitations">
          <div className="space-y-1.5 text-xs text-slate-400">
            <div className="flex items-start gap-2">
              <span className="text-emerald-400 flex-shrink-0">▸</span>
              <span>
                <strong className="text-slate-300">Orbital data:</strong>{' '}
                {isLive
                  ? 'Real Keplerian elements from JPL Horizons DE441 (observed ephemeris).'
                  : 'Geometric model using Mars mean orbital elements (e=0.0934).'}
              </span>
            </div>
            <div className="flex items-start gap-2">
              <span className="text-cyan-400 flex-shrink-0">▸</span>
              <span><strong className="text-slate-300">Irradiance:</strong> Inverse-square law from actual Mars–Sun distance. Top-of-atmosphere only.</span>
            </div>
            <div className="flex items-start gap-2">
              <span className="text-amber-400 flex-shrink-0">▸</span>
              <span><strong className="text-slate-300">Ls derivation:</strong> True anomaly → solar longitude using IAU perihelion offset (Lp ≈ 251°).</span>
            </div>
            {analysis.assumptions.map((a, i) => (
              <div key={i} className="flex items-start gap-2">
                <span className="text-slate-600 flex-shrink-0">▸</span>
                <span>{a}</span>
              </div>
            ))}
            <div className="mt-2 p-2 bg-amber-500/10 border border-amber-500/20 rounded text-[10px] text-amber-300">
              ⚠ No atmospheric dust opacity, terrain shadowing, or surface albedo modelled.
              Real solar power requires detailed engineering analysis.
            </div>
          </div>
        </GlassPanel>
      </div>
    </div>
  );
}
