import React, { useState, useMemo } from 'react';
import { useAppStore } from '../store/useAppStore';
import DataBadge from '../components/ui/DataBadge';
import GlassPanel from '../components/ui/GlassPanel';
import OutcropFeed from '../components/science/OutcropFeed';
import { FlaskConical, Star, Plus, Trash2, MapPin, Eye, Search, Filter, Camera, Sparkles } from 'lucide-react';
import type { ScienceCategory, ScienceTarget } from '../types';

const CATEGORY_COLORS: Record<ScienceCategory, string> = {
  mineralogy: '#a78bfa',
  geology: '#60a5fa',
  hydrology: '#34d399',
  geomorphology: '#f9a8d4',
  astrobiology: '#f87171',
  resource: '#fbbf24',
  atmospheric: '#67e8f9',
};

const CATEGORY_ICONS: Record<ScienceCategory, string> = {
  mineralogy: '💎',
  geology: '🪨',
  hydrology: '💧',
  geomorphology: '⛰️',
  astrobiology: '🧬',
  resource: '⚡',
  atmospheric: '🌬️',
};

const STATUS_CONFIG = {
  proposed:  { label: 'Proposed',  classes: 'bg-slate-500/15 text-slate-400 border border-slate-500/20' },
  planned:   { label: 'Planned',   classes: 'bg-blue-500/15 text-blue-400 border border-blue-500/20' },
  visited:   { label: 'Visited',   classes: 'bg-amber-500/15 text-amber-400 border border-amber-500/20' },
  completed: { label: 'Completed', classes: 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/20' },
};

function StarRating({ priority }: { priority: number }) {
  return (
    <div className="flex gap-0.5">
      {Array.from({ length: 5 }, (_, i) => (
        <Star key={i} size={10} className={i < priority ? 'text-amber-400 fill-amber-400' : 'text-slate-700'} />
      ))}
    </div>
  );
}

interface AddTargetFormProps { onAdd: (t: ScienceTarget) => void; onCancel: () => void; }
function AddTargetForm({ onAdd, onCancel }: AddTargetFormProps) {
  const [form, setForm] = useState({
    name: '', lat: '18.5', lon: '77.5',
    category: 'geology' as ScienceCategory,
    rationale: '', priority: 3,
    notes: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const target: ScienceTarget = {
      id: `st-custom-${Date.now()}`,
      name: form.name || 'Custom Target',
      coordinates: { lat: parseFloat(form.lat), lon: parseFloat(form.lon) },
      category: form.category,
      dataSource: 'User-defined',
      rationale: form.rationale || 'User-defined investigation target',
      observations: [],
      priority: form.priority as 1|2|3|4|5,
      dataQuality: 'low',
      uncertainty: 'User-defined target — no observational basis',
      missionStatus: 'proposed',
      notes: form.notes,
    };
    onAdd(target);
  };

  return (
    <form onSubmit={handleSubmit} className="glass-panel p-4 space-y-3">
      <div className="text-xs font-semibold text-slate-300 mb-1">Add Science Target</div>
      <div className="grid grid-cols-2 gap-2">
        <div className="col-span-2">
          <label className="text-[10px] text-slate-500 uppercase">Name</label>
          <input className="w-full bg-navy-900 border border-white/10 rounded px-2 py-1 text-xs text-slate-200" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Target name" />
        </div>
        <div>
          <label className="text-[10px] text-slate-500 uppercase">Latitude (°N)</label>
          <input type="number" step={0.001} className="w-full bg-navy-900 border border-white/10 rounded px-2 py-1 text-xs text-slate-200 font-mono" value={form.lat} onChange={e => setForm(f => ({ ...f, lat: e.target.value }))} />
        </div>
        <div>
          <label className="text-[10px] text-slate-500 uppercase">Longitude (°E)</label>
          <input type="number" step={0.001} className="w-full bg-navy-900 border border-white/10 rounded px-2 py-1 text-xs text-slate-200 font-mono" value={form.lon} onChange={e => setForm(f => ({ ...f, lon: e.target.value }))} />
        </div>
        <div>
          <label className="text-[10px] text-slate-500 uppercase">Category</label>
          <select className="w-full bg-navy-900 border border-white/10 rounded px-2 py-1 text-xs text-slate-200" value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value as ScienceCategory }))}>
            {(['mineralogy','geology','hydrology','geomorphology','astrobiology','resource','atmospheric'] as ScienceCategory[]).map(c => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="text-[10px] text-slate-500 uppercase">Priority (1–5)</label>
          <input type="number" min={1} max={5} className="w-full bg-navy-900 border border-white/10 rounded px-2 py-1 text-xs text-slate-200 font-mono" value={form.priority} onChange={e => setForm(f => ({ ...f, priority: parseInt(e.target.value) }))} />
        </div>
        <div className="col-span-2">
          <label className="text-[10px] text-slate-500 uppercase">Scientific Rationale</label>
          <textarea rows={2} className="w-full bg-navy-900 border border-white/10 rounded px-2 py-1 text-xs text-slate-200 resize-none" value={form.rationale} onChange={e => setForm(f => ({ ...f, rationale: e.target.value }))} placeholder="Why is this target scientifically interesting?" />
        </div>
      </div>
      <div className="flex gap-2">
        <button type="submit" className="px-3 py-1.5 bg-mars-600 hover:bg-mars-500 text-white text-xs rounded font-medium transition-colors">Add Target</button>
        <button type="button" onClick={onCancel} className="px-3 py-1.5 bg-white/5 hover:bg-white/10 text-slate-300 text-xs rounded transition-colors">Cancel</button>
      </div>
    </form>
  );
}

export default function SciencePage() {
  const { scienceTargets, selectedTargetId, setSelectedTarget, addScienceTarget, removeScienceTarget, theme } = useAppStore();
  const isBright = theme === 'bright';
  const [activeTab, setActiveTab] = useState<'targets' | 'outcrops'>('targets');
  const [filterCat, setFilterCat] = useState<ScienceCategory | 'all'>('all');
  const [filterPriority, setFilterPriority] = useState(0);
  const [search, setSearch] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);

  const filtered = useMemo(() => scienceTargets.filter(t => {
    if (filterCat !== 'all' && t.category !== filterCat) return false;
    if (filterPriority > 0 && t.priority < filterPriority) return false;
    if (search && !t.name.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  }), [scienceTargets, filterCat, filterPriority, search]);

  const selected = scienceTargets.find(t => t.id === selectedTargetId);
  const CATS: (ScienceCategory | 'all')[] = ['all', 'mineralogy', 'geology', 'hydrology', 'geomorphology', 'astrobiology', 'resource', 'atmospheric'];

  return (
    <div className="flex flex-col h-full overflow-hidden">
      {/* Top Tab Bar: Targets vs Mars 2020 Outcrops */}
      <div className={`flex items-center justify-between px-4 py-2.5 border-b backdrop-blur-md flex-shrink-0 ${
        isBright ? 'bg-white/80 border-slate-200' : 'bg-black/40 border-white/10'
      }`}>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('targets')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition-all ${
              activeTab === 'targets'
                ? 'bg-mars-orange text-white shadow'
                : isBright
                ? 'text-slate-600 hover:bg-slate-100'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <FlaskConical size={13} /> Science Targets & Astrobiology ({scienceTargets.length})
          </button>

          <button
            onClick={() => setActiveTab('outcrops')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition-all ${
              activeTab === 'outcrops'
                ? 'bg-cyan-600 text-white shadow'
                : isBright
                ? 'text-slate-600 hover:bg-slate-100'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <Camera size={13} /> Mars 2020 & Curiosity Outcrop Feeds & Sample Tubes
          </button>
        </div>

        <div className="hidden sm:flex items-center gap-2 text-[11px] font-mono text-slate-400">
          <span>Pipelines: <strong>NASA Mars Trek • PDS • Raw Image Streams</strong></span>
        </div>
      </div>

      {activeTab === 'outcrops' ? (
        <div className="flex-1 p-4 overflow-hidden">
          <OutcropFeed />
        </div>
      ) : (
        <div className="flex flex-1 overflow-hidden">
          {/* Left: list */}
          <div className="w-80 flex-shrink-0 flex flex-col border-r border-white/5 bg-navy-900/60">
        {/* Filters */}
        <div className="p-3 border-b border-white/5 space-y-2">
          <div className="flex items-center gap-2 bg-navy-900 border border-white/10 rounded px-2 py-1">
            <Search size={12} className="text-slate-500" />
            <input className="flex-1 bg-transparent text-xs text-slate-200 outline-none" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search targets…" />
          </div>
          <div className="flex gap-1 flex-wrap">
            {CATS.map(c => (
              <button key={c} onClick={() => setFilterCat(c)}
                className={`px-2 py-0.5 rounded text-[10px] font-medium capitalize transition-colors ${filterCat === c ? 'bg-mars-600/30 text-orange-400 border border-mars-600/30' : 'text-slate-500 hover:text-slate-300'}`}>
                {c}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-500">Min priority:</span>
            {[0,1,2,3,4,5].map(p => (
              <button key={p} onClick={() => setFilterPriority(p)}
                className={`w-5 h-5 rounded text-[10px] transition-colors ${filterPriority === p ? 'bg-amber-500/30 text-amber-400' : 'text-slate-600 hover:text-slate-300'}`}>
                {p === 0 ? 'All' : p}
              </button>
            ))}
          </div>
        </div>

        {/* List */}
        <div className="flex-1 overflow-y-auto">
          {filtered.map(t => (
            <button
              key={t.id}
              onClick={() => setSelectedTarget(t.id === selectedTargetId ? null : t.id)}
              className={`w-full text-left px-3 py-2.5 border-b border-white/5 transition-colors hover:bg-white/5 ${t.id === selectedTargetId ? 'bg-mars-600/10' : ''}`}
            >
              <div className="flex items-start gap-2">
                <span className="text-base flex-shrink-0 mt-0.5">{CATEGORY_ICONS[t.category]}</span>
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-medium text-slate-200 truncate">{t.name}</div>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <StarRating priority={t.priority} />
                    <span className={`text-[9px] px-1 py-0.5 rounded ${STATUS_CONFIG[t.missionStatus].classes}`}>
                      {STATUS_CONFIG[t.missionStatus].label}
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-500 font-mono mt-0.5">
                    {t.coordinates.lat.toFixed(3)}°N {t.coordinates.lon.toFixed(3)}°E
                  </div>
                </div>
              </div>
            </button>
          ))}
          {filtered.length === 0 && (
            <div className="flex flex-col items-center justify-center py-12 text-slate-600 text-xs gap-2">
              <FlaskConical size={24} />
              <span>No targets match filters</span>
            </div>
          )}
        </div>

        {/* Add / count */}
        <div className="p-3 border-t border-white/5 flex items-center justify-between">
          <span className="text-[10px] text-slate-500">{filtered.length} of {scienceTargets.length} targets</span>
          <button onClick={() => setShowAddForm(true)} className="flex items-center gap-1 px-2 py-1 bg-mars-600/20 hover:bg-mars-600/30 text-orange-400 text-xs rounded border border-mars-600/30 transition-colors">
            <Plus size={12} /> Add Target
          </button>
        </div>
      </div>

      {/* Right: detail or add form */}
      <div className="flex-1 p-4 overflow-y-auto">
        {showAddForm ? (
          <AddTargetForm onAdd={t => { addScienceTarget(t); setShowAddForm(false); setSelectedTarget(t.id); }} onCancel={() => setShowAddForm(false)} />
        ) : selected ? (
          <div className="max-w-2xl space-y-4">
            {/* Header */}
            <div className="flex items-start gap-3">
              <span className="text-3xl">{CATEGORY_ICONS[selected.category]}</span>
              <div className="flex-1">
                <h1 className="text-lg font-bold text-slate-100">{selected.name}</h1>
                <div className="flex items-center gap-2 mt-1 flex-wrap">
                  <span className="text-xs capitalize px-2 py-0.5 rounded-full border text-slate-300"
                    style={{ borderColor: CATEGORY_COLORS[selected.category] + '60', background: CATEGORY_COLORS[selected.category] + '15', color: CATEGORY_COLORS[selected.category] }}>
                    {selected.category}
                  </span>
                  <span className={`text-[10px] px-1.5 py-0.5 rounded ${STATUS_CONFIG[selected.missionStatus].classes}`}>
                    {STATUS_CONFIG[selected.missionStatus].label}
                  </span>
                  <DataBadge classification={selected.dataQuality === 'high' ? 'observed' : selected.dataQuality === 'medium' ? 'derived' : 'simulated'} />
                  <StarRating priority={selected.priority} />
                </div>
              </div>
              <button onClick={() => { removeScienceTarget(selected.id); }} className="flex items-center gap-1 px-2 py-1 text-xs text-red-400 hover:bg-red-500/10 rounded transition-colors">
                <Trash2 size={12} /> Remove
              </button>
            </div>

            {/* Coordinates */}
            <GlassPanel className="!p-3">
              <div className="grid grid-cols-3 gap-4 text-center">
                <div><div className="text-[10px] text-slate-500 uppercase">Latitude</div><div className="font-mono text-sm text-slate-100">{selected.coordinates.lat.toFixed(5)}°N</div></div>
                <div><div className="text-[10px] text-slate-500 uppercase">Longitude</div><div className="font-mono text-sm text-slate-100">{selected.coordinates.lon.toFixed(5)}°E</div></div>
                <div><div className="text-[10px] text-slate-500 uppercase">Est. Detour</div><div className="font-mono text-sm text-slate-100">{selected.estimatedDetourKm?.toFixed(1) ?? '—'} km</div></div>
              </div>
            </GlassPanel>

            {/* Rationale */}
            <GlassPanel title="Scientific Rationale">
              <p className="text-sm text-slate-300 leading-relaxed">{selected.rationale}</p>
            </GlassPanel>

            {/* Observations */}
            {selected.observations.length > 0 && (
              <GlassPanel title="Available Observations" badge={<DataBadge classification="simulated" />}>
                <ul className="space-y-1.5">
                  {selected.observations.map((obs, i) => (
                    <li key={i} className="flex items-start gap-2 text-xs text-slate-300">
                      <span className="text-orange-400 flex-shrink-0 mt-0.5">▸</span>
                      {obs}
                    </li>
                  ))}
                </ul>
              </GlassPanel>
            )}

            {/* Quality & uncertainty */}
            <GlassPanel title="Data Quality & Uncertainty">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-400">Data quality:</span>
                  <span className={`text-xs font-medium capitalize ${selected.dataQuality === 'high' ? 'text-emerald-400' : selected.dataQuality === 'medium' ? 'text-amber-400' : 'text-red-400'}`}>
                    {selected.dataQuality}
                  </span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">{selected.uncertainty}</p>
              </div>
            </GlassPanel>

            {/* Source */}
            <GlassPanel title="Data Source">
              <p className="text-xs text-slate-400 font-mono break-all">{selected.dataSource}</p>
            </GlassPanel>

            {selected.notes && (
              <GlassPanel title="Notes">
                <p className="text-xs text-slate-300">{selected.notes}</p>
              </GlassPanel>
            )}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-center gap-3">
            <FlaskConical size={32} className="text-slate-600" />
            <div className="text-slate-500 text-sm">Select a science target to view details</div>
            <div className="text-slate-600 text-xs">Or add a new custom target</div>
          </div>
        )}
      </div>
    </div>
  )}
</div>
  );
}
