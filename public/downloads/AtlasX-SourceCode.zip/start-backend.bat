@echo off
echo Starting AtlasX Backend...
cd /d "%~dp0\backend"
python main.py
