using System;
using System.Diagnostics;
using System.IO;
using System.Text;

/// <summary>
/// 7za.exe wrapper for electron-builder on Windows without Developer Mode.
/// The app-builder Go binary downloads winCodeSign-2.6.0.7z which contains macOS
/// symlinks (libcrypto.dylib -> libcrypto.1.0.0.dylib). Windows without Developer
/// Mode cannot create symlinks, so 7za exits with code 2.
/// This wrapper:
///   1. Runs the real 7za-real.exe with all original args
///   2. If exit code is 2 and a darwin/10.12/lib directory was created in the
///      output folder, copies the versioned dylib files over the missing symlink
///      targets so downstream tools can find them
///   3. Exits with 0 so the Go binary considers extraction successful
/// </summary>
class Program
{
    static int Main(string[] args)
    {
        string wrapperDir = AppDomain.CurrentDomain.BaseDirectory;
        string realExe = Path.Combine(wrapperDir, "7za-real.exe");

        if (!File.Exists(realExe))
        {
            Console.Error.WriteLine("[7za-wrapper] ERROR: 7za-real.exe not found at: " + realExe);
            return 1;
        }

        // Build argument string (preserve quoting)
        var psi = new ProcessStartInfo();
        psi.FileName = realExe;
        psi.UseShellExecute = false;

        // Pass all arguments manually
        StringBuilder sb = new StringBuilder();
        foreach (string arg in args)
        {
            if (sb.Length > 0) sb.Append(' ');
            if (arg.Contains(" ") || arg.Contains("'"))
                sb.Append('"').Append(arg.Replace("\"", "\\\"")).Append('"');
            else
                sb.Append(arg);
        }
        psi.Arguments = sb.ToString();

        var proc = Process.Start(psi);
        proc.WaitForExit();
        int exitCode = proc.ExitCode;

        if (exitCode == 2)
        {
            // Possibly a symlink-only failure. Try to fix darwin dylib links.
            string outDir = GetOutputDir(args);
            if (outDir != null && FixDarwinSymlinks(outDir))
            {
                // Extraction succeeded modulo the symlinks we just fixed
                return 0;
            }
        }

        return exitCode;
    }

    static string GetOutputDir(string[] args)
    {
        // 7za uses -oOUTPUT_DIR (no space) format
        foreach (string arg in args)
        {
            string clean = arg.Trim('\'', '"');
            if (clean.StartsWith("-o") && clean.Length > 2)
                return clean.Substring(2);
        }
        return null;
    }

    static bool FixDarwinSymlinks(string outDir)
    {
        string darwinLib = Path.Combine(outDir, "darwin", "10.12", "lib");
        if (!Directory.Exists(darwinLib))
            return false;

        bool fixed_ = false;
        fixed_ |= CopyIfMissing(darwinLib, "libcrypto.1.0.0.dylib", "libcrypto.dylib");
        fixed_ |= CopyIfMissing(darwinLib, "libssl.1.0.0.dylib",    "libssl.dylib");
        return fixed_;
    }

    static bool CopyIfMissing(string dir, string srcName, string dstName)
    {
        string src = Path.Combine(dir, srcName);
        string dst = Path.Combine(dir, dstName);
        // 7zip creates 0-byte placeholder files for symlinks it cannot create on Windows
        // without Developer Mode. We overwrite them with the real file content.
        bool dstMissingOrEmpty = !File.Exists(dst) || new FileInfo(dst).Length == 0;
        if (File.Exists(src) && dstMissingOrEmpty)
        {
            File.Copy(src, dst, overwrite: true);
            return true;
        }
        return false;
    }
}
