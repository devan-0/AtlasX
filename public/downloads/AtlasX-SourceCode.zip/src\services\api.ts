/**
 * AtlasX — Real-time Data Service Layer
 * 
 * Connects to the FastAPI backend for live NASA/JPL data.
 * Falls back gracefully to SIMULATED data if backend is unreachable.
 * 
 * All real data is clearly classified. Never pretend simulated is observed.
 *
 * Port strategy:
 *  - VITE_API_URL env var (dev .env file) → use that
 *  - Running inside packaged Electron (file:// origin) → use port 8765
 *  - Otherwise default dev port 8000
 */

function resolveBackendUrl(): string {
  // Explicit override always wins
  if (import.meta.env.VITE_API_URL) return import.meta.env.VITE_API_URL as string;

  // Detect packaged Electron: location.protocol will be 'file:'
  if (typeof window !== 'undefined' && window.location.protocol === 'file:') {
    return 'http://127.0.0.1:8765';
  }

  // Dev server default
  return 'http://localhost:8000';
}

const BACKEND_URL = resolveBackendUrl();
const REQUEST_TIMEOUT_MS = 10000;

export type DataSource = 'live' | 'cached' | 'simulated' | 'unavailable';

export interface ApiResponse<T> {
  data: T | null;
  source: DataSource;
  error?: string;
  retrievedAt?: string;
}

/** Shared fetch with timeout and graceful error handling */
async function fetchWithTimeout<T>(
  url: string,
  timeoutMs = REQUEST_TIMEOUT_MS
): Promise<ApiResponse<T>> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const resp = await fetch(url, { signal: controller.signal });
    clearTimeout(timer);
    if (!resp.ok) {
      return { data: null, source: 'unavailable', error: `HTTP ${resp.status}` };
    }
    const data = await resp.json() as T;
    return { data, source: 'live', retrievedAt: new Date().toISOString() };
  } catch (err) {
    clearTimeout(timer);
    const message = err instanceof Error ? err.message : String(err);
    const isTimeout = message.includes('abort') || message.includes('timeout');
    return {
      data: null,
      source: 'unavailable',
      error: isTimeout ? 'Backend not reachable (timeout). Is the API server running?' : message,
    };
  }
}

// ── Type Definitions ─────────────────────────────────────────────────────────

export interface MarsEphemeris {
  classification: 'observed' | 'derived';
  source: string;
  source_url: string;
  date: string;
  retrieved_at: string;
  orbital_elements: {
    eccentricity: number;
    true_anomaly_deg: number;
    argument_of_perihelion_deg: number;
    semi_major_axis_km: number;
    periapsis_km: number;
    inclination_deg: number;
  };
  derived: {
    solar_longitude_deg: number;
    season: string;
    mars_sun_distance_km: number;
    mars_sun_distance_au: number;
    solar_irradiance_w_m2: number;
    irradiance_classification: string;
    irradiance_note: string;
  };
  notes: string;
}

export interface InsightWeatherSol {
  sol: number;
  first_utc: string | null;
  last_utc: string | null;
  northern_season: string;
  southern_season: string;
  month_ordinal: number | null;
  air_temperature: {
    average_c: number | null;
    min_c: number | null;
    max_c: number | null;
    sample_count: number | null;
  };
  pressure: {
    average_pa: number | null;
    min_pa: number | null;
    max_pa: number | null;
    sample_count: number | null;
  };
  wind_speed: {
    average_m_s: number | null;
    min_m_s: number | null;
    max_m_s: number | null;
    sample_count: number | null;
  };
}

export interface InsightWeather {
  classification: 'observed';
  source: string;
  source_url: string;
  instrument: string;
  location: {
    name: string;
    lat: number;
    lon: number;
    elevation_m: number;
  };
  mission_status: string;
  mission_end_date: string;
  note: string;
  retrieved_at: string;
  sol_count: number;
  sols: InsightWeatherSol[];
  latest_sol: InsightWeatherSol | null;
}

export interface SeasonalCurvePoint {
  ls_deg: number;
  irradiance_w_m2: number;
  season: string;
}

export interface SeasonalCurve {
  classification: 'derived';
  source: string;
  note: string;
  eccentricity_used: number;
  perihelion_ls_used: number;
  data: SeasonalCurvePoint[];
}

export interface BackendStatus {
  timestamp: string;
  sources: Array<{
    name: string;
    endpoint: string;
    reachable: boolean;
    classification: string;
    data_type: string;
    mission_status?: string;
    cached?: boolean;
    cache_age_s?: number | null;
  }>;
  backend_version: string;
}

// ── API Functions ────────────────────────────────────────────────────────────

export interface MarsTimeData {
  status: string;
  classification: string;
  standard: string;
  earth_utc_iso: string;
  earth_utc_date: string;
  earth_utc_time: string;
  julian_date_ut: number;
  julian_date_tt: number;
  mars_sol_date: number;
  mars_sol_int: number;
  mtc: string;
  mtc_formatted: string;
  lmst: string;
  lmst_formatted: string;
  target_lon_east_deg: number;
  mars_year: number;
  mars_year_formatted: string;
  solar_longitude_deg: number;
  season: string;
  mars_sun_distance_au: number;
  mars_sun_distance_km: number;
  solar_irradiance_w_m2: number;
  subsolar_latitude_deg: number;
}

/**
 * Get live real-time Earth and Mars clock and orbital state from backend.
 */
export async function fetchMarsTime(lon?: number, timestamp?: string): Promise<ApiResponse<MarsTimeData>> {
  const query = new URLSearchParams();
  if (lon !== undefined) query.set('lon', String(lon));
  if (timestamp) query.set('timestamp', timestamp);
  return fetchWithTimeout<MarsTimeData>(`${BACKEND_URL}/api/time/mars?${query.toString()}`, 3000);
}

/**
 * Get real Mars orbital ephemeris from JPL Horizons.
 * Returns actual solar longitude, Mars-Sun distance, irradiance.
 */
export async function fetchMarsEphemeris(date?: string): Promise<ApiResponse<MarsEphemeris>> {
  const dateStr = date || new Date().toISOString().split('T')[0];
  return fetchWithTimeout<MarsEphemeris>(
    `${BACKEND_URL}/api/ephemeris/mars?date=${dateStr}`
  );
}

/**
 * Get real NASA InSight weather data (Elysium Planitia).
 * Last sol data available from InSight APSS instrument.
 */
export async function fetchInsightWeather(): Promise<ApiResponse<InsightWeather>> {
  return fetchWithTimeout<InsightWeather>(`${BACKEND_URL}/api/weather/insight`);
}

/**
 * Get irradiance curve over full Martian year.
 * Derived from JPL Horizons orbital elements.
 */
export async function fetchSeasonalCurve(): Promise<ApiResponse<SeasonalCurve>> {
  return fetchWithTimeout<SeasonalCurve>(`${BACKEND_URL}/api/ephemeris/mars/seasonal-curve`);
}

/**
 * Get backend health and data source status.
 */
export async function fetchBackendStatus(): Promise<ApiResponse<BackendStatus>> {
  return fetchWithTimeout<BackendStatus>(`${BACKEND_URL}/api/status`, 5000);
}

/**
 * Check if the backend API is reachable at all.
 */
export async function checkBackendHealth(): Promise<boolean> {
  try {
    const controller = new AbortController();
    setTimeout(() => controller.abort(), 3000);
    const resp = await fetch(`${BACKEND_URL}/api/health`, { signal: controller.signal });
    return resp.ok;
  } catch {
    return false;
  }
}

