// AtlasX — Mars Coordinate Utilities
// Formulae based on planetary constants and standard geodetic/spherical methods.

import { Coordinates } from '../types';

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

/** Mean volumetric radius of Mars (km) */
export const MARS_RADIUS_KM = 3389.5;

/** Mean semi-major axis of Mars orbit (AU) */
export const MARS_SEMIMAJOR_AU = 1.524;

/** Martian orbital period (Earth days) */
export const MARS_ORBITAL_PERIOD_DAYS = 686.971;

/** Length of a Martian solar day / sol (hours) */
export const MARS_SOL_HOURS = 24.6597;

/** Mars axial tilt (degrees) */
export const MARS_AXIAL_TILT_DEG = 25.19;

// Mars is an oblate spheroid; the ratio (a²-b²)/a² gives the flattening.
// a = 3396.2 km (equatorial), b = 3376.2 km (polar) — IAU 2000
const MARS_EQUATORIAL_RADIUS_KM = 3396.2;
const MARS_POLAR_RADIUS_KM = 3376.2;
// Flattening f = (a - b) / a
const MARS_FLATTENING =
  (MARS_EQUATORIAL_RADIUS_KM - MARS_POLAR_RADIUS_KM) / MARS_EQUATORIAL_RADIUS_KM;
// First eccentricity squared: e² = 2f - f²
const MARS_E_SQ = 2 * MARS_FLATTENING - MARS_FLATTENING ** 2;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/** Convert degrees to radians */
const toRad = (deg: number): number => (deg * Math.PI) / 180;

/** Convert radians to degrees */
const toDeg = (rad: number): number => (rad * 180) / Math.PI;

// ---------------------------------------------------------------------------
// Exported functions
// ---------------------------------------------------------------------------

/**
 * Convert a decimal-degree value to a DMS (Degrees°Minutes'Seconds") string.
 * @param decimal - Decimal degrees (positive = N or E, negative = S or W)
 * @param isLat   - true for latitude (N/S labels), false for longitude (E/W)
 */
export function decimalToDMS(decimal: number, isLat: boolean): string {
  const absolute = Math.abs(decimal);
  const degrees = Math.floor(absolute);
  const minutesFloat = (absolute - degrees) * 60;
  const minutes = Math.floor(minutesFloat);
  const seconds = ((minutesFloat - minutes) * 60).toFixed(2);

  let direction: string;
  if (isLat) {
    direction = decimal >= 0 ? 'N' : 'S';
  } else {
    // Normalise: treat lon > 180 as West equivalents for display
    const displayDecimal = decimal > 180 ? decimal - 360 : decimal;
    direction = displayDecimal >= 0 ? 'E' : 'W';
  }

  return `${degrees}°${minutes}'${seconds}"${direction}`;
}

/**
 * Great-circle distance between two Mars surface points using the Haversine
 * formula applied to Mars's mean spherical radius.
 *
 * Haversine: a = sin²(Δφ/2) + cos φ₁ · cos φ₂ · sin²(Δλ/2)
 *            c = 2 · atan2(√a, √(1-a))
 *            d = R · c
 *
 * @returns Distance in kilometres.
 */
export function marsDistance(a: Coordinates, b: Coordinates): number {
  const φ1 = toRad(a.lat);
  const φ2 = toRad(b.lat);
  const Δφ = toRad(b.lat - a.lat);
  // Longitude difference — unwrap to avoid sign ambiguity with 0-360 vs ±180
  const lonDiff = normalizeLon(b.lon) - normalizeLon(a.lon);
  const Δλ = toRad(lonDiff > 180 ? lonDiff - 360 : lonDiff < -180 ? lonDiff + 360 : lonDiff);

  const sinHalfLat = Math.sin(Δφ / 2);
  const sinHalfLon = Math.sin(Δλ / 2);

  const haversineA =
    sinHalfLat * sinHalfLat +
    Math.cos(φ1) * Math.cos(φ2) * sinHalfLon * sinHalfLon;

  const centralAngle = 2 * Math.atan2(Math.sqrt(haversineA), Math.sqrt(1 - haversineA));
  return MARS_RADIUS_KM * centralAngle;
}

/**
 * Format a lat/lon pair for display.
 * @param format - 'decimal' returns e.g. "4.5890°N, 137.4417°E";
 *                 'dms'     returns DMS notation.
 */
export function formatCoords(
  lat: number,
  lon: number,
  format: 'decimal' | 'dms',
): string {
  if (format === 'decimal') {
    const latDir = lat >= 0 ? 'N' : 'S';
    // Normalise lon for display
    const displayLon = lon > 180 ? lon - 360 : lon;
    const lonDir = displayLon >= 0 ? 'E' : 'W';
    return `${Math.abs(lat).toFixed(4)}°${latDir}, ${Math.abs(displayLon).toFixed(4)}°${lonDir}`;
  }
  return `${decimalToDMS(lat, true)}, ${decimalToDMS(lon, false)}`;
}

/**
 * Validate that coordinates fall within Mars's legal ranges.
 * Latitude must be −90..90; longitude can be 0..360 or −180..180.
 */
export function isValidMarsCoord(lat: number, lon: number): boolean {
  if (!Number.isFinite(lat) || !Number.isFinite(lon)) return false;
  if (lat < -90 || lat > 90) return false;
  // Accept both 0-360 and -180 to 180 conventions
  if (lon < -180 || lon > 360) return false;
  return true;
}

/**
 * Normalise a longitude value into the 0–360° East range.
 * Handles inputs in either −180..180 or 0..360 convention.
 */
export function normalizeLon(lon: number): number {
  let result = lon % 360;
  if (result < 0) result += 360;
  return result;
}

/**
 * Convert planetocentric latitude to planetographic latitude.
 *
 * Planetographic latitude φ_g is related to planetocentric latitude φ_c by:
 *   tan(φ_g) = tan(φ_c) / (1 - e²)
 *
 * where e² is the first eccentricity squared of Mars's reference ellipsoid.
 * For a sphere e² = 0, so the two systems coincide; Mars's slight oblateness
 * introduces up to ~0.31° difference near 45° latitude.
 *
 * @param lat - Planetocentric latitude in degrees.
 * @returns Planetographic latitude in degrees.
 */
export function toPlanetoGraphic(lat: number): number {
  const φc = toRad(lat);
  // Avoid division by zero at the poles (cos φc ≈ 0)
  if (Math.abs(Math.cos(φc)) < 1e-10) return lat;
  const tanPG = Math.tan(φc) / (1 - MARS_E_SQ);
  return toDeg(Math.atan(tanPG));
}
