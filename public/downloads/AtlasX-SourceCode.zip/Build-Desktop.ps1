﻿# Build-Desktop.ps1 — Complete desktop build pipeline for AtlasX
# Run from project root: .\Build-Desktop.ps1

param(
    [switch]$SkipBackend,   # Skip PyInstaller step (use existing dist/)
    [switch]$SkipInstaller  # Build unpacked only (faster, no NSIS)
)

$ErrorActionPreference = 'Stop'
$NODE = "C:\Users\valiy\tools\node-v20.18.0-win-x64"
$env:PATH = "$NODE;$env:PATH"
$ROOT = Split-Path $MyInvocation.MyCommand.Path
if (-not $ROOT) { $ROOT = (Get-Location).Path }
$releaseDir = Join-Path $ROOT "release"

Set-Location $ROOT
Write-Host "`n=======================================" -ForegroundColor Cyan
Write-Host "  AtlasX — Desktop Build Pipeline" -ForegroundColor Cyan
Write-Host "=======================================" -ForegroundColor Cyan

# ── Step 1: Build Python backend ────────────────────────────────────────────
if (-not $SkipBackend) {
    Write-Host "`n[1/4] Building Python backend (PyInstaller)..." -ForegroundColor Yellow

    $backendDist = Join-Path $ROOT "backend\dist\mars_backend\mars_backend.exe"
    Set-Location (Join-Path $ROOT "backend")

    if (Test-Path "dist") { Remove-Item "dist" -Recurse -Force }
    if (Test-Path "build") { Remove-Item "build" -Recurse -Force }

    python -m PyInstaller mars_backend.spec --clean --noconfirm
    if ($LASTEXITCODE -ne 0) {
        Write-Error "PyInstaller build failed!"
        exit 1
    }

    if (-not (Test-Path $backendDist)) {
        Write-Error "Expected backend exe not found: $backendDist"
        exit 1
    }
    Write-Host "  ✓ Backend built: $backendDist" -ForegroundColor Green
    Set-Location $ROOT
} else {
    Write-Host "`n[1/4] Skipping backend build (--SkipBackend)" -ForegroundColor Gray
}

# ── Step 2: Build Vite frontend ──────────────────────────────────────────────
Write-Host "`n[2/4] Building Vite frontend..." -ForegroundColor Yellow
$env:BUILD_TARGET = "electron"
npm run build
if ($LASTEXITCODE -ne 0) {
    Write-Error "Vite build failed!"
    exit 1
}
Write-Host "  ✓ Frontend built: dist/" -ForegroundColor Green

# ── Step 3: Prepare Electron assets ─────────────────────────────────────────
Write-Host "`n[3/4] Preparing Electron app bundle..." -ForegroundColor Yellow
node scripts/prepare-electron.mjs
if ($LASTEXITCODE -ne 0) {
    Write-Error "Electron preparation failed!"
    exit 1
}
Write-Host "  ✓ App assets prepared: app/" -ForegroundColor Green

# ── Step 4: Package with electron-builder ───────────────────────────────────
Write-Host "`n[4/4] Packaging with electron-builder..." -ForegroundColor Yellow
if ($SkipInstaller) {
    npm run electron:pack
} else {
    npm run electron:dist
}
if ($LASTEXITCODE -ne 0) {
    Write-Error "electron-builder packaging failed!"
    exit 1
}

# ── Step 5: Sign executables (Authenticode) ─────────────────────────────────
Write-Host "`n[5/5] Signing executables with Authenticode certificate..." -ForegroundColor Yellow
$cert = Get-ChildItem Cert:\CurrentUser\My | Where-Object { $_.Subject -match "AtlasX" -or $_.Subject -match "Mars" } | Select-Object -First 1
if ($cert) {
    Get-ChildItem $releaseDir -Filter "*.exe" -Recurse | ForEach-Object {
        Set-AuthenticodeSignature -FilePath $_.FullName -Certificate $cert -HashAlgorithm SHA256 | Out-Null
        Write-Host "  ✓ Signed $($_.Name)" -ForegroundColor Green
    }
} else {
    Write-Host "  ℹ No local Mars code-signing certificate found, skipping signing" -ForegroundColor Gray
}

Write-Host "`n=======================================" -ForegroundColor Green
Write-Host "  BUILD COMPLETE!" -ForegroundColor Green
Write-Host "=======================================" -ForegroundColor Green

Write-Host "`nOutput in: $releaseDir" -ForegroundColor Cyan
Get-ChildItem $releaseDir -Filter "*.exe" -Recurse | ForEach-Object {
    $size = "{0:N1} MB" -f ($_.Length / 1MB)
    Write-Host "  $($_.Name)  ($size)" -ForegroundColor White
}

