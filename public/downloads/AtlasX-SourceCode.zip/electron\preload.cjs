/**
 * Electron preload script — exposes a safe bridge from renderer to main.
 * No Node APIs are exposed directly; only specific IPC channels.
 */
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  /** Query backend readiness status from the main process */
  getBackendStatus: () => ipcRenderer.invoke('backend-status'),

  /** App version */
  getVersion: () => ipcRenderer.invoke('get-version'),
});
