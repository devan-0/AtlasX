// AtlasX — Meteorological Stream & EVA Hazard Advisory Engine
// Integrates telemetry models from NASA MEDA (Perseverance), REMS (Curiosity), and InSight APSS.
// Correlates diurnal temperature swings, dust optical depth (tau), and wind dynamics with astronaut survival.

import type { EVAMeteorologicalAdvisory } from '../types';

export interface WeatherInput {
  sol?: number;
  temperatureK?: number;
  pressurePa?: number;
  windSpeedMs?: number;
  windGustMs?: number;
  dustOpticalDepth?: number;
  lsDeg?: number;
}

/**
 * Computes an EVA Meteorological Advisory assessing life-support impact,
 * optical visibility, suit thermal penalty, and mission GO / NO-GO status.
 */
export function computeEVAMeteorologicalAdvisory(input: WeatherInput): EVAMeteorologicalAdvisory {
  const sol = input.sol ?? 245;
  const tempK = input.temperatureK ?? 215;
  const tempC = tempK - 273.15;
  const pressure = input.pressurePa ?? 740;
  const tau = input.dustOpticalDepth ?? 0.52;
  const wind = input.windSpeedMs ?? 6.2;
  const gust = input.windGustMs ?? wind * 1.55;

  // 1. Thermal suit penalty (deviation from nominal 220 K - 250 K operating comfort)
  let thermalPenalty = 0;
  if (tempK < 195) {
    // Extreme Martian night cold: suit heaters must draw additional battery power
    thermalPenalty = Math.min(60, Math.round(((195 - tempK) / 30) * 50));
  } else if (tempK > 265) {
    // Warm equatorial noon: sublimator water boil-off increases rapidly
    thermalPenalty = Math.min(45, Math.round(((tempK - 265) / 15) * 40));
  }

  // 2. Optical visibility range derived from dust optical depth (Koschmieder atmospheric model)
  // Clean atmosphere (tau ~ 0.3) -> 20 km; dust storm (tau ~ 2.5) -> <800 m; global storm -> <400 m
  const visibilityKm = Math.max(0.1, Math.min(25.0, 4.0 / Math.pow(Math.max(0.2, tau), 1.85)));
  const visibilityMeters = Math.round(visibilityKm * 1000);

  // 3. Storm Risk & Dust Activity
  let stormRisk: 'low' | 'moderate' | 'high' | 'severe' = 'low';
  if (tau >= 2.5) {
    stormRisk = 'severe';
  } else if (tau >= 1.5 || wind >= 18) {
    stormRisk = 'high';
  } else if (tau >= 0.8 || wind >= 12) {
    stormRisk = 'moderate';
  }

  // 4. UV Flux Index (Martian surface receives unshielded UV-B/C due to thin ozone)
  // Higher tau actually attenuates UV reaching the ground!
  const maxUV = 8.5;
  const uvIndex = parseFloat((maxUV * Math.exp(-0.45 * tau)).toFixed(1));

  // 5. GO / CAUTION / NO-GO Safety Rating
  let rating: 'GO' | 'CAUTION' | 'NO_GO' = 'GO';
  const recommendations: string[] = [];

  if (tau >= 2.5) {
    rating = 'NO_GO';
    recommendations.push('NO-GO: Severe global/regional dust storm (tau ≥ 2.5). Optical disorientation & extreme solar loss.');
  } else if (wind >= 22) {
    rating = 'NO_GO';
    recommendations.push('NO-GO: Dangerous wind velocities & saltation risk exceeding EVA structural limit (>22 m/s).');
  } else if (tempK < 175) {
    rating = 'NO_GO';
    recommendations.push('NO-GO: Extreme cryogenic ambient temperature (<175 K). Sub-zero battery lock out risk.');
  } else if (tau >= 1.2 || wind >= 13 || tempK < 190) {
    rating = 'CAUTION';
    if (tau >= 1.2) recommendations.push('CAUTION: Elevated atmospheric dust loading (tau > 1.2). Limit traverse to 3 km radius.');
    if (wind >= 13) recommendations.push('CAUTION: Moderate wind gusts; ensure rover anchoring and sample container sealing.');
    if (tempK < 190) recommendations.push('CAUTION: Low ambient temperature; suit heater auxiliary power consumption active (+25%).');
  } else {
    recommendations.push('NOMINAL: Atmospheric conditions optimal for suited surface traverse and scientific sampling.');
    recommendations.push('Maintain standard 30-minute O2 reserve and PNR radius checks.');
  }

  return {
    sol,
    temperatureK: Math.round(tempK),
    temperatureC: parseFloat(tempC.toFixed(1)),
    pressurePa: Math.round(pressure),
    dustOpticalDepthTau: parseFloat(tau.toFixed(2)),
    windSpeedMs: parseFloat(wind.toFixed(1)),
    windGustMs: parseFloat(gust.toFixed(1)),
    uvFluxIndex: uvIndex,
    thermalSuitPenaltyPercent: thermalPenalty,
    visibilityRangeMeters: visibilityMeters,
    stormRisk,
    evaSafetyRating: rating,
    recommendations,
  };
}
