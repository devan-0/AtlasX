// AtlasX — Astronaut Physiological & EVA Survival Modeling
// Calibrated for Martian gravity (g = 3.721 m/s², 0.379g) and planetary exploration space suits (xEMU).
// Formulas: Pandolf-Margaria Martian metabolic expenditure, Fick oxygen consumption, and PNR turnaround.

import type {
  AstronautBioState,
  EVASuitState,
  EVASurvivalMetrics,
  EVARouteMetrics,
  TerrainPoint,
} from '../types';

// ── Planetary & Physiological Constants ─────────────────────────────────────

export const MARS_GRAVITY_MS2 = 3.721;
export const EARTH_GRAVITY_MS2 = 9.80665;
export const MARS_GRAVITY_RATIO = MARS_GRAVITY_MS2 / EARTH_GRAVITY_MS2; // ~0.3794

/** Energy equivalent per liter of O2 consumed (Joules per Liter). */
export const JOULES_PER_LITER_O2 = 20100;

/** Normal STP density of O2 gas (kg / m³ = g / L). */
export const O2_DENSITY_G_PER_L = 1.429;

/** Respiratory quotient (VCO2 / VO2) for astronaut balanced diet. */
export const RESPIRATORY_QUOTIENT = 0.85;

/** Nominal suited exploration parameters. */
export const DEFAULT_ASTRONAUT_MASS_KG = 80;
export const DEFAULT_SUIT_MASS_KG = 120;
export const DEFAULT_TOTAL_MASS_KG = DEFAULT_ASTRONAUT_MASS_KG + DEFAULT_SUIT_MASS_KG; // 200 kg

/** Usable primary O2 capacity (kg and equivalent STP Liters). */
export const PRIMARY_O2_CAPACITY_KG = 1.2;
export const PRIMARY_O2_CAPACITY_LITERS = (PRIMARY_O2_CAPACITY_KG * 1000) / O2_DENSITY_G_PER_L; // ~839.7 L

/** Emergency secondary O2 buffer margin in minutes (untouchable safety margin). */
export const EMERGENCY_O2_BUFFER_MINUTES = 30;

/** Suit battery capacity in Watt-hours. */
export const SUIT_BATTERY_CAPACITY_WH = 600;

/** Baseline suit electronics, comms, and ventilation draw (Watts). */
export const SUIT_BASE_ELECTRICAL_WATTS = 75;

// ── Terrain Roughness Factor (η in Pandolf equation) ─────────────────────────

export function getTerrainFactor(slopeDeg: number, roughness = 0.5): number {
  // 1.1 for smooth bedrock, 1.4 for compact regolith, 1.9 for sand/dunes, up to 2.4 for boulder scree
  if (slopeDeg > 20) return 2.2 + roughness * 0.4;
  if (slopeDeg > 12) return 1.7 + roughness * 0.3;
  if (slopeDeg > 6) return 1.4 + roughness * 0.2;
  return 1.2 + roughness * 0.2;
}

// ── Pandolf-Margaria Martian Suited Metabolic Rate ────────────────────────────

/**
 * Calculates human metabolic energy expenditure (in Watts) during Martian walking.
 * Incorporates suit mass penalty, reduced gravity scaling, and slope gradient.
 *
 * @param velocityMs Walking speed in m/s (typically 0.8 to 1.1 m/s for suited walk)
 * @param slopeDeg Slope angle in degrees (positive = uphill, negative = downhill)
 * @param terrainFactor Terrain friction coefficient (1.1 to 2.4)
 * @param astronautMassKg Mass of astronaut without suit
 * @param suitMassKg Mass of space suit (xEMU ~120kg)
 */
export function calculateMetabolicWatts(
  velocityMs = 0.95,
  slopeDeg = 0,
  terrainFactor = 1.3,
  astronautMassKg = DEFAULT_ASTRONAUT_MASS_KG,
  suitMassKg = DEFAULT_SUIT_MASS_KG
): number {
  const mTot = astronautMassKg + suitMassKg;
  const grade = Math.tan((slopeDeg * Math.PI) / 180); // decimal gradient (rise / run)

  // Baseline resting metabolic wattage (approx 105 W)
  const restWatts = 105;

  // Pressurized suit joint resistance (stiffness of pressurized knees/hips)
  const suitJointResistanceWatts = 42;

  // Reduced gravity scaling factor for carrying weight vs kinetic walking
  const grav = MARS_GRAVITY_RATIO;

  // Pandolf kinetic term adapted for Martian suited mobility:
  // M = η * [ 1.5 * M_tot * g_rel + 2.0 * (M_a + M_s) * g_rel * (M_s/M_a)^2 * 0.12 + M_tot * g_rel * (1.5 * v² + 0.35 * v * grade * 100) ]
  const massRatio = suitMassKg / astronautMassKg;
  const suitPenalty = 2.0 * mTot * grav * Math.pow(massRatio, 2) * 0.08;
  const kineticTerm = mTot * grav * (1.5 * Math.pow(velocityMs, 2) + 0.35 * velocityMs * (grade * 100));

  let metabolicRate = terrainFactor * (1.5 * mTot * grav + suitPenalty + kineticTerm) + suitJointResistanceWatts;

  // Downhill braking work adjustment: downhill reduces metabolic work down to -15% grade,
  // beyond which eccentric muscular braking increases expenditure again.
  if (grade < 0) {
    if (grade > -0.15) {
      metabolicRate *= Math.max(0.65, 1.0 + grade * 2.2);
    } else {
      metabolicRate *= 0.65 + Math.abs(grade + 0.15) * 1.8;
    }
  }

  // Realistic human bounds: min ~110 W, max sprint/high exertion ~580 W
  return Math.max(restWatts, Math.min(580, metabolicRate));
}

// ── Oxygen Consumption & Gas Exchange ────────────────────────────────────────

/**
 * Calculates instantaneous VO2 (Oxygen consumption rate) in Liters per minute.
 * Based on metabolic caloric equivalent of 20,100 J per liter of O2.
 */
export function calculateVO2LitersPerMin(metabolicWatts: number): number {
  return (metabolicWatts * 60) / JOULES_PER_LITER_O2;
}

/**
 * Calculates CO2 production rate in Liters per minute based on respiratory quotient.
 */
export function calculateVCO2LitersPerMin(vo2Lpm: number): number {
  return vo2Lpm * RESPIRATORY_QUOTIENT;
}

/**
 * Calculates heart rate response based on metabolic exertion.
 */
export function calculateHeartRateBpm(metabolicWatts: number): number {
  const restWatts = 105;
  const maxWatts = 550;
  const restBpm = 68;
  const maxBpm = 175;

  const fraction = Math.max(0, Math.min(1, (metabolicWatts - restWatts) / (maxWatts - restWatts)));
  return Math.round(restBpm + fraction * (maxBpm - restBpm));
}

// ── Curiosity / Perseverance Mobility & Regolith Slip ────────────────────────

/**
 * Computes regolith wheel slip / suited boot slippage percentage based on NASA
 * Curiosity & Perseverance traverse telemetry models.
 * Slopes > 15° induce non-linear shear failure in dry Martian drift regolith.
 */
export function calculateSoilSlipPercent(slopeDeg: number, roughness = 0.5): number {
  const absSlope = Math.abs(slopeDeg);
  if (absSlope < 4) return 2 + roughness * 2;
  if (absSlope < 10) return 5 + (absSlope - 4) * 1.5;
  if (absSlope < 15) return 14 + (absSlope - 10) * 2.5;
  if (absSlope < 20) return 26.5 + Math.pow(absSlope - 15, 1.6) * 4.5;
  // Critical slip threshold > 20°
  return Math.min(95, 45 + Math.pow(absSlope - 20, 1.8) * 8.0);
}

// ── Route EVA Metrics Engine ─────────────────────────────────────────────────

/**
 * Evaluates the full physiological cost and life-support margin along an entire route.
 * Identifies the Point of No Return (PNR) where returning to start would violate safety buffers.
 */
export function evaluateEVARouteMetrics(
  profile: TerrainPoint[],
  totalDistanceKm: number,
  estimatedDurationHours: number
): EVARouteMetrics {
  if (!profile || profile.length < 2) {
    return {
      totalMetabolicEnergyKcal: 0,
      totalMetabolicEnergyKwh: 0,
      totalO2ConsumedLiters: 0,
      peakMetabolicRateWatts: 110,
      peakHeartRateBpm: 72,
      soilSlipRiskPercent: 5,
      pointOfNoReturnWpIndex: profile.length - 1,
      safeReturnMarginMinutes: 180,
      limitingFactor: 'Nominal',
    };
  }

  const numSegments = profile.length - 1;
  const segDistM = (totalDistanceKm * 1000) / numSegments;
  const durationSec = estimatedDurationHours * 3600;
  const segDurationSec = durationSec / numSegments;
  const walkVelocityMs = segDistM / Math.max(1, segDurationSec);

  let cumulativeJoules = 0;
  let cumulativeO2Liters = 0;
  let peakWatts = 0;
  let peakHR = 0;
  let maxSlip = 0;

  // Pre-calculate outbound metabolic expenditure per segment
  const segWatts: number[] = [];
  const segO2: number[] = [];

  for (let i = 0; i < numSegments; i++) {
    const sl = profile[i + 1].slope ?? 0;
    const tf = getTerrainFactor(sl);
    const watts = calculateMetabolicWatts(walkVelocityMs, sl, tf);
    const vo2 = calculateVO2LitersPerMin(watts);
    const segO2Consumed = (vo2 / 60) * segDurationSec;

    segWatts.push(watts);
    segO2.push(segO2Consumed);

    cumulativeJoules += watts * segDurationSec;
    cumulativeO2Liters += segO2Consumed;
    peakWatts = Math.max(peakWatts, watts);
    peakHR = Math.max(peakHR, calculateHeartRateBpm(watts));

    const slip = calculateSoilSlipPercent(sl);
    maxSlip = Math.max(maxSlip, slip);
  }

  // ── Calculate Point of No Return (PNR) ──
  // For each waypoint k, calculate cost to return to start (segments 0..k in reverse direction)
  // Reverse slope inverts elevation profile (uphill becomes downhill, downhill uphill).
  let pnrIndex = profile.length - 1;
  let returnMarginMins = 120;

  let outboundO2 = 0;
  for (let k = 0; k < numSegments; k++) {
    outboundO2 += segO2[k];

    // Compute reverse return cost from k back to 0
    let returnO2 = 0;
    for (let r = k; r >= 0; r--) {
      // Inverted slope: elevation change is opposite
      const forwardSlope = profile[r + 1].slope ?? 0;
      const reverseSlope = -forwardSlope;
      const tf = getTerrainFactor(Math.abs(reverseSlope));
      const rWatts = calculateMetabolicWatts(walkVelocityMs, reverseSlope, tf);
      const rVo2 = calculateVO2LitersPerMin(rWatts);
      returnO2 += (rVo2 / 60) * segDurationSec;
    }

    const totalRoundTripO2 = outboundO2 + returnO2;
    // Max safe usable O2 budget (leaving 30 min emergency buffer)
    const avgVo2 = cumulativeO2Liters / (estimatedDurationHours * 60);
    const bufferO2 = avgVo2 * EMERGENCY_O2_BUFFER_MINUTES;
    const safeUsableO2 = PRIMARY_O2_CAPACITY_LITERS - bufferO2;

    if (totalRoundTripO2 > safeUsableO2) {
      pnrIndex = k;
      const remainingSafeLiters = Math.max(0, safeUsableO2 - totalRoundTripO2);
      returnMarginMins = (remainingSafeLiters / Math.max(0.2, avgVo2));
      break;
    }
  }

  const totalKcal = cumulativeJoules / 4184;
  const totalKwh = cumulativeJoules / 3600000;

  return {
    totalMetabolicEnergyKcal: Math.round(totalKcal),
    totalMetabolicEnergyKwh: parseFloat(totalKwh.toFixed(3)),
    totalO2ConsumedLiters: parseFloat(cumulativeO2Liters.toFixed(1)),
    peakMetabolicRateWatts: Math.round(peakWatts),
    peakHeartRateBpm: peakHR,
    soilSlipRiskPercent: Math.round(maxSlip),
    pointOfNoReturnWpIndex: pnrIndex,
    safeReturnMarginMinutes: Math.max(0, Math.round(returnMarginMins)),
    limitingFactor: cumulativeO2Liters > 600 ? 'Oxygen Consumables' : maxSlip > 35 ? 'Regolith Slip Hazard' : 'Nominal',
  };
}

// ── Real-time Astronaut Bio Telemetry Generator ──────────────────────────────

/**
 * Returns dynamic live biometric telemetry given an exertion profile and elapsed time.
 */
export function getLiveAstronautBioState(
  elapsedMinutes = 45,
  currentSlopeDeg = 4,
  activity: 'rest' | 'traverse' | 'sampling' | 'ascent' = 'traverse'
): { bio: AstronautBioState; suit: EVASuitState; survival: EVASurvivalMetrics } {
  let v = 0.95;
  let slope = currentSlopeDeg;
  if (activity === 'rest') { v = 0; slope = 0; }
  else if (activity === 'sampling') { v = 0.3; }
  else if (activity === 'ascent') { v = 0.8; slope = Math.max(10, currentSlopeDeg); }

  const terrainFactor = getTerrainFactor(slope);
  const metabolicWatts = activity === 'rest'
    ? 110
    : calculateMetabolicWatts(v, slope, terrainFactor);

  const vo2Lpm = calculateVO2LitersPerMin(metabolicWatts);
  const vco2Lpm = calculateVCO2LitersPerMin(vo2Lpm);
  const heartRate = calculateHeartRateBpm(metabolicWatts);

  // Core temp response to work
  const coreTemp = 36.8 + (metabolicWatts / 500) * 0.9;
  const skinTemp = 32.5 + (metabolicWatts / 600) * 1.5;
  const sweatRate = Math.round(150 + (metabolicWatts / 400) * 450);
  const hydration = Math.max(70, 100 - (elapsedMinutes / 360) * 20);
  const fatigue = Math.min(100, Math.round((elapsedMinutes / 420) * 75 + (metabolicWatts / 500) * 20));

  // Suit consumable state
  const o2ConsumedLiters = vo2Lpm * elapsedMinutes;
  const o2RemainingLiters = Math.max(0, PRIMARY_O2_CAPACITY_LITERS - o2ConsumedLiters);
  const o2PressureBar = Math.round((o2RemainingLiters / PRIMARY_O2_CAPACITY_LITERS) * 200);
  const o2MassKg = (o2RemainingLiters * O2_DENSITY_G_PER_L) / 1000;
  const o2TimeRemainingMins = Math.max(0, Math.round(o2RemainingLiters / vo2Lpm));

  const totalBatteryDrawWatts = SUIT_BASE_ELECTRICAL_WATTS + (metabolicWatts > 300 ? 55 : 25);
  const batteryUsedWh = (totalBatteryDrawWatts * elapsedMinutes) / 60;
  const batteryRemainWh = Math.max(0, SUIT_BATTERY_CAPACITY_WH - batteryUsedWh);
  const batteryPercent = Math.round((batteryRemainWh / SUIT_BATTERY_CAPACITY_WH) * 100);
  const batteryMins = Math.round((batteryRemainWh / totalBatteryDrawWatts) * 60);

  const liohSaturation = Math.min(100, Math.round((elapsedMinutes / 480) * 100));
  const waterRemaining = Math.max(0, 4.5 - (metabolicWatts * 0.8 * elapsedMinutes * 60) / 2400000);

  // Survival metrics & PNR
  const safeWalkSpeedKmH = 3.2;
  const safeTurnaroundMins = Math.min(o2TimeRemainingMins, batteryMins) / 2;
  const pnrRadiusKm = parseFloat(((safeTurnaroundMins / 60) * safeWalkSpeedKmH * 0.75).toFixed(2));

  let evaStatus: 'GO_NOMINAL' | 'CAUTION_MARGINAL' | 'ABORT_HAZARDOUS' = 'GO_NOMINAL';
  const warnings: string[] = [];
  let limiting: 'O2' | 'BATTERY' | 'LIOH' | 'THERMAL' | 'FATIGUE' | 'METEOROLOGICAL' = 'O2';

  if (o2TimeRemainingMins < 45 || batteryPercent < 20 || liohSaturation > 85) {
    evaStatus = 'ABORT_HAZARDOUS';
    if (o2TimeRemainingMins < 45) { warnings.push('Critical Oxygen Consumable Margin (<45 min)'); limiting = 'O2'; }
    if (batteryPercent < 20) { warnings.push('Critical Suit Battery Reserve (<20%)'); limiting = 'BATTERY'; }
    if (liohSaturation > 85) { warnings.push('LiOH Canister Saturation High (>85%)'); limiting = 'LIOH'; }
  } else if (o2TimeRemainingMins < 90 || batteryPercent < 35 || fatigue > 70) {
    evaStatus = 'CAUTION_MARGINAL';
    if (o2TimeRemainingMins < 90) { warnings.push('Approaching Point of No Return (Turnaround in <30 min)'); limiting = 'O2'; }
    if (fatigue > 70) { warnings.push('High Astronaut Exertion Index'); limiting = 'FATIGUE'; }
  }

  return {
    bio: {
      heartRateBpm: heartRate,
      metabolicRateWatts: Math.round(metabolicWatts),
      vo2LitersPerMin: parseFloat(vo2Lpm.toFixed(2)),
      co2OutputLitersPerMin: parseFloat(vco2Lpm.toFixed(2)),
      bodyCoreTempC: parseFloat(coreTemp.toFixed(1)),
      skinTempC: parseFloat(skinTemp.toFixed(1)),
      sweatRateMlPerHour: sweatRate,
      hydrationPercent: Math.round(hydration),
      fatigueIndex: fatigue,
    },
    suit: {
      o2TankPressureBar: o2PressureBar,
      o2MassRemainingKg: parseFloat(o2MassKg.toFixed(2)),
      o2TimeRemainingMinutes: o2TimeRemainingMins,
      secondaryO2ReserveMinutes: EMERGENCY_O2_BUFFER_MINUTES,
      batteryChargePercent: batteryPercent,
      batteryRemainingMinutes: batteryMins,
      liohCanisterSaturationPercent: liohSaturation,
      coolingWaterRemainingLiters: parseFloat(waterRemaining.toFixed(2)),
      suitInternalPressureKpa: 29.6,
      suitThermalMode: metabolicWatts > 320 ? 'high-cooling' : 'nominal',
    },
    survival: {
      pointOfNoReturnRadiusKm: pnrRadiusKm,
      pointOfNoReturnTimeMinutes: Math.round(safeTurnaroundMins),
      evaStatus,
      limitingFactor: limiting,
      activeWarnings: warnings,
    },
  };
}
