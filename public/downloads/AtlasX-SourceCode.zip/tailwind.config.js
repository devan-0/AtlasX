/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'mars': {
          50:  '#fef2ee',
          100: '#fde0d5',
          200: '#fbbfaa',
          300: '#f8957a',
          400: '#f46040',
          500: '#e84020',
          600: '#c42f14',
          700: '#9c2312',
          800: '#7a1e13',
          900: '#641b15',
          950: '#380a08',
        },
        'space': {
          50:  '#f0f4ff',
          100: '#dde7ff',
          200: '#c2d1ff',
          300: '#9db4ff',
          400: '#758bff',
          500: '#4f5eff',
          600: '#3a3df5',
          700: '#2e2fd8',
          800: '#2628ae',
          900: '#262789',
          950: '#161752',
        },
        'navy': {
          800: '#0d1421',
          850: '#0a1018',
          900: '#070d14',
          950: '#040810',
        },
        'glass': {
          50:  'rgba(255, 255, 255, 0.05)',
          100: 'rgba(255, 255, 255, 0.08)',
          200: 'rgba(255, 255, 255, 0.12)',
        },
      },
      fontFamily: {
        'mono': ['JetBrains Mono', 'Fira Code', 'Cascadia Code', 'monospace'],
        'display': ['Inter', 'system-ui', 'sans-serif'],
      },
      backdropBlur: {
        'xs': '2px',
        'sm': '4px',
        'md': '8px',
        'lg': '16px',
        'xl': '24px',
        '2xl': '40px',
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'glow': 'glow 2s ease-in-out infinite alternate',
        'slide-in': 'slideIn 0.3s ease-out',
        'fade-in': 'fadeIn 0.2s ease-out',
        'scan-line': 'scanLine 4s linear infinite',
      },
      keyframes: {
        glow: {
          '0%': { boxShadow: '0 0 5px rgba(232, 64, 32, 0.3)' },
          '100%': { boxShadow: '0 0 20px rgba(232, 64, 32, 0.6)' },
        },
        slideIn: {
          '0%': { transform: 'translateX(-10px)', opacity: '0' },
          '100%': { transform: 'translateX(0)', opacity: '1' },
        },
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        scanLine: {
          '0%': { top: '0%' },
          '100%': { top: '100%' },
        },
      },
      boxShadow: {
        'glass': '0 4px 30px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(255,255,255,0.05)',
        'glow-mars': '0 0 20px rgba(232, 64, 32, 0.4)',
        'glow-cyan': '0 0 20px rgba(34, 211, 238, 0.4)',
        'inner-glass': 'inset 0 1px 0 rgba(255,255,255,0.05), inset 0 -1px 0 rgba(0,0,0,0.2)',
      },
      borderColor: {
        'glass': 'rgba(255, 255, 255, 0.08)',
      },
    },
  },
  plugins: [],
};
