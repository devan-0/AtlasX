// Zustand global store for AtlasX
import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type {
  MarsRegion,
  ScienceTarget,
  Hazard,
  Route,
  CandidateSite,
  LayerConfig,
  SavedMission,
  Coordinates,
  MarsOutcrop,
  SampleTube,
} from '../types';
import {
  DEFAULT_REGION,
  MARS_REGIONS,
  SCIENCE_TARGETS,
  HAZARDS,
  CANDIDATE_SITES,
  DEFAULT_LAYERS,
  MARS_2020_OUTCROPS,
} from '../data/sampleData';

type NavPage =
  | 'overview'
  | 'atlas'
  | 'terrain3d'
  | 'routes'
  | 'science'
  | 'minerals'
  | 'solar'
  | 'atmosphere'
  | 'suitability'
  | 'comparison'
  | 'catalogue'
  | 'missions'
  | 'settings';

interface AppState {
  // Navigation
  activePage: NavPage;
  setActivePage: (page: NavPage) => void;

  // Selected region
  selectedRegion: MarsRegion;
  setSelectedRegion: (region: MarsRegion) => void;
  regions: MarsRegion[];

  // Map state
  mapCenter: Coordinates;
  mapZoom: number;
  setMapView: (center: Coordinates, zoom: number) => void;
  selectedDate: string; // ISO date string (YYYY-MM-DD)
  isLiveDate: boolean;  // True if syncing to real-time clock
  setSelectedDate: (date: string) => void;
  setIsLiveDate: (isLive: boolean) => void;
  syncToLive: () => void;

  // Layers
  layers: LayerConfig[];
  setLayerVisible: (id: string, visible: boolean) => void;
  setLayerOpacity: (id: string, opacity: number) => void;

  // Science targets
  scienceTargets: ScienceTarget[];
  selectedTargetId: string | null;
  setSelectedTarget: (id: string | null) => void;
  addScienceTarget: (target: ScienceTarget) => void;
  removeScienceTarget: (id: string) => void;
  updateScienceTarget: (id: string, updates: Partial<ScienceTarget>) => void;

  // Mars 2020 & Curiosity Geological Outcrops & Sample Caching
  outcrops: MarsOutcrop[];
  selectedOutcropId: string | null;
  setSelectedOutcrop: (id: string | null) => void;
  updateSampleTube: (outcropId: string, tubeUpdates: Partial<SampleTube>) => void;

  // Hazards
  hazards: Hazard[];

  // Routes
  routes: Route[];
  activeRouteId: string | null;
  setActiveRoute: (id: string | null) => void;
  addRoute: (route: Route) => void;
  removeRoute: (id: string) => void;

  // Candidate sites
  candidateSites: CandidateSite[];
  selectedSiteIds: string[];
  toggleSiteSelection: (id: string) => void;

  // Saved missions
  savedMissions: SavedMission[];
  activeMissionId: string | null;
  saveMission: (name: string, notes: string) => void;
  loadMission: (id: string) => void;
  deleteMission: (id: string) => void;

  // Settings
  theme: 'dark' | 'bright';
  units: 'metric' | 'imperial';
  coordFormat: 'decimal' | 'dms';
  setTheme: (theme: 'dark' | 'bright') => void;
  toggleTheme: () => void;
  setUnits: (u: 'metric' | 'imperial') => void;
  setCoordFormat: (f: 'decimal' | 'dms') => void;

  // UI state (not persisted)
  sidebarCollapsed: boolean;
  toggleSidebar: () => void;
  analysisOpen: boolean;
  setAnalysisOpen: (open: boolean) => void;
  statusMessage: string;
  setStatusMessage: (msg: string) => void;
  showIntro: boolean;
  setShowIntro: (show: boolean) => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      // Navigation
      activePage: 'overview',
      setActivePage: (page) => set({ activePage: page }),

      // Region
      selectedRegion: DEFAULT_REGION,
      setSelectedRegion: (region) =>
        set({
          selectedRegion: region,
          mapCenter: region.coordinates,
          mapZoom: 6,
        }),
      regions: MARS_REGIONS,

      // Map state
      mapCenter: DEFAULT_REGION.coordinates,
      mapZoom: 6,
      setMapView: (center, zoom) => set({ mapCenter: center, mapZoom: zoom }),
      selectedDate: new Date().toISOString().split('T')[0],
      isLiveDate: true,
      setSelectedDate: (date) => {
        const today = new Date().toISOString().split('T')[0];
        set({ selectedDate: date, isLiveDate: date === today });
      },
      setIsLiveDate: (isLive) => set({ isLiveDate: isLive }),
      syncToLive: () => {
        const today = new Date().toISOString().split('T')[0];
        set({ selectedDate: today, isLiveDate: true });
      },

      // Layers
      layers: DEFAULT_LAYERS,
      setLayerVisible: (id, visible) =>
        set((s) => ({
          layers: s.layers.map((l) => (l.id === id ? { ...l, visible } : l)),
        })),
      setLayerOpacity: (id, opacity) =>
        set((s) => ({
          layers: s.layers.map((l) => (l.id === id ? { ...l, opacity } : l)),
        })),

      // Science targets
      scienceTargets: SCIENCE_TARGETS,
      selectedTargetId: null,
      setSelectedTarget: (id) => set({ selectedTargetId: id }),
      addScienceTarget: (target) =>
        set((s) => ({ scienceTargets: [...s.scienceTargets, target] })),
      removeScienceTarget: (id) =>
        set((s) => ({
          scienceTargets: s.scienceTargets.filter((t) => t.id !== id),
          selectedTargetId: s.selectedTargetId === id ? null : s.selectedTargetId,
        })),
      updateScienceTarget: (id, updates) =>
        set((s) => ({
          scienceTargets: s.scienceTargets.map((t) =>
            t.id === id ? { ...t, ...updates } : t
          ),
        })),

      // Mars 2020 & Curiosity Geological Outcrops
      outcrops: MARS_2020_OUTCROPS,
      selectedOutcropId: null,
      setSelectedOutcrop: (id) => set({ selectedOutcropId: id }),
      updateSampleTube: (outcropId, tubeUpdates) =>
        set((s) => ({
          outcrops: s.outcrops.map((o) =>
            o.id === outcropId && o.sampleTube
              ? { ...o, sampleTube: { ...o.sampleTube, ...tubeUpdates } }
              : o
          ),
        })),

      // Hazards
      hazards: HAZARDS,

      // Routes
      routes: [],
      activeRouteId: null,
      setActiveRoute: (id) => set({ activeRouteId: id }),
      addRoute: (route) =>
        set((s) => ({ routes: [...s.routes, route], activeRouteId: route.id })),
      removeRoute: (id) =>
        set((s) => ({
          routes: s.routes.filter((r) => r.id !== id),
          activeRouteId: s.activeRouteId === id ? null : s.activeRouteId,
        })),

      // Candidate sites
      candidateSites: CANDIDATE_SITES,
      selectedSiteIds: ['site-A', 'site-C'],
      toggleSiteSelection: (id) =>
        set((s) => ({
          selectedSiteIds: s.selectedSiteIds.includes(id)
            ? s.selectedSiteIds.filter((x) => x !== id)
            : [...s.selectedSiteIds, id].slice(-4),
        })),

      // Saved missions
      savedMissions: [],
      activeMissionId: null,
      saveMission: (name, notes) => {
        const state = get();
        const mission: SavedMission = {
          id: `mission-${Date.now()}`,
          name,
          region: state.selectedRegion,
          routes: state.routes,
          scienceTargets: state.scienceTargets,
          candidateSites: state.candidateSites,
          activeLayerIds: state.layers.filter((l) => l.visible).map((l) => l.id),
          notes,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          version: '1.0.0',
        };
        set((s) => ({
          savedMissions: [...s.savedMissions, mission],
          activeMissionId: mission.id,
        }));
      },
      loadMission: (id) => {
        const mission = get().savedMissions.find((m) => m.id === id);
        if (!mission) return;
        set({
          activeMissionId: id,
          selectedRegion: mission.region,
          routes: mission.routes,
          scienceTargets: mission.scienceTargets,
          mapCenter: mission.region.coordinates,
        });
      },
      deleteMission: (id) =>
        set((s) => ({
          savedMissions: s.savedMissions.filter((m) => m.id !== id),
          activeMissionId: s.activeMissionId === id ? null : s.activeMissionId,
        })),

      // Settings
      theme: 'dark',
      units: 'metric',
      coordFormat: 'decimal',
      setTheme: (theme) => set({ theme }),
      toggleTheme: () => set((s) => ({ theme: s.theme === 'dark' ? 'bright' : 'dark' })),
      setUnits: (units) => set({ units }),
      setCoordFormat: (coordFormat) => set({ coordFormat }),

      // UI state
      sidebarCollapsed: false,
      toggleSidebar: () =>
        set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),
      analysisOpen: true,
      setAnalysisOpen: (open) => set({ analysisOpen: open }),
      statusMessage: '',
      setStatusMessage: (msg) => set({ statusMessage: msg }),
      showIntro: true,
      setShowIntro: (show) => set({ showIntro: show }),
    }),
    {
      name: 'atlasx',
      partialize: (state) => ({
        selectedRegion: state.selectedRegion,
        layers: state.layers,
        scienceTargets: state.scienceTargets,
        routes: state.routes,
        selectedSiteIds: state.selectedSiteIds,
        savedMissions: state.savedMissions,
        activeMissionId: state.activeMissionId,
        units: state.units,
        coordFormat: state.coordFormat,
        theme: state.theme,
      }),
    }
  )
);
