/**
 * React hooks for live NASA/JPL data.
 * Each hook manages loading, error, and stale states independently.
 * Falls back to simulated data if the backend is unreachable.
 */

import { useState, useEffect, useCallback, useRef } from 'react';
import {
  fetchMarsEphemeris,
  fetchInsightWeather,
  fetchSeasonalCurve,
  checkBackendHealth,
  type ApiResponse,
  type MarsEphemeris,
  type InsightWeather,
  type SeasonalCurve,
} from './api';

// ── Generic async data hook ──────────────────────────────────────────────────

interface UseAsyncDataState<T> {
  data: T | null;
  loading: boolean;
  error: string | null;
  source: 'live' | 'cached' | 'simulated' | 'unavailable';
  retrievedAt: string | null;
  refetch: () => void;
}

function useAsyncData<T>(
  fetcher: () => Promise<ApiResponse<T>>,
  deps: unknown[] = [],
  autoRefreshMs?: number,
): UseAsyncDataState<T> {
  const [state, setState] = useState<Omit<UseAsyncDataState<T>, 'refetch'>>({
    data: null,
    loading: true,
    error: null,
    source: 'unavailable',
    retrievedAt: null,
  });
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const load = useCallback(async () => {
    setState(s => ({ ...s, loading: true, error: null }));
    try {
      const result = await fetcher();
      setState({
        data: result.data,
        loading: false,
        error: result.error || null,
        source: result.source,
        retrievedAt: result.retrievedAt || null,
      });
    } catch (err) {
      setState(s => ({
        ...s,
        loading: false,
        error: err instanceof Error ? err.message : String(err),
        source: 'unavailable',
      }));
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);

  useEffect(() => {
    load();
    if (autoRefreshMs) {
      timerRef.current = setInterval(load, autoRefreshMs);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [load, autoRefreshMs]);

  return { ...state, refetch: load };
}

// ── Specific data hooks ──────────────────────────────────────────────────────

/** Real JPL Horizons Mars orbital ephemeris for a specific date */
export function useMarsEphemeris(date?: string) {
  return useAsyncData<MarsEphemeris>(
    () => fetchMarsEphemeris(date),
    [date],
  );
}

/** Real NASA InSight surface weather (Elysium Planitia, last available sols) */
export function useInsightWeather() {
  return useAsyncData<InsightWeather>(
    () => fetchInsightWeather(),
    [],
  );
}

/** Irradiance vs solar longitude over a full Martian year */
export function useSeasonalCurve() {
  return useAsyncData<SeasonalCurve>(
    () => fetchSeasonalCurve(),
    [],
  );
}

/** Backend connectivity status, polled every 30 seconds */
export function useBackendStatus() {
  const [alive, setAlive] = useState<boolean | null>(null);
  const [checking, setChecking] = useState(true);

  const check = useCallback(async () => {
    setChecking(true);
    const ok = await checkBackendHealth();
    setAlive(ok);
    setChecking(false);
  }, []);

  useEffect(() => {
    check();
    const interval = setInterval(check, 30_000);
    return () => clearInterval(interval);
  }, [check]);

  return { alive, checking, recheck: check };
}

/** Real-time Mars clock from backend API */
export function useBackendMarsTime(lon?: number, autoRefreshMs = 5000) {
  return useAsyncData<import('./api').MarsTimeData>(
    () => import('./api').then(m => m.fetchMarsTime(lon)),
    [lon],
    autoRefreshMs,
  );
}
