import React, { useState, useCallback, useEffect, useMemo } from 'react';
import {
  MapContainer, TileLayer, WMSTileLayer, CircleMarker, Marker, Popup,
  Polyline, useMapEvents, ScaleControl, useMap, ZoomControl,
  SVGOverlay,
} from 'react-leaflet';
import L from 'leaflet';
import { useAppStore } from '../store/useAppStore';
import { HAZARDS, SCIENCE_TARGETS, CANDIDATE_SITES } from '../data/sampleData';
import { marsDistance } from '../utils/marsCoordinates';
import DataBadge from '../components/ui/DataBadge';
import {
  Ruler, Crosshair, Trash2, Eye, EyeOff,
  ChevronDown, ChevronUp, LocateFixed, Route, Info,
  Copy, Check, Grid3x3, MapPin, X, Star, Layers,
} from 'lucide-react';

// ── Offline global basemap fallback images (instant load, 0ms latency) ──────
import molaThemisGlobalImg from '../assets/basemaps/mars_mola_themis_global.jpg';
import vikingGlobalImg from '../assets/basemaps/mars_viking_global.jpg';
import molaColorGlobalImg from '../assets/basemaps/mars_mola_color_global.jpg';

// ── Leaflet icon fix (Offline embedded SVG, avoids external CDN network failures) ─
const DEFAULT_PIN_SVG = `data:image/svg+xml;utf8,${encodeURIComponent(
  `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="34" viewBox="0 0 24 34"><path d="M12 0C5.37 0 0 5.37 0 12c0 9 12 22 12 22s12-13 12-22c0-6.63-5.37-12-12-12z" fill="#e84020" stroke="#ffffff" stroke-width="1.5"/><circle cx="12" cy="12" r="4" fill="#ffffff"/></svg>`
)}`;
const EMPTY_SHADOW_SVG = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="1" height="1"/>';

delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: DEFAULT_PIN_SVG,
  iconUrl: DEFAULT_PIN_SVG,
  shadowUrl: EMPTY_SHADOW_SVG,
});

// ── Color maps ────────────────────────────────────────────────────────────────
const HAZARD_COLORS: Record<string, string> = {
  none: '#94a3b8', low: '#22d3ee', moderate: '#f59e0b', high: '#ef4444', extreme: '#dc2626',
};
const SCIENCE_CAT_COLORS: Record<string, string> = {
  mineralogy: '#a78bfa', geology: '#60a5fa', hydrology: '#34d399',
  geomorphology: '#f9a8d4', astrobiology: '#f87171', resource: '#fbbf24', atmospheric: '#67e8f9',
};
const WAYPOINT_COLORS = ['#f46040','#22d3ee','#a78bfa','#34d399','#fbbf24','#f87171','#60a5fa','#fb923c'];

// ── Basemap Definitions ───────────────────────────────────────────────────────
const USGS_WMS = 'https://planetarymaps.usgs.gov/cgi-bin/mapserv?map=/maps/mars/mars_simp_cyl.map';

interface BasemapDef {
  id: string;
  label: string;
  shortLabel: string;
  type: 'tile' | 'wms';
  url: string;
  layer?: string;         // WMS layer name
  fallbackImage?: string; // offline / preloaded global mosaic image
  attribution: string;
  description: string;
  maxNativeZoom?: number; // max zoom available on server before client scaling
  maxZoom: number;
  source: string;        // instrument / mission
  color: string;         // accent color for UI
}

const BASEMAPS: BasemapDef[] = [
  {
    id: 'nasa-trek-viking',
    label: 'NASA Mars Trek — Viking Color (232m/px)',
    shortLabel: 'NASA Viking',
    type: 'tile',
    url: 'https://trek.nasa.gov/tiles/Mars/EQ/Mars_Viking_MDIM21_ClrMosaic_global_232m/1.0.0/default/default028mm/{z}/{y}/{x}.jpg',
    attribution: '© NASA / JPL / USGS Mars Trek | Viking Orbiter MDIM 2.1',
    description: 'Premier global natural-color mosaic streamed directly from NASA Solar System Treks global tile cache. Pre-rendered high-speed tiles (~232 m/px).',
    maxNativeZoom: 7,
    maxZoom: 12,
    source: 'NASA JPL Mars Trek',
    color: '#38bdf8',
  },
  {
    id: 'usgs-themis-blend',
    label: 'USGS — MOLA + THEMIS Blend (100m/px)',
    shortLabel: 'THEMIS Blend',
    type: 'wms',
    url: USGS_WMS,
    layer: 'MOLA_THEMIS_blend',
    attribution: '© USGS Astrogeology | NASA MGS MOLA + Odyssey THEMIS',
    description: 'Premier USGS terrain mosaic blending MGS MOLA elevation topography with Mars Odyssey THEMIS daytime thermal infrared (~100 m/px). High crater and dune detail.',
    maxNativeZoom: 12,
    maxZoom: 12,
    source: 'NASA MGS + Odyssey • USGS',
    color: '#f97316',
  },
  {
    id: 'nasa-trek-mola',
    label: 'NASA Mars Trek — MOLA Color Elevation',
    shortLabel: 'NASA MOLA',
    type: 'tile',
    url: 'https://trek.nasa.gov/tiles/Mars/EQ/Mars_MGS_MOLA_ClrShade_merge_global_463m/1.0.0/default/default028mm/{z}/{y}/{x}.jpg',
    attribution: '© NASA / JPL / USGS Mars Trek | MGS MOLA Elevation',
    description: 'Color-coded topography and shaded relief streamed directly from NASA Solar System Treks global cache (~463 m/px).',
    maxNativeZoom: 7,
    maxZoom: 12,
    source: 'NASA JPL Mars Trek',
    color: '#34d399',
  },
  {
    id: 'usgs-mdim',
    label: 'Viking Color Mosaic (USGS WMS)',
    shortLabel: 'Viking Color',
    type: 'wms',
    url: USGS_WMS,
    layer: 'MDIM21_color',
    fallbackImage: vikingGlobalImg,
    attribution: '© USGS Astrogeology | Viking/NASA MDIM 2.1',
    description: 'Mars Digital Image Model 2.1 — global color mosaic from Viking Orbiter cameras (1976–1980). ~232 m/px. True-color closest to real Mars surface.',
    maxZoom: 10,
    source: 'Viking Orbiter • USGS MDIM 2.1',
    color: '#c2864e',
  },
  {
    id: 'usgs-mola',
    label: 'MOLA Color Elevation (USGS WMS)',
    shortLabel: 'MOLA Color',
    type: 'wms',
    url: USGS_WMS,
    layer: 'MOLA_color',
    fallbackImage: molaColorGlobalImg,
    attribution: '© USGS Astrogeology | MOLA/MGS/NASA',
    description: 'Mars Orbiter Laser Altimeter (MOLA) colorized elevation map. Blue/green = low elevations; red/white = high elevations. ~460 m/px.',
    maxZoom: 10,
    source: 'MGS MOLA • USGS',
    color: '#22d3ee',
  },
  {
    id: 'usgs-themis',
    label: 'THEMIS Day IR (USGS WMS)',
    shortLabel: 'THEMIS IR',
    type: 'wms',
    url: USGS_WMS,
    layer: 'THEMIS',
    fallbackImage: molaThemisGlobalImg,
    attribution: '© USGS Astrogeology | THEMIS/Odyssey/NASA',
    description: 'Thermal Emission Imaging System (THEMIS) daytime infrared mosaic from Mars Odyssey. ~100 m/px. Brighter = warmer surfaces. Reveals rock vs. sand.',
    maxZoom: 12,
    source: 'Mars Odyssey THEMIS • USGS',
    color: '#eab308',
  },
  {
    id: 'usgs-hrsc',
    label: 'HRSC + MOLA Hillshade (USGS WMS)',
    shortLabel: 'HRSC Hillshade',
    type: 'wms',
    url: USGS_WMS,
    layer: 'HRSC_MOLA_Blend_Hillshade',
    fallbackImage: molaThemisGlobalImg,
    attribution: '© USGS Astrogeology | ESA Mars Express + NASA MGS',
    description: 'High-Resolution Stereo Camera (HRSC) blended with MOLA digital terrain hillshade. Highlights high-contrast sunward slopes, crater ramparts, and tectonic grabens.',
    maxZoom: 12,
    source: 'ESA Mars Express + NASA MGS • USGS',
    color: '#94a3b8',
  },
  {
    id: 'usgs-mola-bw',
    label: 'MOLA Shaded Relief (USGS WMS)',
    shortLabel: 'MOLA Shaded',
    type: 'wms',
    url: USGS_WMS,
    layer: 'MOLA_bw',
    fallbackImage: molaThemisGlobalImg,
    attribution: '© USGS Astrogeology | MGS MOLA',
    description: 'Black-and-white shaded relief derived from MOLA topographic gridded data, illuminating subtle geological structures and volcanic calderas.',
    maxZoom: 10,
    source: 'MGS MOLA • USGS',
    color: '#64748b',
  },
];

// ── Types ─────────────────────────────────────────────────────────────────────
interface WaypointPin { id: string; lat: number; lon: number; label: string; color: string; note?: string; }
interface ClickedFeature { type: 'hazard'|'science'|'site'|'waypoint'|'point'; data: any; }
type MapMode = 'inspect' | 'measure' | 'waypoint';

// ── Helpers ───────────────────────────────────────────────────────────────────
function totalDist(pts: { lat: number; lon: number }[]) {
  let d = 0;
  for (let i = 1; i < pts.length; i++) d += marsDistance(pts[i-1], pts[i]);
  return d;
}
function fmtCoord(v: number, isLat: boolean) {
  const dir = isLat ? (v >= 0 ? 'N' : 'S') : (v >= 0 ? 'E' : 'W');
  return `${Math.abs(v).toFixed(5)}° ${dir}`;
}
function fmtDMS(decimal: number, isLat: boolean) {
  const abs = Math.abs(decimal);
  const d = Math.floor(abs);
  const m = Math.floor((abs - d) * 60);
  const s = ((abs - d - m / 60) * 3600).toFixed(1);
  const dir = isLat ? (decimal >= 0 ? 'N' : 'S') : (decimal >= 0 ? 'E' : 'W');
  return `${d}° ${m}' ${s}" ${dir}`;
}

// ── Custom Markers ────────────────────────────────────────────────────────────
/** Crosshair origin marker */
function makeOriginIcon() {
  return L.divIcon({
    className: '',
    html: `<div style="width:40px;height:40px;position:relative;transform:translate(-50%,-50%)">
      <!-- Outer ring -->
      <svg width="40" height="40" viewBox="0 0 40 40" style="position:absolute;top:0;left:0">
        <circle cx="20" cy="20" r="16" fill="none" stroke="#34d399" stroke-width="1.5" stroke-dasharray="4,3" opacity="0.7"/>
        <circle cx="20" cy="20" r="6" fill="none" stroke="#34d399" stroke-width="2" opacity="0.9"/>
        <circle cx="20" cy="20" r="2.5" fill="#34d399"/>
        <!-- crosshair lines -->
        <line x1="20" y1="2"  x2="20" y2="12" stroke="#34d399" stroke-width="1.5" opacity="0.9"/>
        <line x1="20" y1="28" x2="20" y2="38" stroke="#34d399" stroke-width="1.5" opacity="0.9"/>
        <line x1="2"  y1="20" x2="12" y2="20" stroke="#34d399" stroke-width="1.5" opacity="0.9"/>
        <line x1="28" y1="20" x2="38" y2="20" stroke="#34d399" stroke-width="1.5" opacity="0.9"/>
      </svg>
    </div>`,
    iconSize: [40, 40],
    iconAnchor: [20, 20],
    popupAnchor: [0, -22],
  });
}

/** Waypoint teardrop */
function makeWaypointIcon(color: string, letter: string) {
  return L.divIcon({
    className: '',
    html: `<div style="width:28px;height:28px;position:relative">
      <svg width="28" height="34" viewBox="0 0 28 34" style="position:absolute;top:0;left:0">
        <path d="M14 0 C6.3 0 0 6.3 0 14 C0 24 14 34 14 34 C14 34 28 24 28 14 C28 6.3 21.7 0 14 0Z"
          fill="${color}" fill-opacity="0.9" stroke="rgba(255,255,255,0.6)" stroke-width="1.2"/>
        <text x="14" y="17" text-anchor="middle" dominant-baseline="middle"
          fill="white" font-size="11" font-weight="700" font-family="monospace">${letter}</text>
      </svg>
    </div>`,
    iconSize: [28, 34],
    iconAnchor: [14, 34],
    popupAnchor: [0, -36],
  });
}

/** Measure point */
function makeMeasureIcon(num: number) {
  return L.divIcon({
    className: '',
    html: `<div style="width:22px;height:22px;border-radius:50%;background:rgba(34,211,238,0.25);
      border:2px solid #22d3ee;display:flex;align-items:center;justify-content:center;
      font-size:10px;font-weight:700;color:#22d3ee;font-family:monospace;
      box-shadow:0 0 8px rgba(34,211,238,0.4);">${num}</div>`,
    iconSize: [22, 22],
    iconAnchor: [11, 11],
    popupAnchor: [0, -14],
  });
}

// ── Graticule Grid ────────────────────────────────────────────────────────────
/** Draws Mars coordinate grid lines at a given interval */
function GraticuleGrid({ interval, opacity }: { interval: number; opacity: number }) {
  const map = useMap();
  const [bounds, setBounds] = useState(() => {
    try { return map.getBounds(); } catch { return null; }
  });

  useMapEvents({
    moveend() { try { setBounds(map.getBounds()); } catch {} },
    zoomend() { try { setBounds(map.getBounds()); } catch {} },
  });

  const lines = useMemo(() => {
    if (!bounds || !bounds.isValid()) return [];
    const zoom = map.getZoom?.() ?? 4;
    const minSafe = zoom <= 2 ? 30 : zoom <= 4 ? 15 : zoom <= 6 ? 5 : 1;
    const safeInterval = Math.max(minSafe, interval || 5);
    const s = Math.max(-90, Math.floor(bounds.getSouth() / safeInterval) * safeInterval);
    const n = Math.min(90, Math.ceil(bounds.getNorth() / safeInterval) * safeInterval);
    const w = Math.max(-180, Math.floor(bounds.getWest() / safeInterval) * safeInterval);
    const e = Math.min(180, Math.ceil(bounds.getEast() / safeInterval) * safeInterval);

    const result: { positions: [number, number][]; label: string; isLat: boolean; labelPos: [number, number] }[] = [];

    // Latitude lines (Mars simple cylindrical extends full [-90, 90])
    for (let lat = s; lat <= n; lat += safeInterval) {
      if (lat < -90 || lat > 90) continue;
      result.push({
        positions: [[lat, w], [lat, e]],
        label: `${Math.abs(lat)}° ${lat >= 0 ? 'N' : 'S'}`,
        isLat: true,
        labelPos: [lat, w + (e - w) * 0.02],
      });
    }
    // Longitude lines (clamped to [-180, 180])
    for (let lon = w; lon <= e; lon += safeInterval) {
      if (lon < -180 || lon > 180) continue;
      result.push({
        positions: [[s, lon], [n, lon]],
        label: `${Math.abs(lon)}° ${lon >= 0 ? 'E' : 'W'}`,
        isLat: false,
        labelPos: [s + (n - s) * 0.02, lon],
      });
    }
    return result;
  }, [bounds, interval, map]);

  return (
    <>
      {lines.map((line, i) => (
        <Polyline
          key={`graticule-${line.isLat ? 'lat' : 'lon'}-${i}`}
          positions={line.positions}
          pathOptions={{
            color: line.isLat ? 'rgba(100,148,212,0.45)' : 'rgba(100,148,212,0.3)',
            weight: line.isLat ? 0.8 : 0.6,
            opacity,
            dashArray: line.isLat ? undefined : '3,5',
          }}
        />
      ))}
    </>
  );
}

/** SVG labels for graticule — rendered as floating divs via custom Leaflet panes */
function GraticuleLabels({ interval, opacity }: { interval: number; opacity: number }) {
  const map = useMap();
  const containerRef = React.useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!map) return;
    try {
      if (!map.getPane('graticule-labels')) {
        map.createPane('graticule-labels');
        const pane = map.getPane('graticule-labels');
        if (pane) {
          pane.style.zIndex = '399';
          pane.style.pointerEvents = 'none';
        }
      }
    } catch {}

    const pane = map.getPane('graticule-labels');
    if (!pane) return;

    const div = document.createElement('div');
    div.style.cssText = 'position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;';
    pane.appendChild(div);
    containerRef.current = div;

    const update = () => {
      if (!containerRef.current) return;
      try {
        const size = map.getSize();
        if (!size || size.x <= 0 || size.y <= 0) return;
        const bounds = map.getBounds();
        if (!bounds || !bounds.isValid()) return;

        const zoom = map.getZoom?.() ?? 4;
        const minSafe = zoom <= 2 ? 30 : zoom <= 4 ? 15 : zoom <= 6 ? 5 : 1;
        const safeInterval = Math.max(minSafe, interval || 5);
        const s = Math.max(-90, Math.floor(bounds.getSouth() / safeInterval) * safeInterval);
        const n = Math.min(90, Math.ceil(bounds.getNorth() / safeInterval) * safeInterval);
        const w = Math.max(-180, Math.floor(bounds.getWest() / safeInterval) * safeInterval);
        const e = Math.min(180, Math.ceil(bounds.getEast() / safeInterval) * safeInterval);

        let html = '';

        // Lat labels on left edge
        for (let lat = s; lat <= n; lat += safeInterval) {
          if (lat < -90 || lat > 90) continue;
          try {
            const pt = map.latLngToContainerPoint([lat, Math.max(-180, bounds.getWest())]);
            if (!isFinite(pt.x) || !isFinite(pt.y)) continue;
            html += `<div style="position:absolute;left:${Math.max(4, pt.x + 4)}px;top:${pt.y - 8}px;
              font-size:9px;font-family:monospace;color:rgba(100,180,255,${opacity * 0.85});
              text-shadow:0 1px 3px rgba(0,0,0,0.8);white-space:nowrap;font-weight:600;">
              ${Math.abs(lat)}°${lat >= 0 ? 'N' : 'S'}
            </div>`;
          } catch {}
        }
        // Lon labels on bottom edge
        for (let lon = w; lon <= e; lon += safeInterval) {
          if (lon < -180 || lon > 180) continue;
          try {
            const pt = map.latLngToContainerPoint([Math.max(-90, bounds.getSouth()), lon]);
            if (!isFinite(pt.x) || !isFinite(pt.y)) continue;
            html += `<div style="position:absolute;left:${pt.x - 14}px;top:${Math.max(14, pt.y - 14)}px;
              font-size:9px;font-family:monospace;color:rgba(100,180,255,${opacity * 0.7});
              text-shadow:0 1px 3px rgba(0,0,0,0.8);white-space:nowrap;font-weight:600;">
              ${Math.abs(lon)}°${lon >= 0 ? 'E' : 'W'}
            </div>`;
          } catch {}
        }

        containerRef.current.innerHTML = html;
      } catch {}
    };

    map.on('moveend zoomend', update);
    update();

    return () => {
      map.off('moveend zoomend', update);
      if (div.parentNode) {
        div.parentNode.removeChild(div);
      }
      containerRef.current = null;
    };
  }, [map, interval, opacity]);

  return null;
}

// ── Map event handlers ────────────────────────────────────────────────────────
function MapEventHandler({
  mode, onCursor, onMapClick,
}: {
  mode: MapMode;
  onCursor: (lat: number, lon: number) => void;
  onMapClick: (lat: number, lon: number) => void;
}) {
  const lastMove = React.useRef(0);
  useMapEvents({
    mousemove(e) {
      const now = Date.now();
      if (now - lastMove.current > 40) { // ~25 fps throttle for smooth cursor
        lastMove.current = now;
        onCursor(e.latlng.lat, e.latlng.lng);
      }
    },
    click(e) { onMapClick(e.latlng.lat, e.latlng.lng); },
  });
  return null;
}

function AutoResizeMap() {
  const map = useMap();

  useEffect(() => {
    // Staggered invalidations ensure Leaflet sizes itself accurately after CSS layouts settle
    const timers = [
      setTimeout(() => { try { map.invalidateSize({ debounceMoveend: true }); } catch {} }, 50),
      setTimeout(() => { try { map.invalidateSize({ debounceMoveend: true }); } catch {} }, 250),
      setTimeout(() => { try { map.invalidateSize({ debounceMoveend: true }); } catch {} }, 750),
      setTimeout(() => { try { map.invalidateSize({ debounceMoveend: true }); } catch {} }, 1500),
    ];

    const container = map.getContainer();
    let ro: ResizeObserver | null = null;
    if (typeof ResizeObserver !== 'undefined' && container) {
      ro = new ResizeObserver(() => {
        try { map.invalidateSize({ debounceMoveend: true }); } catch {}
      });
      ro.observe(container);
    }

    return () => {
      timers.forEach(clearTimeout);
      if (ro) ro.disconnect();
    };
  }, [map]);

  return null;
}

function MapController({ flyTo }: { flyTo: { lat: number; lon: number; zoom: number } | null }) {
  const map = useMap();
  useEffect(() => {
    if (flyTo) {
      try {
        map.flyTo([flyTo.lat, flyTo.lon], flyTo.zoom, { duration: 1.2 });
      } catch (err) {
        console.warn('MapController flyTo failed:', err);
      }
    }
  }, [flyTo, map]);
  return null;
}

// ── Detail Panel ──────────────────────────────────────────────────────────────
function FeatureDetailPanel({ feature, onClose }: { feature: ClickedFeature | null; onClose: () => void }) {
  if (!feature) return null;
  const { type, data } = feature;

  return (
    <div className="absolute top-10 right-2 z-[1001] w-64 glass-panel p-3 space-y-2 border border-white/10 shadow-xl">
      <div className="flex items-center justify-between">
        <div className="text-[10px] text-slate-500 uppercase tracking-widest font-mono">
          {type === 'hazard' ? '⚠ Hazard Detail' :
           type === 'science' ? '🔬 Science Target' :
           type === 'site' ? '⭐ Candidate Site' :
           type === 'waypoint' ? '📍 Waypoint' : '📌 Point'}
        </div>
        <button onClick={onClose} className="text-slate-600 hover:text-slate-300 transition-colors">
          <X size={13} />
        </button>
      </div>

      {type === 'hazard' && (
        <div className="space-y-1.5 text-xs">
          <div className="font-semibold text-orange-400 capitalize text-sm">{data.type?.replace(/-/g, ' ')}</div>
          <Row label="Severity" value={<span className="capitalize font-medium" style={{ color: HAZARD_COLORS[data.severity] }}>{data.severity}</span>} />
          <Row label="Radius" value={`${data.radius ?? '?'} m`} />
          <Row label="Confidence" value={`${(data.confidence * 100).toFixed(0)}%`} />
          <Row label="Latitude" value={fmtDMS(data.coordinates.lat, true)} />
          <Row label="Longitude" value={fmtDMS(data.coordinates.lon, false)} />
          <Row label="Source" value={data.dataSource} mono />
          <div className="text-slate-400 text-[11px] pt-1 border-t border-white/10">{data.description}</div>
        </div>
      )}

      {type === 'science' && (
        <div className="space-y-1.5 text-xs">
          <div className="font-semibold text-sm" style={{ color: SCIENCE_CAT_COLORS[data.category] }}>{data.name}</div>
          <Row label="Category" value={<span className="capitalize">{data.category}</span>} />
          <Row label="Priority" value={`${'★'.repeat(data.priority)}${'☆'.repeat(5 - data.priority)} (${data.priority}/5)`} />
          <Row label="Latitude" value={fmtDMS(data.coordinates.lat, true)} />
          <Row label="Longitude" value={fmtDMS(data.coordinates.lon, false)} />
          <Row label="Data Quality" value={data.dataQuality} />
          <Row label="Source" value={data.dataSource} mono />
          <div className="text-slate-400 text-[11px] pt-1 border-t border-white/10">{data.rationale}</div>
        </div>
      )}

      {type === 'site' && (
        <div className="space-y-1.5 text-xs">
          <div className="font-semibold text-yellow-400 text-sm">⭐ {data.name}</div>
          <Row label="Latitude" value={fmtDMS(data.coordinates.lat, true)} />
          <Row label="Longitude" value={fmtDMS(data.coordinates.lon, false)} />
          {data.landingSuitability && <Row label="Landing Score" value={`${data.landingSuitability.overall}/100`} />}
          {data.ascentSuitability && <Row label="Ascent Score" value={`${data.ascentSuitability.overall}/100`} />}
          <Row label="Science Value" value={`${data.scienceValue}/100`} />
          <div className="text-orange-400 text-[10px] pt-1">⚠ Demonstration data — not certified</div>
        </div>
      )}

      {type === 'point' && (
        <div className="space-y-1.5 text-xs">
          <div className="font-semibold text-slate-200">Map Point</div>
          <Row label="Latitude" value={fmtDMS(data.lat, true)} />
          <Row label="Longitude" value={fmtDMS(data.lon, false)} />
          <Row label="Decimal" value={`${data.lat.toFixed(6)}, ${data.lon.toFixed(6)}`} mono />
        </div>
      )}
    </div>
  );
}

function Row({ label, value, mono }: { label: string; value: React.ReactNode; mono?: boolean }) {
  return (
    <div className="flex items-start justify-between gap-2">
      <span className="text-slate-500 flex-shrink-0">{label}</span>
      <span className={`text-slate-200 text-right ${mono ? 'font-mono text-[10px]' : ''}`}>{value}</span>
    </div>
  );
}

// ── Main Component ────────────────────────────────────────────────────────────
export default function AtlasPage() {
  const {
    mapCenter, mapZoom, layers, setLayerVisible, setLayerOpacity,
    setSelectedTarget, selectedRegion, regions, setSelectedRegion,
    theme,
  } = useAppStore();

  const [cursor, setCursor] = useState<{ lat: number; lon: number } | null>(null);
  const [flyTo, setFlyTo] = useState<{ lat: number; lon: number; zoom: number } | null>(null);
  const [mode, setMode] = useState<MapMode>('inspect');
  const [copied, setCopied] = useState(false);

  // Graticule
  const [showGrid, setShowGrid] = useState(true);
  const [gridInterval, setGridInterval] = useState(5);
  const [gridOpacity, setGridOpacity] = useState(0.8);

  // Origin
  const [origin, setOrigin] = useState<{ lat: number; lon: number } | null>(null);

  // Measure
  const [measurePoints, setMeasurePoints] = useState<{ lat: number; lon: number }[]>([]);

  // Waypoints
  const [waypoints, setWaypoints] = useState<WaypointPin[]>([]);
  const [editingWpId, setEditingWpId] = useState<string | null>(null);
  const [editNote, setEditNote] = useState('');

  // Feature detail panel
  const [selectedFeature, setSelectedFeature] = useState<ClickedFeature | null>(null);

  // Panels open/close
  const [showLayers, setShowLayers] = useState(true);
  const [showLegend, setShowLegend] = useState(false);
  const [showGridPanel, setShowGridPanel] = useState(true);

  // Go-to input
  const [gotoLat, setGotoLat] = useState('');
  const [gotoLon, setGotoLon] = useState('');
  const [gotoError, setGotoError] = useState('');

  // Coord format
  const [coordFormat, setCoordFormat] = useState<'decimal' | 'dms'>('decimal');

  // Basemap
  const [activeBasemapId, setActiveBasemapId] = useState('nasa-trek-viking');
  const [showBasemapPanel, setShowBasemapPanel] = useState(false);
  const activeBasemap = BASEMAPS.find(b => b.id === activeBasemapId) ?? BASEMAPS[0];

  const hazardLayer = layers.find(l => l.id === 'hazard-layer');
  const scienceLayer = layers.find(l => l.id === 'science-targets');

  // ── Derived ───────────────────────────────────────────────────────────────
  const measureTotal = totalDist(measurePoints);
  const waypointTotal = totalDist(waypoints.map(w => ({ lat: w.lat, lon: w.lon })));
  const originToCursor = origin && cursor ? marsDistance(origin, cursor) : null;

  const displayCoord = useCallback((lat: number, lon: number) => {
    if (coordFormat === 'dms') return `${fmtDMS(lat, true)}\n${fmtDMS(lon, false)}`;
    return `${fmtCoord(lat, true)}, ${fmtCoord(lon, false)}`;
  }, [coordFormat]);

  // ── Handlers ──────────────────────────────────────────────────────────────
  const handleMapClick = useCallback((lat: number, lon: number) => {
    if (mode === 'measure') {
      setMeasurePoints(prev => [...prev, { lat, lon }]);
    } else if (mode === 'waypoint') {
      const idx = waypoints.length;
      setWaypoints(prev => [...prev, {
        id: `wp-${Date.now()}`, lat, lon,
        label: String.fromCharCode(65 + (idx % 26)),
        color: WAYPOINT_COLORS[idx % WAYPOINT_COLORS.length],
      }]);
    } else {
      // inspect mode: show point detail
      setSelectedFeature({ type: 'point', data: { lat, lon } });
    }
  }, [mode, waypoints.length]);

  const handleGoto = () => {
    const lat = parseFloat(gotoLat);
    let lon = parseFloat(gotoLon);
    if (isNaN(lat) || isNaN(lon) || lat < -90 || lat > 90) {
      setGotoError('Invalid latitude (−90 to 90)'); return;
    }
    // Auto-normalize 0..360 longitude to standard -180..180
    if (lon > 180 && lon <= 360) lon -= 360;
    if (lon < -180 || lon > 180) {
      setGotoError('Invalid longitude (−180 to 180 or 0 to 360)'); return;
    }
    setGotoError('');
    setFlyTo({ lat, lon, zoom: 8 });
    setTimeout(() => setFlyTo(null), 2000);
  };

  const copyCoords = (lat: number, lon: number) => {
    navigator.clipboard.writeText(`${lat.toFixed(6)}, ${lon.toFixed(6)}`).catch(() => {});
    setCopied(true); setTimeout(() => setCopied(false), 1500);
  };

  return (
    <div className="flex w-full h-full min-h-0 min-w-0 overflow-hidden">

      {/* ── LEFT SIDEBAR ─────────────────────────────────────────────────── */}
      <div className="w-60 flex-shrink-0 flex flex-col gap-2 p-2 border-r border-white/5 overflow-y-auto bg-navy-900/60">

        {/* Mode */}
        <div className="glass-panel p-2">
          <div className="text-[9px] text-slate-600 uppercase tracking-widest mb-1.5 font-mono">Interaction Mode</div>
          <div className="grid grid-cols-3 gap-1">
            {([
              { id: 'inspect', icon: <Info size={12}/>, label: 'Inspect' },
              { id: 'measure', icon: <Ruler size={12}/>, label: 'Measure' },
              { id: 'waypoint', icon: <Route size={12}/>, label: 'Route' },
            ] as const).map(m => (
              <button key={m.id} onClick={() => setMode(m.id)}
                className={`flex flex-col items-center gap-0.5 py-1.5 rounded text-[10px] font-medium transition-all border ${
                  mode === m.id ? 'bg-mars-600/25 border-mars-500/40 text-orange-300' : 'border-transparent text-slate-500 hover:text-slate-300 hover:bg-white/5'
                }`}>
                {m.icon}{m.label}
              </button>
            ))}
          </div>
        </div>

        {/* Go to coords */}
        <div className="glass-panel p-2">
          <div className="flex items-center gap-1 mb-1.5">
            <LocateFixed size={10} className="text-cyan-400"/>
            <span className="text-[9px] text-slate-500 uppercase tracking-widest font-mono">Go To Coords</span>
          </div>
          <div className="space-y-1">
            <input type="text" placeholder="Latitude (−90 to 90)" value={gotoLat}
              onChange={e => setGotoLat(e.target.value)}
              className="w-full bg-white/5 border border-white/10 rounded px-2 py-1 text-xs text-slate-200 font-mono placeholder-slate-700 focus:outline-none focus:border-cyan-500/50"/>
            <input type="text" placeholder="Longitude (−180 to 180)" value={gotoLon}
              onChange={e => setGotoLon(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleGoto()}
              className="w-full bg-white/5 border border-white/10 rounded px-2 py-1 text-xs text-slate-200 font-mono placeholder-slate-700 focus:outline-none focus:border-cyan-500/50"/>
            {gotoError && <div className="text-[10px] text-red-400">{gotoError}</div>}
            <button onClick={handleGoto}
              className="w-full py-1 rounded bg-cyan-500/15 border border-cyan-500/30 text-xs text-cyan-300 hover:bg-cyan-500/25 transition-colors font-medium">
              ▶ Fly To
            </button>
          </div>
          {/* Coord format toggle */}
          <div className="flex items-center justify-between mt-2 pt-1.5 border-t border-white/5">
            <span className="text-[9px] text-slate-600">Format</span>
            <div className="flex gap-1">
              {(['decimal','dms'] as const).map(f => (
                <button key={f} onClick={() => setCoordFormat(f)}
                  className={`px-1.5 py-0.5 rounded text-[9px] font-mono transition-colors ${coordFormat === f ? 'bg-orange-500/20 text-orange-300' : 'text-slate-600 hover:text-slate-400'}`}>
                  {f.toUpperCase()}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Regions */}
        <div className="glass-panel p-2">
          <div className="text-[9px] text-slate-600 uppercase tracking-widest mb-1.5 font-mono">Study Regions</div>
          <div className="space-y-0.5">
            {regions.map(r => (
              <button key={r.id}
                onClick={() => { setSelectedRegion(r); setFlyTo({ lat: r.coordinates.lat, lon: r.coordinates.lon, zoom: 7 }); setTimeout(() => setFlyTo(null), 2000); }}
                className={`w-full text-left px-2 py-1.5 rounded text-xs transition-colors border ${
                  r.id === selectedRegion.id ? 'bg-mars-600/20 text-orange-400 border-mars-600/30' : 'text-slate-400 hover:bg-white/5 hover:text-slate-200 border-transparent'
                }`}>
                <div className="font-medium">{r.name}</div>
                <div className="text-[9px] text-slate-600 font-mono">{r.coordinates.lat.toFixed(2)}°N · {r.coordinates.lon.toFixed(2)}°E</div>
              </button>
            ))}
          </div>
        </div>

        {/* ── Basemap Switcher ────────────────────────────────────────── */}
        <div className="glass-panel p-2">
          <button className="flex items-center justify-between w-full" onClick={() => setShowBasemapPanel(v => !v)}>
            <div className="flex items-center gap-1.5">
              <Layers size={10} className="text-orange-400"/>
              <span className="text-[9px] text-slate-500 uppercase tracking-widest font-mono">Basemap</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="text-[9px] font-mono px-1 rounded" style={{ color: activeBasemap.color, background: `${activeBasemap.color}22` }}>
                {activeBasemap.shortLabel}
              </span>
              {showBasemapPanel ? <ChevronUp size={10} className="text-slate-600"/> : <ChevronDown size={10} className="text-slate-600"/>}
            </div>
          </button>

          {showBasemapPanel && (
            <div className="mt-2 space-y-1.5">
              {BASEMAPS.map(bm => (
                <button
                  key={bm.id}
                  onClick={() => setActiveBasemapId(bm.id)}
                  className={`w-full text-left rounded px-2 py-1.5 border transition-all ${
                    activeBasemapId === bm.id
                      ? 'border-white/20 bg-white/8'
                      : 'border-transparent hover:bg-white/5'
                  }`}
                >
                  <div className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: bm.color }}/>
                    <span className={`text-[11px] font-medium ${activeBasemapId === bm.id ? 'text-white' : 'text-slate-400'}`}>
                      {bm.label}
                    </span>
                    {activeBasemapId === bm.id && (
                      <span className="ml-auto text-[8px] font-mono text-emerald-400">●</span>
                    )}
                  </div>
                  <div className="text-[9px] text-slate-600 mt-0.5 pl-3.5 font-mono">{bm.source}</div>
                </button>
              ))}

              {/* Info card for active basemap */}
              <div className="mt-1 pt-1.5 border-t border-white/5">
                <div className="text-[9px] text-slate-500 leading-relaxed">{activeBasemap.description}</div>
                <div className="mt-1 text-[8px] font-mono text-slate-700 truncate">{activeBasemap.attribution}</div>
              </div>
            </div>
          )}
        </div>

        {/* Grid controls */}

        <div className="glass-panel p-2">
          <button className="flex items-center justify-between w-full" onClick={() => setShowGridPanel(v => !v)}>
            <div className="flex items-center gap-1.5">
              <Grid3x3 size={10} className={showGrid ? 'text-cyan-400' : 'text-slate-600'}/>
              <span className="text-[9px] text-slate-500 uppercase tracking-widest font-mono">Coord Grid</span>
            </div>
            {showGridPanel ? <ChevronUp size={10} className="text-slate-600"/> : <ChevronDown size={10} className="text-slate-600"/>}
          </button>
          {showGridPanel && (
            <div className="mt-2 space-y-2">
              <label className="flex items-center justify-between text-xs">
                <span className="text-slate-400">Show grid</span>
                <div className={`w-8 h-4 rounded-full relative cursor-pointer transition-colors ${showGrid ? 'bg-cyan-500/40' : 'bg-white/10'}`}
                  onClick={() => setShowGrid(v => !v)}>
                  <div className={`absolute top-0.5 w-3 h-3 rounded-full bg-white transition-all ${showGrid ? 'left-4' : 'left-0.5'}`}/>
                </div>
              </label>
              {showGrid && (
                <>
                  <div className="space-y-0.5">
                    <div className="flex justify-between text-[9px] text-slate-600"><span>Interval</span><span className="font-mono text-slate-400">{gridInterval}°</span></div>
                    <input type="range" min={1} max={20} step={1} value={gridInterval}
                      onChange={e => setGridInterval(+e.target.value)}
                      className="w-full h-1 accent-cyan-500"/>
                    <div className="flex justify-between text-[9px] text-slate-700">
                      {[1,2,5,10,15,20].map(v => (
                        <button key={v} onClick={() => setGridInterval(v)}
                          className={`px-1 rounded ${gridInterval===v?'text-cyan-400':'text-slate-600 hover:text-slate-400'}`}>{v}°</button>
                      ))}
                    </div>
                  </div>
                  <div className="space-y-0.5">
                    <div className="flex justify-between text-[9px] text-slate-600"><span>Opacity</span><span className="font-mono text-slate-400">{(gridOpacity*100).toFixed(0)}%</span></div>
                    <input type="range" min={0.1} max={1} step={0.05} value={gridOpacity}
                      onChange={e => setGridOpacity(+e.target.value)}
                      className="w-full h-1 accent-cyan-500"/>
                  </div>
                </>
              )}
            </div>
          )}
        </div>

        {/* Layers */}
        <div className="glass-panel p-2">
          <button className="flex items-center justify-between w-full" onClick={() => setShowLayers(v => !v)}>
            <span className="text-[9px] text-slate-500 uppercase tracking-widest font-mono">Layers</span>
            {showLayers ? <ChevronUp size={10} className="text-slate-600"/> : <ChevronDown size={10} className="text-slate-600"/>}
          </button>
          {showLayers && (
            <div className="space-y-2 mt-2">
              {layers.map(layer => (
                <div key={layer.id} className="space-y-0.5">
                  <div className="flex items-center gap-1.5">
                    <button onClick={() => setLayerVisible(layer.id, !layer.visible)}
                      className={layer.visible ? 'text-orange-400' : 'text-slate-600'}>
                      {layer.visible ? <Eye size={11}/> : <EyeOff size={11}/>}
                    </button>
                    <span className="text-[11px] text-slate-300 flex-1 truncate cursor-pointer"
                      onClick={() => setLayerVisible(layer.id, !layer.visible)}>{layer.name}</span>
                    <DataBadge classification={layer.classification}/>
                  </div>
                  {layer.visible && (
                    <input type="range" min={0} max={1} step={0.05} value={layer.opacity}
                      onChange={e => setLayerOpacity(layer.id, parseFloat(e.target.value))}
                      className="w-full h-0.5 accent-orange-500"/>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Legend */}
        <div className="glass-panel p-2">
          <button className="flex items-center justify-between w-full" onClick={() => setShowLegend(v => !v)}>
            <span className="text-[9px] text-slate-500 uppercase tracking-widest font-mono">Legend</span>
            {showLegend ? <ChevronUp size={10} className="text-slate-600"/> : <ChevronDown size={10} className="text-slate-600"/>}
          </button>
          {showLegend && (
            <div className="mt-2 space-y-1">
              {/* Origin */}
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full flex-shrink-0 border-2 border-emerald-400" style={{background:'rgba(52,211,153,0.2)'}}/>
                <span className="text-[11px] text-slate-400">Origin (crosshair)</span>
              </div>
              {/* Hazards */}
              <div className="text-[9px] text-slate-600 uppercase mt-1">Hazards</div>
              {Object.entries(HAZARD_COLORS).filter(([k])=>k!=='none').map(([sev,col])=>(
                <div key={sev} className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{background:col}}/>
                  <span className="text-[11px] text-slate-400 capitalize">{sev}</span>
                </div>
              ))}
              {/* Science */}
              <div className="text-[9px] text-slate-600 uppercase mt-1">Science Targets</div>
              {Object.entries(SCIENCE_CAT_COLORS).map(([cat,col])=>(
                <div key={cat} className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded flex-shrink-0" style={{background:col}}/>
                  <span className="text-[11px] text-slate-400 capitalize">{cat}</span>
                </div>
              ))}
              <div className="flex items-center gap-2 mt-1">
                <span className="w-2.5 h-2.5 rounded-full flex-shrink-0 border border-dashed border-yellow-400"/>
                <span className="text-[11px] text-slate-400">Candidate site</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full flex-shrink-0 bg-cyan-400"/>
                <span className="text-[11px] text-slate-400">Measure point</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded flex-shrink-0 bg-orange-400"/>
                <span className="text-[11px] text-slate-400">Waypoint</span>
              </div>
              {/* Grid lines */}
              <div className="text-[9px] text-slate-600 uppercase mt-1">Grid Lines</div>
              <div className="flex items-center gap-2">
                <span className="w-5 h-0.5 flex-shrink-0" style={{background:'rgba(100,148,212,0.6)'}}/>
                <span className="text-[11px] text-slate-400">Parallels (lat)</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-5 h-0 border-t border-dashed flex-shrink-0" style={{borderColor:'rgba(100,148,212,0.4)'}}/>
                <span className="text-[11px] text-slate-400">Meridians (lon)</span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* ── MAP ──────────────────────────────────────────────────────────── */}
      <div className="flex-1 relative overflow-hidden w-full h-full min-h-0 min-w-0">

        {/* Top bar */}
        <div className="absolute top-2 left-1/2 -translate-x-1/2 z-[1000] glass-panel px-3 py-1 text-[9px] font-mono text-slate-400 whitespace-nowrap pointer-events-none flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ background: activeBasemap.color }}/>
          <span>{activeBasemap.source}</span>
          <span className="text-slate-700">·</span>
          <span>CRS: Planetocentric</span>
          <span className="text-slate-700">·</span>
          <span>Overlays: <span className="text-orange-400">SIMULATED</span></span>
        </div>

        {/* Mode badge */}
        <div className={`absolute top-2 left-2 z-[1000] flex items-center gap-1.5 px-2 py-1 rounded text-[10px] font-mono font-semibold border ${
          mode==='inspect' ? 'bg-blue-500/10 border-blue-500/20 text-blue-300' :
          mode==='measure' ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-300' :
          'bg-orange-500/10 border-orange-500/20 text-orange-300'
        }`}>
          {mode==='inspect' && <><Info size={11}/> INSPECT</>}
          {mode==='measure' && <><Ruler size={11}/> MEASURE — click to add points</>}
          {mode==='waypoint' && <><Route size={11}/> ROUTE — click to place pins</>}
        </div>

        {/* ── CURSOR / COORDINATE HUD ──────────────────────────────────── */}
        <div className="absolute bottom-8 right-2 z-[1000] glass-panel px-3 py-2 border border-white/10 min-w-44">
          <div className="text-[9px] text-slate-600 uppercase tracking-widest mb-1 font-mono">Cursor Position</div>
          {cursor ? (
            <>
              <div className="text-cyan-300 font-mono text-xs font-semibold">{fmtCoord(cursor.lat, true)}</div>
              <div className="text-cyan-300 font-mono text-xs font-semibold">{fmtCoord(cursor.lon, false)}</div>
              {coordFormat === 'dms' && (
                <>
                  <div className="text-cyan-200/60 font-mono text-[9px] mt-0.5">{fmtDMS(cursor.lat, true)}</div>
                  <div className="text-cyan-200/60 font-mono text-[9px]">{fmtDMS(cursor.lon, false)}</div>
                </>
              )}
              {originToCursor !== null && (
                <div className="text-amber-300 font-mono text-[10px] border-t border-white/10 mt-1 pt-1">
                  Δ {originToCursor.toFixed(3)} km from origin
                </div>
              )}
              <button onClick={() => copyCoords(cursor.lat, cursor.lon)}
                className="flex items-center gap-1 text-[9px] text-slate-600 hover:text-slate-300 mt-1 transition-colors">
                {copied ? <Check size={9} className="text-emerald-400"/> : <Copy size={9}/>}
                {copied ? 'Copied!' : 'Copy coords'}
              </button>
            </>
          ) : (
            <div className="text-slate-600 text-xs">Move cursor over map</div>
          )}
        </div>

        {/* ── ORIGIN INFO PANEL ───────────────────────────────────────── */}
        {origin && (
          <div className="absolute bottom-8 left-2 z-[1000] glass-panel px-3 py-2 border border-emerald-500/30 min-w-44">
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-1.5 text-emerald-400">
                <Crosshair size={11}/>
                <span className="text-[9px] font-mono uppercase tracking-widest font-semibold">Origin Point</span>
              </div>
              <button onClick={() => setOrigin(null)} className="text-slate-600 hover:text-red-400 transition-colors"><X size={11}/></button>
            </div>
            <div className="text-emerald-300 font-mono text-xs font-semibold">{fmtCoord(origin.lat, true)}</div>
            <div className="text-emerald-300 font-mono text-xs font-semibold">{fmtCoord(origin.lon, false)}</div>
            <div className="text-emerald-200/50 font-mono text-[9px] mt-0.5">{fmtDMS(origin.lat, true)}</div>
            <div className="text-emerald-200/50 font-mono text-[9px]">{fmtDMS(origin.lon, false)}</div>
            {originToCursor !== null && (
              <div className="text-amber-300 font-mono text-[10px] border-t border-white/10 mt-1 pt-1">
                → cursor: {originToCursor.toFixed(3)} km
              </div>
            )}
          </div>
        )}

        {/* ── MEASURE PANEL ───────────────────────────────────────────── */}
        {mode === 'measure' && measurePoints.length > 0 && (
          <div className="absolute top-10 right-2 z-[1000] glass-panel p-2.5 w-56 border border-emerald-500/20">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-1.5 text-emerald-400">
                <Ruler size={11}/><span className="text-[9px] font-mono uppercase font-semibold">Measurement</span>
              </div>
              <button onClick={() => setMeasurePoints([])} className="text-slate-600 hover:text-red-400"><Trash2 size={11}/></button>
            </div>
            <div className="space-y-1 max-h-36 overflow-y-auto">
              {measurePoints.map((pt, i) => (
                <div key={i} className="flex items-center gap-1.5 text-[10px] font-mono">
                  <span className="w-4 h-4 rounded-full bg-cyan-500/20 border border-cyan-500/50 flex items-center justify-center text-cyan-400 text-[8px] font-bold flex-shrink-0">{i+1}</span>
                  <div className="flex-1">
                    <div className="text-slate-300">{fmtCoord(pt.lat, true)}</div>
                    <div className="text-slate-500">{fmtCoord(pt.lon, false)}</div>
                  </div>
                </div>
              ))}
            </div>
            {measurePoints.length >= 2 && (
              <div className="border-t border-white/10 mt-2 pt-1.5 space-y-0.5">
                {measurePoints.map((pt, i) => {
                  if (i === 0) return null;
                  return (
                    <div key={i} className="flex justify-between text-[10px] font-mono">
                      <span className="text-slate-500">Seg {i}→{i+1}</span>
                      <span className="text-slate-300">{marsDistance(measurePoints[i-1], pt).toFixed(3)} km</span>
                    </div>
                  );
                })}
                <div className="flex justify-between text-[10px] font-mono font-bold border-t border-white/10 pt-0.5">
                  <span className="text-slate-400">Total</span>
                  <span className="text-emerald-300">{measureTotal.toFixed(3)} km</span>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ── WAYPOINT PANEL ──────────────────────────────────────────── */}
        {mode === 'waypoint' && (
          <div className="absolute top-10 right-2 z-[1000] glass-panel p-2.5 w-60 border border-orange-500/20">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-1.5 text-orange-400">
                <Route size={11}/><span className="text-[9px] font-mono uppercase font-semibold">Waypoints & Path</span>
              </div>
              <button onClick={() => setWaypoints([])} className="text-slate-600 hover:text-red-400"><Trash2 size={11}/></button>
            </div>
            {waypoints.length === 0 ? (
              <div className="text-[10px] text-slate-600">Click the map to place waypoints…</div>
            ) : (
              <div className="space-y-1.5 max-h-52 overflow-y-auto">
                {waypoints.map((wp, i) => {
                  const dPrev = i > 0 ? marsDistance({lat:waypoints[i-1].lat,lon:waypoints[i-1].lon},{lat:wp.lat,lon:wp.lon}) : null;
                  const dOrigin = origin ? marsDistance(origin, {lat:wp.lat,lon:wp.lon}) : null;
                  return (
                    <div key={wp.id} className="group border border-white/5 rounded p-1.5 hover:border-white/10 transition-colors">
                      <div className="flex items-center gap-1.5 text-[10px] font-mono">
                        <span className="w-5 h-5 rounded-full flex items-center justify-center text-white font-bold text-[9px] flex-shrink-0" style={{background:wp.color}}>{wp.label}</span>
                        <div className="flex-1 min-w-0">
                          <div className="text-slate-200 text-[10px]">{fmtCoord(wp.lat, true)}</div>
                          <div className="text-slate-500 text-[9px]">{fmtCoord(wp.lon, false)}</div>
                          {dPrev !== null && <div className="text-cyan-400 text-[9px]">↑ {dPrev.toFixed(2)} km from {waypoints[i-1].label}</div>}
                          {dOrigin !== null && <div className="text-amber-400 text-[9px]">○ {dOrigin.toFixed(2)} km from origin</div>}
                          {wp.note && <div className="text-slate-500 text-[9px] italic truncate">{wp.note}</div>}
                        </div>
                        <button onClick={() => setWaypoints(p => p.filter(w => w.id !== wp.id))}
                          className="opacity-0 group-hover:opacity-100 text-slate-600 hover:text-red-400 flex-shrink-0 transition-all">
                          <Trash2 size={10}/>
                        </button>
                      </div>
                      {editingWpId === wp.id ? (
                        <div className="flex gap-1 mt-1">
                          <input value={editNote} onChange={e => setEditNote(e.target.value)} placeholder="Note…"
                            className="flex-1 bg-white/5 border border-white/10 rounded px-1.5 py-0.5 text-[10px] font-mono text-slate-200 focus:outline-none focus:border-orange-500/40"
                            onKeyDown={e => {
                              if (e.key === 'Enter') { setWaypoints(p => p.map(w => w.id===wp.id?{...w,note:editNote}:w)); setEditingWpId(null); }
                              if (e.key === 'Escape') setEditingWpId(null);
                            }} autoFocus/>
                          <button onClick={() => { setWaypoints(p=>p.map(w=>w.id===wp.id?{...w,note:editNote}:w)); setEditingWpId(null); }} className="text-emerald-400 text-[10px]">✓</button>
                        </div>
                      ) : (
                        <button onClick={() => {setEditingWpId(wp.id);setEditNote(wp.note||'');}}
                          className="text-[9px] text-slate-700 hover:text-slate-500 ml-6 mt-0.5 transition-colors">+ note</button>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
            {waypoints.length >= 2 && (
              <div className="border-t border-white/10 mt-2 pt-1.5 space-y-0.5 text-[10px] font-mono">
                <div className="flex justify-between"><span className="text-slate-500">Segments</span><span className="text-slate-400">{waypoints.length-1}</span></div>
                <div className="flex justify-between font-bold">
                  <span className="text-slate-400">Total path</span>
                  <span className="text-orange-300">{waypointTotal.toFixed(3)} km</span>
                </div>
              </div>
            )}
            {waypoints.length > 0 && (
              <button onClick={() => {
                const csv = ['Label,Lat,Lon,Note',...waypoints.map(w=>`${w.label},${w.lat},${w.lon},"${w.note||''}"`)].join('\n');
                const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([csv],{type:'text/csv'})); a.download='mars_waypoints.csv'; a.click();
              }} className="w-full mt-2 py-1 rounded text-[10px] border border-white/10 text-slate-500 hover:text-slate-300 hover:border-orange-500/30 transition-colors">
                ↓ Export CSV
              </button>
            )}
          </div>
        )}

        {/* Feature detail panel */}
        <FeatureDetailPanel feature={selectedFeature} onClose={() => setSelectedFeature(null)}/>

        {/* ── LEAFLET MAP ─────────────────────────────────────────────── */}
        <MapContainer
          center={[mapCenter.lat, mapCenter.lon]}
          zoom={mapZoom}
          crs={L.CRS.EPSG4326}
          minZoom={1}
          maxZoom={12}
          maxBounds={[[-90, -180], [90, 180]]}
          maxBoundsViscosity={1.0}
          style={{ height: '100%', width: '100%', background: theme === 'bright' ? '#e2e8f0' : '#0d1421' }}
          zoomControl={false}
        >
          <ZoomControl position="bottomright"/>
          <ScaleControl position="bottomleft"/>
          <AutoResizeMap/>
          <MapController flyTo={flyTo}/>
          <MapEventHandler mode={mode} onCursor={(lat,lon)=>setCursor({lat,lon})} onMapClick={handleMapClick}/>

          {/* Mars basemap — switches between real NASA imagery sources */}
          {activeBasemap.type === 'tile' ? (
            <TileLayer
              key={activeBasemap.id}
              url={activeBasemap.url}
              attribution={activeBasemap.attribution}
              minNativeZoom={0}
              maxNativeZoom={activeBasemap.maxNativeZoom ?? 7}
              maxZoom={12}
              tileSize={256}
              noWrap={true}
              keepBuffer={4}
              updateWhenZooming={false}
              updateWhenIdle={false}
            />
          ) : (
            <WMSTileLayer
              key={activeBasemap.id}
              url={activeBasemap.url}
              layers={activeBasemap.layer ?? ''}
              format="image/png"
              transparent={false}
              attribution={activeBasemap.attribution}
              minNativeZoom={1}
              maxNativeZoom={activeBasemap.maxNativeZoom ?? 12}
              maxZoom={12}
              version="1.1.1"
              tileSize={256}
              noWrap={true}
              uppercase={false}
              keepBuffer={4}
              updateWhenZooming={false}
              updateWhenIdle={false}
              updateInterval={150}
            />
          )}

          {/* Coordinate grid */}
          {showGrid && <GraticuleGrid interval={gridInterval} opacity={gridOpacity}/>}
          {showGrid && <GraticuleLabels interval={gridInterval} opacity={gridOpacity}/>}

          {/* Origin crosshair marker */}
          {origin && (
            <>
              {/* Radiating rings */}
              <CircleMarker center={[origin.lat, origin.lon]} radius={24}
                pathOptions={{ color:'#34d399', fillColor:'transparent', weight:1, opacity:0.2, dashArray:'4,3' }}/>
              <CircleMarker center={[origin.lat, origin.lon]} radius={16}
                pathOptions={{ color:'#34d399', fillColor:'transparent', weight:1, opacity:0.35, dashArray:'3,4' }}/>
              {/* Crosshair lines — horizontal */}
              <Polyline positions={[[origin.lat, origin.lon - 2],[origin.lat, origin.lon + 2]]}
                pathOptions={{ color:'#34d399', weight:1, opacity:0.6, dashArray:'2,3' }}/>
              <Polyline positions={[[origin.lat - 1, origin.lon],[origin.lat + 1, origin.lon]]}
                pathOptions={{ color:'#34d399', weight:1, opacity:0.6, dashArray:'2,3' }}/>
              {/* Center dot */}
              <Marker position={[origin.lat, origin.lon]} icon={makeOriginIcon()}>
                <Popup>
                  <div className="text-xs space-y-1.5" style={{minWidth:210}}>
                    <div className="font-semibold text-emerald-400 flex items-center gap-1">
                      <Crosshair size={12}/> Origin Point
                    </div>
                    <div className="space-y-0.5 text-[11px] font-mono">
                      <div className="text-slate-300">{fmtDMS(origin.lat, true)}</div>
                      <div className="text-slate-300">{fmtDMS(origin.lon, false)}</div>
                      <div className="text-slate-500">{origin.lat.toFixed(6)}°, {origin.lon.toFixed(6)}°</div>
                    </div>
                    <button onClick={() => setOrigin(null)} className="text-[10px] text-red-400 hover:underline">Remove origin</button>
                  </div>
                </Popup>
              </Marker>
              {/* Distance line to cursor */}
              {cursor && (
                <Polyline
                  positions={[[origin.lat, origin.lon],[cursor.lat, cursor.lon]]}
                  pathOptions={{ color:'#34d399', weight:1.5, opacity:0.5, dashArray:'4,4' }}
                />
              )}
            </>
          )}

          {/* Measure points */}
          {measurePoints.map((pt, i) => (
            <Marker key={i} position={[pt.lat, pt.lon]} icon={makeMeasureIcon(i+1)}>
              <Popup>
                <div className="text-xs space-y-1">
                  <div className="font-semibold text-cyan-400">Measure Point {i+1}</div>
                  <div className="font-mono text-[10px]">{fmtDMS(pt.lat, true)}</div>
                  <div className="font-mono text-[10px]">{fmtDMS(pt.lon, false)}</div>
                  {i > 0 && <div className="text-emerald-400 text-[10px]">+{marsDistance(measurePoints[i-1],pt).toFixed(3)} km from prev</div>}
                  <button onClick={() => setMeasurePoints(p => p.filter((_,j) => j !== i))} className="text-[10px] text-red-400 hover:underline">Remove</button>
                </div>
              </Popup>
            </Marker>
          ))}
          {/* Measure polyline */}
          {measurePoints.length >= 2 && (
            <Polyline
              positions={measurePoints.map(p => [p.lat, p.lon] as [number,number])}
              pathOptions={{ color:'#22d3ee', weight:2.5, opacity:0.85, dashArray:'6,4' }}
            />
          )}

          {/* Waypoints */}
          {waypoints.map((wp, i) => (
            <React.Fragment key={wp.id}>
              <Marker position={[wp.lat, wp.lon]} icon={makeWaypointIcon(wp.color, wp.label)}>
                <Popup>
                  <div className="text-xs space-y-1" style={{minWidth:200}}>
                    <div className="font-semibold" style={{color:wp.color}}>Waypoint {wp.label}</div>
                    <div className="font-mono text-[10px]">{fmtDMS(wp.lat, true)}</div>
                    <div className="font-mono text-[10px]">{fmtDMS(wp.lon, false)}</div>
                    {wp.note && <div className="text-slate-400 italic">{wp.note}</div>}
                    {i > 0 && <div className="text-cyan-400 text-[10px]">↑ {marsDistance({lat:waypoints[i-1].lat,lon:waypoints[i-1].lon},{lat:wp.lat,lon:wp.lon}).toFixed(3)} km from {waypoints[i-1].label}</div>}
                    {origin && <div className="text-amber-400 text-[10px]">○ {marsDistance(origin,{lat:wp.lat,lon:wp.lon}).toFixed(3)} km from origin</div>}
                    <div className="flex gap-2 pt-1 border-t border-white/10">
                      <button onClick={() => setOrigin({lat:wp.lat,lon:wp.lon})} className="text-[10px] text-emerald-400 hover:underline">Set as Origin</button>
                      <button onClick={() => copyCoords(wp.lat, wp.lon)} className="text-[10px] text-cyan-400 hover:underline">Copy</button>
                      <button onClick={() => setWaypoints(p => p.filter(w => w.id !== wp.id))} className="text-[10px] text-red-400 hover:underline">Remove</button>
                    </div>
                  </div>
                </Popup>
              </Marker>
              {/* Dashed distance line from origin */}
              {origin && (
                <Polyline positions={[[origin.lat,origin.lon],[wp.lat,wp.lon]]}
                  pathOptions={{color:'#fbbf24',weight:1,opacity:0.25,dashArray:'2,5'}}/>
              )}
            </React.Fragment>
          ))}
          {/* Waypoint route polyline */}
          {waypoints.length >= 2 && (
            <Polyline
              positions={waypoints.map(w => [w.lat,w.lon] as [number,number])}
              pathOptions={{ color:'#f46040', weight:3, opacity:0.85 }}
            />
          )}

          {/* Hazard markers */}
          {hazardLayer?.visible && HAZARDS.map(hz => (
            <CircleMarker key={hz.id}
              center={[hz.coordinates.lat, hz.coordinates.lon]}
              radius={Math.max(8, (hz.radius||100)/400)}
              pathOptions={{
                color: HAZARD_COLORS[hz.severity], fillColor: HAZARD_COLORS[hz.severity],
                fillOpacity: 0.2 * hazardLayer.opacity, weight:2, opacity:hazardLayer.opacity,
              }}
              eventHandlers={{ click: () => setSelectedFeature({type:'hazard', data:hz}) }}
            >
              <Popup>
                <div className="text-xs space-y-1" style={{minWidth:200}}>
                  <div className="font-semibold text-orange-400 capitalize">{hz.type?.replace(/-/g,' ')}</div>
                  <div className="font-mono text-[10px]">{fmtDMS(hz.coordinates.lat, true)}</div>
                  <div className="font-mono text-[10px]">{fmtDMS(hz.coordinates.lon, false)}</div>
                  <div><span className="text-slate-400">Severity:</span> <span className="capitalize" style={{color:HAZARD_COLORS[hz.severity]}}>{hz.severity}</span></div>
                  <div><span className="text-slate-400">Radius:</span> {hz.radius??'?'} m · Conf: {(hz.confidence*100).toFixed(0)}%</div>
                  <div className="text-slate-300 text-[11px]">{hz.description}</div>
                  <div className="flex gap-2 pt-1 border-t border-white/10">
                    <button onClick={()=>setOrigin({lat:hz.coordinates.lat,lon:hz.coordinates.lon})} className="text-[10px] text-emerald-400 hover:underline">Set Origin</button>
                    <button onClick={()=>copyCoords(hz.coordinates.lat,hz.coordinates.lon)} className="text-[10px] text-cyan-400 hover:underline">Copy</button>
                  </div>
                </div>
              </Popup>
            </CircleMarker>
          ))}

          {/* Science targets */}
          {scienceLayer?.visible && SCIENCE_TARGETS.map(st => (
            <CircleMarker key={st.id}
              center={[st.coordinates.lat, st.coordinates.lon]}
              radius={10}
              pathOptions={{
                color: SCIENCE_CAT_COLORS[st.category]||'#fff',
                fillColor: SCIENCE_CAT_COLORS[st.category]||'#fff',
                fillOpacity: 0.45 * scienceLayer.opacity, weight:2, opacity:scienceLayer.opacity,
              }}
              eventHandlers={{ click: () => { setSelectedTarget(st.id); setSelectedFeature({type:'science',data:st}); } }}
            >
              <Popup>
                <div className="text-xs space-y-1" style={{minWidth:210}}>
                  <div className="font-semibold" style={{color:SCIENCE_CAT_COLORS[st.category]}}>{st.name}</div>
                  <div className="font-mono text-[10px]">{fmtDMS(st.coordinates.lat, true)}</div>
                  <div className="font-mono text-[10px]">{fmtDMS(st.coordinates.lon, false)}</div>
                  <div className="capitalize text-slate-400">{st.category} · {'★'.repeat(st.priority)}{'☆'.repeat(5-st.priority)}</div>
                  <div className="text-slate-300 text-[11px]">{st.rationale.slice(0,120)}…</div>
                  <div className="flex gap-2 pt-1 border-t border-white/10">
                    <button onClick={()=>setOrigin({lat:st.coordinates.lat,lon:st.coordinates.lon})} className="text-[10px] text-emerald-400 hover:underline">Set Origin</button>
                    <button onClick={()=>copyCoords(st.coordinates.lat,st.coordinates.lon)} className="text-[10px] text-cyan-400 hover:underline">Copy</button>
                  </div>
                </div>
              </Popup>
            </CircleMarker>
          ))}

          {/* Candidate sites */}
          {CANDIDATE_SITES.map(site => (
            <CircleMarker key={site.id}
              center={[site.coordinates.lat, site.coordinates.lon]}
              radius={14}
              pathOptions={{ color:'#fbbf24', fillColor:'#fbbf24', fillOpacity:0.1, weight:2, dashArray:'5,4' }}
              eventHandlers={{ click: () => setSelectedFeature({type:'site', data:site}) }}
            >
              <Popup>
                <div className="text-xs space-y-1" style={{minWidth:200}}>
                  <div className="font-semibold text-yellow-400">⭐ {site.name}</div>
                  <div className="font-mono text-[10px]">{fmtDMS(site.coordinates.lat, true)}</div>
                  <div className="font-mono text-[10px]">{fmtDMS(site.coordinates.lon, false)}</div>
                  {site.landingSuitability && <div>Landing: <span className="text-white font-mono">{site.landingSuitability.overall}/100</span></div>}
                  {site.ascentSuitability && <div>Ascent: <span className="text-white font-mono">{site.ascentSuitability.overall}/100</span></div>}
                  <div className="flex gap-2 pt-1 border-t border-white/10">
                    <button onClick={()=>setOrigin({lat:site.coordinates.lat,lon:site.coordinates.lon})} className="text-[10px] text-emerald-400 hover:underline">Set Origin</button>
                    <button onClick={()=>copyCoords(site.coordinates.lat,site.coordinates.lon)} className="text-[10px] text-cyan-400 hover:underline">Copy</button>
                  </div>
                </div>
              </Popup>
            </CircleMarker>
          ))}
        </MapContainer>
      </div>
    </div>
  );
}
