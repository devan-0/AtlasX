import { describe, it, expect } from 'vitest';
import { useAppStore } from '../store/useAppStore';
import { HAZARDS, SCIENCE_TARGETS, CANDIDATE_SITES } from '../data/sampleData';

describe('AtlasX & Navigation Tests', () => {
  it('store navigation to atlas should update activePage', () => {
    const store = useAppStore.getState();
    expect(store.activePage).toBeDefined();

    store.setActivePage('atlas');
    expect(useAppStore.getState().activePage).toBe('atlas');

    store.setActivePage('overview');
    expect(useAppStore.getState().activePage).toBe('overview');
  });

  it('study regions have valid bounds and coordinates', () => {
    const { regions } = useAppStore.getState();
    expect(regions.length).toBeGreaterThan(0);
    for (const r of regions) {
      expect(r.coordinates.lat).toBeGreaterThanOrEqual(-90);
      expect(r.coordinates.lat).toBeLessThanOrEqual(90);
      expect(r.boundingBox.north).toBeGreaterThan(r.boundingBox.south);
    }
  });

  it('hazards and science targets have valid Martian coordinates', () => {
    for (const h of HAZARDS) {
      expect(h.coordinates.lat).toBeGreaterThanOrEqual(-90);
      expect(h.coordinates.lat).toBeLessThanOrEqual(90);
      expect(h.coordinates.lon).toBeGreaterThanOrEqual(-180);
      expect(h.coordinates.lon).toBeLessThanOrEqual(360);
    }
    for (const s of SCIENCE_TARGETS) {
      expect(s.coordinates.lat).toBeGreaterThanOrEqual(-90);
      expect(s.coordinates.lat).toBeLessThanOrEqual(90);
    }
    for (const c of CANDIDATE_SITES) {
      expect(c.coordinates.lat).toBeGreaterThanOrEqual(-90);
      expect(c.coordinates.lat).toBeLessThanOrEqual(90);
    }
  });

  it('graticule latitude bounds are bounded to avoid Mercator singularities', () => {
    const intervals = [1, 2, 5, 10, 15, 20];
    for (const interval of intervals) {
      const s = Math.max(-85, Math.floor(-90 / interval) * interval);
      const n = Math.min(85, Math.ceil(90 / interval) * interval);
      expect(s).toBeGreaterThanOrEqual(-85);
      expect(n).toBeLessThanOrEqual(85);
    }
  });

  it('dynamic app intro state defaults to true on launch and responds to setShowIntro', () => {
    const store = useAppStore.getState();
    expect(typeof store.showIntro).toBe('boolean');

    store.setShowIntro(false);
    expect(useAppStore.getState().showIntro).toBe(false);

    store.setShowIntro(true);
    expect(useAppStore.getState().showIntro).toBe(true);
  });

  it('supports dark and bright themes with setTheme and toggleTheme', () => {
    const store = useAppStore.getState();
    expect(['dark', 'bright']).toContain(store.theme);

    store.setTheme('bright');
    expect(useAppStore.getState().theme).toBe('bright');

    store.toggleTheme();
    expect(useAppStore.getState().theme).toBe('dark');

    store.toggleTheme();
    expect(useAppStore.getState().theme).toBe('bright');

    store.setTheme('dark');
    expect(useAppStore.getState().theme).toBe('dark');
  });

  it('verifies AtlasX project identity and compliance disclaimer constants', () => {
    const requiredDescription = 'AtlasX – An Advanced Planetary Exploration, Surface Intelligence and Mission Planning Platform.';
    const requiredDisclaimer = 'AtlasX is an independent educational and research project. It is not affiliated with, endorsed by, or officially associated with NASA or any other space agency.';

    expect(requiredDescription).toContain('AtlasX');
    expect(requiredDisclaimer).toContain('not affiliated with, endorsed by, or officially associated with NASA');
  });
});
