# AtlasX

**AtlasX – An Advanced Planetary Exploration, Surface Intelligence and Mission Planning Platform.**

![AtlasX](public/mars-icon.svg)

## ⚠ Compliance & Research Disclaimer

> **Affiliation Notice:**  
> AtlasX is an independent educational and research project. It is not affiliated with, endorsed by, or officially associated with NASA or any other space agency.

This application is a **demonstration and research platform** for educational and scientific analysis purposes. Data marked **SIMULATED** is synthetic. Data marked **OBSERVED** or **DERIVED** is sourced from open planetary science pipelines (including USGS Astrogeology, NASA Mars Trek, JPL Horizons, and PDS archives) but has not been validated for operational flight planning. No routes, suitability scores, or biometric models produced by this tool have been certified for human spaceflight operations.

---

## Features

| Feature | Status | Data Source |
|---------|--------|-------------|
| Mission Overview Dashboard | ✅ Complete | Mixed |
| Interactive 2D Mars Atlas | ✅ Complete | OPM Basemap (real) + Overlays (simulated) |
| 3D Terrain Explorer | ✅ Complete | Simulated procedural terrain |
| Marswalk Route Planner (A\*) | ✅ Complete | Simulated terrain grid |
| Science Targets Explorer | ✅ Complete | Simulated (literature-based) |
| Minerals & Geology | ✅ Complete | Simulated CRISM categories |
| **Solar Energy Analysis** | ✅ **Live** | **Real JPL Horizons DE441 orbital data** |
| **Atmosphere & Wind** | ✅ **Live** | **Real NASA InSight APSS measurements** |
| Landing/Ascent Suitability | ✅ Complete | Simulated scores |
| Site Comparison | ✅ Complete | Simulated |
| Data Catalogue | ✅ Complete | Real dataset metadata |
| Saved Missions & Export | ✅ Complete | Local storage + JSON/CSV |
| Settings & About | ✅ Complete | — |

### Real-time Data Sources (when backend is running)
| Data | Source | Classification |
|------|--------|---------------|
| Mars solar longitude (Ls) | JPL Horizons DE441 | OBSERVED |
| Mars–Sun distance | JPL Horizons DE441 | OBSERVED |
| Solar irradiance (TOA) | Derived from Horizons | DERIVED |
| Mars season | Derived from Ls | DERIVED |
| Surface temperature | NASA InSight APSS, Sol 675–681 | OBSERVED |
| Atmospheric pressure | NASA InSight APSS | OBSERVED |
| Wind speed | NASA InSight APSS (HWS) | OBSERVED |

---

## Quick Start (Windows)

### Prerequisites
- Windows 10/11
- Node.js v20+ ([download](https://nodejs.org/))
- Python 3.10+ (optional, for backend)

### Installation

```powershell
# Clone or extract the project
cd mars-explorer-atlas

# Install dependencies
npm install

# Start development server
npm run dev
```

Open http://localhost:5173 in your browser.

### If you installed the portable Node.js with this project

```powershell
# Use the portable Node.js
$env:PATH = "C:\Users\valiy\tools\node-v20.18.0-win-x64;$env:PATH"
cd "C:\Users\valiy\Documents\programs\antigravity\mars-explorer-atlas"
npm run dev
```

Or use the included startup script:
```powershell
.\start.ps1
```

### Option B — Enable Real-time NASA/JPL Data (Backend)

Run the FastAPI backend in a second terminal to enable live data from JPL Horizons and NASA InSight:

```powershell
# Terminal 2 — start the API backend
cd mars-explorer-atlas
.\start-backend.ps1

# Or manually:
cd backend
python main.py
# Backend starts at http://localhost:8000
```

The frontend auto-detects the backend. The toolbar indicator changes:
- 🟡 **Simulated Data** — backend offline, using synthetic datasets
- 🟢 **Live NASA Data** — backend online, real JPL Horizons + InSight data active

#### Optional: NASA API Key (higher rate limits)

Set `NASA_API_KEY` environment variable before starting the backend:
```powershell
$env:NASA_API_KEY = "your_key_here"  # Get free key at api.nasa.gov
python main.py
```

The DEMO_KEY (default) allows 30 requests/hour, sufficient for normal use.

### Production Build

```powershell
npm run build
# Outputs to dist/ — serve with any static file server
npx serve dist
```

---

## Technology Stack

| Layer | Technology |
|-------|-----------|
| Framework | React 18 + TypeScript |
| Build | Vite 5 |
| Styling | Tailwind CSS 3 |
| State | Zustand 4 (persisted) |
| 2D Maps | Leaflet + react-leaflet |
| 3D Rendering | Three.js + @react-three/fiber |
| Charts | Recharts 2 |
| Icons | lucide-react |
| Data Fetching | @tanstack/react-query |

---

## Project Structure

```
src/
├── App.tsx                    # Root component + navigation
├── main.tsx                   # Entry point
├── index.css                  # Global styles + design system
├── types/index.ts             # TypeScript domain types
├── store/useAppStore.ts       # Zustand state management
├── data/sampleData.ts         # Demonstration datasets (SIMULATED)
├── utils/
│   ├── marsCoordinates.ts     # Mars coordinate utilities
│   ├── solarGeometry.ts       # Solar irradiance calculations
│   ├── routePlanning.ts       # A* pathfinding on terrain grid
│   └── export.ts              # JSON/CSV/report export
├── components/
│   ├── layout/                # Shell: Sidebar, TopToolbar, StatusBar
│   └── ui/                    # DataBadge, GlassPanel, StatCard, etc.
└── pages/
    ├── OverviewPage.tsx       # Mission dashboard
    ├── AtlasPage.tsx          # Interactive 2D map
    ├── Terrain3DPage.tsx      # 3D terrain viewer
    ├── RoutesPage.tsx         # Marswalk route planner
    ├── SciencePage.tsx        # Science targets explorer
    ├── MineralsPage.tsx       # Minerals & geology
    ├── SolarPage.tsx          # Solar energy workspace
    ├── AtmospherePage.tsx     # Atmospheric data viewer
    ├── SuitabilityPage.tsx    # Landing/ascent suitability
    ├── ComparisonPage.tsx     # Site comparison
    ├── CataloguePage.tsx      # Data catalogue
    ├── MissionsPage.tsx       # Saved missions & export
    └── SettingsPage.tsx       # Settings & about
```

---

## 🖥 Windows Desktop Application

AtlasX is packaged as a standalone native Windows desktop application with an embedded Python FastAPI backend. No external browser or development server is required.

### Download & Run

The compiled Windows distributions are located in the `release/` folder:

| Distribution | File | Size | Description |
|--------------|------|------|-------------|
| **Installer** | [`release/AtlasX-Setup.exe`](release/AtlasX-Setup.exe) | ~96 MB | Full NSIS installer with Desktop and Start Menu shortcuts |
| **Portable** | [`release/AtlasX 1.0.0.exe`](release/AtlasX%201.0.0.exe) | ~96 MB | Single-file portable executable; run directly without installation |
| **Unpacked** | [`release/win-unpacked/AtlasX.exe`](release/win-unpacked/AtlasX.exe) | ~178 MB | Pre-extracted application folder ready to launch |

### Native Architecture & Backend Lifecycle

1. **Embedded Backend**: The Python FastAPI service (`mars_backend.exe`) is compiled with PyInstaller and bundled directly into `resources/backend/`.
2. **Automatic Lifecycle**: When `AtlasX.exe` launches, the main process automatically spawns the backend on isolated internal port **8765**, polls `/api/health` for readiness, and binds it to the application window.
3. **Clean Teardown**: When the window is closed, the main process immediately terminates the entire backend process tree to prevent orphan background services.
4. **Offline Resilience**: If network access or the backend is unavailable, the application gracefully falls back to synthetic Mars datasets with clear UI indicators.

### How to Rebuild the Windows Desktop Application

#### One-Click Build Script (PowerShell):
```powershell
.\Build-Desktop.ps1
```

#### Step-by-Step Manual Build:
```powershell
# 1. Ensure portable Node.js and Python are in PATH
$env:PATH = "C:\Users\valiy\tools\node-v20.18.0-win-x64;$env:PATH"

# 2. Compile Python FastAPI backend
cd backend
pyinstaller mars_backend.spec --clean --noconfirm
cd ..

# 3. Build React frontend for Electron
$env:BUILD_TARGET = "electron"
npm run build
node scripts/prepare-electron.mjs

# 4. Package executable and installer
$env:CSC_IDENTITY_AUTO_DISCOVERY = "false"
$env:WIN_CSC_LINK = ""
npm run electron:dist
```

For complete packaging architecture and troubleshooting details, see [DESKTOP_BUILD.md](DESKTOP_BUILD.md).

---


## License

MIT License — see [LICENSE](LICENSE) for details.

Data attribution: NASA/JPL, University of Arizona HiRISE team, APL (CRISM), OpenPlanetary.
