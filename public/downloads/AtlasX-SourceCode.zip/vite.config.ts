import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// When building for Electron, assets must use relative paths (./assets/...)
// so they resolve correctly under file:// in the BrowserWindow.
// The prepare-electron.mjs script also patches index.html as a safety net.
// Always use relative base ('./') so all assets, dynamic chunks, and CSS
// resolve correctly under both file:// (Electron desktop) and web contexts.
export default defineConfig({
  plugins: [react()],
  base: './',
  server: {
    port: 5173,
    host: 'localhost',
  },
  build: {
    target: 'es2020',
    outDir: 'dist',
    sourcemap: true,
    rollupOptions: {
      output: {
        manualChunks: {
          'react-vendor': ['react', 'react-dom', 'react-router-dom'],
          'map-vendor': ['leaflet', 'react-leaflet'],
          'three-vendor': ['three', '@react-three/fiber', '@react-three/drei'],
          'chart-vendor': ['recharts'],
          'store': ['zustand'],
        },
      },
    },
  },
  optimizeDeps: {
    include: ['leaflet', 'react-leaflet', 'three', 'recharts', 'zustand'],
  },
});
