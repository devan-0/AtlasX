import React from 'react';
import { useAppStore } from '../store/useAppStore';
import DataBadge from '../components/ui/DataBadge';
import GlassPanel from '../components/ui/GlassPanel';
import { Layers, Camera, ExternalLink, ArrowRight } from 'lucide-react';

const MINERAL_ZONES = [
  { name: 'Phyllosilicates (Clays)', color: '#7b3f9e', coverage: '~12% of crater floor', confidence: 'Medium', evidence: 'Fe/Mg smectite absorption bands 2.28–2.32 µm (CRISM)', region: { x: 15, y: 55, w: 25, h: 18 } },
  { name: 'Carbonates (Mg-rich)', color: '#1e8bc3', coverage: '~4% of crater floor', confidence: 'Low', evidence: 'Mg-carbonate doublet 2.3–2.5 µm (CRISM)', region: { x: 55, y: 35, w: 18, h: 14 } },
  { name: 'Olivine / Mafic Basalt', color: '#e67e22', coverage: '~35% of crater floor', confidence: 'High', evidence: 'Olivine doublet 1.0/1.85 µm; thermally distinct (TES)', region: { x: 30, y: 60, w: 40, h: 25 } },
  { name: 'Hematite (Fe-oxide)', color: '#e74c3c', coverage: '~3% ridge area', confidence: 'Low', evidence: '0.86 µm shoulder absorption (CRISM)', region: { x: 68, y: 55, w: 12, h: 10 } },
  { name: 'Sulfates (potential)', color: '#27ae60', coverage: 'Not mapped in Jezero', confidence: 'None', evidence: 'Absent in CRISM observations; expected at depth only', region: null },
];

const GEO_ERAS = [
  { name: 'Noachian', age: '4.1–3.7 Ga', color: '#7c3aed', description: 'Heavy bombardment; liquid water; crater formation; clay mineral deposition' },
  { name: 'Hesperian', age: '3.7–3.0 Ga', color: '#c2410c', description: 'Declining water activity; sulfate formation; volcanic outgassing' },
  { name: 'Amazonian', age: '3.0 Ga–present', color: '#0369a1', description: 'Cold, dry conditions; ice deposits; aeolian activity; Jezero infilling' },
];

export default function MineralsPage() {
  const { selectedRegion, setActivePage, theme } = useAppStore();
  const isBright = theme === 'bright';

  return (
    <div className="h-full overflow-y-auto p-4 space-y-4">
      {/* Header */}
      <div className="flex items-start gap-3">
        <GlassPanel className="flex-1 !p-3">
          <div className="text-[10px] text-slate-500 uppercase tracking-wide mb-1">Region</div>
          <div className="text-sm font-semibold text-slate-100">{selectedRegion.name}</div>
          <div className="text-xs text-slate-400 mt-1">{selectedRegion.geologyNote}</div>
        </GlassPanel>
        <DataBadge classification="simulated" className="self-center" />
      </div>

      <div className="p-2.5 rounded bg-orange-500/10 border border-orange-500/20 text-[11px] text-orange-300">
        ⚠ All mineral maps are <strong>SIMULATED</strong>. Real CRISM spectral products require PDS access and ENVI/IDL processing. Spectral categories shown here are based on published Jezero literature but spatial positions are illustrative only.
      </div>

      {/* Mars 2020 Raw Image & Sample Return Outcrop Banner */}
      <div className={`p-3 rounded-lg border flex flex-wrap items-center justify-between gap-3 ${
        isBright ? 'bg-cyan-50 border-cyan-200' : 'bg-cyan-950/40 border-cyan-500/30'
      }`}>
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-cyan-500/20 flex items-center justify-center">
            <Camera className="w-4 h-4 text-cyan-400" />
          </div>
          <div>
            <div className={`text-xs font-bold ${isBright ? 'text-slate-900' : 'text-white'}`}>
              NASA Mars 2020 Raw Feeds &amp; Outcrop Sampling Available
            </div>
            <div className={`text-[11px] ${isBright ? 'text-slate-600' : 'text-slate-400'}`}>
              Inspect high-res Mastcam-Z, SuperCam LIBS spectra, and core/sealed sample tubes for Jezero &amp; Mount Sharp.
            </div>
          </div>
        </div>
        <button
          onClick={() => setActivePage('science')}
          className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold rounded shadow transition-all flex items-center gap-1.5"
        >
          Explore Geological Outcrops <ArrowRight size={13} />
        </button>
      </div>

      {/* Mineral map + legend */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <GlassPanel title="Mineral Distribution Map" badge={<DataBadge classification="simulated" />} noPad>
          <div className="relative bg-[#0d1421] overflow-hidden" style={{ height: 280 }}>
            {/* Crater outline */}
            <svg width="100%" height="100%" viewBox="0 0 100 100" className="absolute inset-0">
              {/* Crater rim */}
              <ellipse cx="50" cy="50" rx="45" ry="42" fill="none" stroke="rgba(255,255,255,0.15)" strokeWidth="0.8" />
              {/* Fill regions */}
              {MINERAL_ZONES.filter(z => z.region).map((z, i) => (
                <rect key={i} x={z.region!.x} y={z.region!.y} width={z.region!.w} height={z.region!.h}
                  fill={z.color} opacity={0.35} rx={2} />
              ))}
              {/* North arrow */}
              <text x="92" y="8" fill="rgba(148,163,184,0.6)" fontSize="4" textAnchor="middle">N</text>
              <line x1="92" y1="9" x2="92" y2="14" stroke="rgba(148,163,184,0.4)" strokeWidth="0.5" />
              {/* Scale */}
              <line x1="5" y1="95" x2="25" y2="95" stroke="rgba(148,163,184,0.4)" strokeWidth="0.5" />
              <text x="15" y="98" fill="rgba(148,163,184,0.5)" fontSize="3" textAnchor="middle">~10 km</text>
              {/* SIMULATED watermark */}
              <text x="50" y="52" fill="rgba(255,100,30,0.08)" fontSize="8" textAnchor="middle" fontWeight="bold" transform="rotate(-15 50 52)">SIMULATED</text>
            </svg>
          </div>
        </GlassPanel>

        <GlassPanel title="Detected Minerals">
          <div className="space-y-3">
            {MINERAL_ZONES.map((z, i) => (
              <div key={i} className="flex items-start gap-2.5">
                <span className="w-3 h-3 rounded flex-shrink-0 mt-0.5" style={{ background: z.color }} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-xs font-medium text-slate-200">{z.name}</span>
                    <span className={`text-[9px] px-1 py-0.5 rounded font-mono ${z.confidence === 'High' ? 'bg-emerald-500/15 text-emerald-400' : z.confidence === 'Medium' ? 'bg-amber-500/15 text-amber-400' : z.confidence === 'Low' ? 'bg-red-500/15 text-red-400' : 'bg-slate-500/15 text-slate-500'}`}>
                      {z.confidence} confidence
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-500 mt-0.5">{z.coverage}</div>
                  <div className="text-[10px] text-slate-400 mt-0.5 italic">{z.evidence}</div>
                </div>
              </div>
            ))}
          </div>
        </GlassPanel>
      </div>

      {/* Geological timeline */}
      <GlassPanel title="Martian Geological Timeline">
        <div className="space-y-2">
          {GEO_ERAS.map(era => (
            <div key={era.name} className="flex items-start gap-3">
              <div className="flex-shrink-0 w-24">
                <div className="text-xs font-semibold" style={{ color: era.color }}>{era.name}</div>
                <div className="text-[10px] text-slate-500 font-mono">{era.age}</div>
              </div>
              <div className="flex-1 pt-0.5">
                <div className="h-1.5 rounded-full mb-1" style={{ background: era.color, opacity: 0.4 }} />
                <div className="text-[11px] text-slate-400">{era.description}</div>
              </div>
            </div>
          ))}
          <div className="text-[10px] text-slate-500 pt-1 border-t border-white/5">
            Jezero Crater formation: Noachian (~3.8 Ga) · Lake phase: ~3.7–3.5 Ga · Current surface: Amazonian
          </div>
        </div>
      </GlassPanel>

      {/* CRISM access info */}
      <GlassPanel title="Real CRISM Data Integration">
        <div className="text-xs text-slate-400 space-y-1">
          <div>Real CRISM mineral maps are available from the NASA PDS Geosciences Node:</div>
          <a href="https://pds-geosciences.wustl.edu/mro/mro-m-crism-5-rdr-v1/" target="_blank" rel="noopener noreferrer" className="text-cyan-400 hover:text-cyan-300 break-all">
            https://pds-geosciences.wustl.edu/mro/mro-m-crism-5-rdr-v1/
          </a>
          <div className="mt-1">Processing pipeline: Download FRT .img files → Apply CRISM Analysis Tool (CAT) atmospheric correction → Compute spectral parameters → Generate GeoTIFF maps.</div>
        </div>
      </GlassPanel>
    </div>
  );
}
