/**
 * AtlasX — Real-Time Astronomical Mars Timing Utilities
 * 
 * Implements the standard NASA GISS Mars24 timing algorithm:
 * Allison, M., and M. McEwen 2000. "A post-Pathfinder evaluation of areocentric solar
 * coordinates with improved timing recipes for Mars seasonal/diurnal climate studies."
 * Planetary and Space Science 48, 215-235.
 * 
 * Provides:
 * - Earth UTC date and time
 * - Julian Date in UT and TT (Terrestrial Time)
 * - Mars Sol Date (MSD)
 * - Coordinated Mars Time (MTC) at the Airy-0 prime meridian
 * - Local Mean Solar Time (LMST) for any Mars longitude
 * - Areocentric Solar Longitude (Ls), Mars Year (MY), season, solar declination,
 *   Mars-Sun distance, and solar irradiance.
 */

import { useState, useEffect } from 'react';

// ── Constants ───────────────────────────────────────────────────────────────

/** Milliseconds in a standard Earth day */
export const MS_PER_DAY = 86400000.0;

/** Ratio of Mars sol length to Earth day length (88775.244147s / 86400s) */
export const MARS_SOL_RATIO = 1.02749125170;

/** Length of one Mars sol in seconds */
export const MARS_SOL_SECONDS = 88775.244147;

/** J2000 epoch as Julian Date (2000-01-01 12:00:00 TT) */
export const J2000_JD = 2451545.0;

/** Offset between Terrestrial Time (TT) and UTC (approx 37 leap seconds + 32.184s) */
export const TT_MINUS_UTC_SECONDS = 69.184;

/** Mars semi-major axis in AU */
export const MARS_SEMI_MAJOR_AU = 1.523662;

/** Mars orbital eccentricity */
export const MARS_ECCENTRICITY = 0.0934123;

/** Solar constant at 1 AU in W/m² */
export const SOLAR_CONSTANT_1AU_W = 1361.0;

/** Mars axial tilt (obliquity) in degrees */
export const MARS_AXIAL_TILT_DEG = 25.19;

/** Solar longitude of Mars perihelion (IAU value Lp ≈ 251.12°) */
export const MARS_PERIHELION_LS = 251.12;

/**
 * Standard reference epochs for Mars Years (Todd Clancy et al. 2000 standard).
 * Mars Year 1 began at Ls = 0 on April 11, 1955 (JD_TT 2435207.5).
 */
export const MY1_START_JD = 2435207.5;

// ── Time & Coordinate Functions ─────────────────────────────────────────────

/**
 * Convert a JavaScript Date to Julian Date (UT).
 */
export function getJulianDateUT(date: Date = new Date()): number {
  return 2440587.5 + date.getTime() / MS_PER_DAY;
}

/**
 * Convert a JavaScript Date to Terrestrial Time (TT) Julian Date.
 */
export function getJulianDateTT(date: Date = new Date()): number {
  return getJulianDateUT(date) + (TT_MINUS_UTC_SECONDS / 86400.0);
}

/**
 * Compute the continuous Mars Sol Date (MSD) for a given Date.
 * MSD 0 was set to December 29, 1873, 12:00:00 TT.
 */
export function getMarsSolDate(date: Date = new Date()): number {
  const jdTT = getJulianDateTT(date);
  return (jdTT - 2405522.0028779) / MARS_SOL_RATIO;
}

export interface MarsClockTime {
  hours: number;
  minutes: number;
  seconds: number;
  decimalHours: number;
  formatted: string;
}

function hoursToClock(decimalHours: number, label = ''): MarsClockTime {
  const normalized = ((decimalHours % 24) + 24) % 24;
  const hours = Math.floor(normalized);
  const remainderMinutes = (normalized - hours) * 60;
  const minutes = Math.floor(remainderMinutes);
  const seconds = Math.floor((remainderMinutes - minutes) * 60);

  const hh = String(hours).padStart(2, '0');
  const mm = String(minutes).padStart(2, '0');
  const ss = String(seconds).padStart(2, '0');

  return {
    hours,
    minutes,
    seconds,
    decimalHours: normalized,
    formatted: label ? `${hh}:${mm}:${ss} ${label}` : `${hh}:${mm}:${ss}`,
  };
}

/**
 * Compute Coordinated Mars Time (MTC) at the Airy-0 prime meridian.
 * Equivalent to UTC on Earth.
 */
export function getCoordinatedMarsTime(date: Date = new Date()): MarsClockTime {
  const msd = getMarsSolDate(date);
  const mtcHours = (24.0 * msd) % 24.0;
  return hoursToClock(mtcHours, 'MTC');
}

/**
 * Compute Local Mean Solar Time (LMST) for a given Mars east longitude (in degrees).
 * Mars rotates 15 degrees per Martian hour (360° / 24h).
 */
export function getLocalMeanSolarTime(lonDeg: number, date: Date = new Date()): MarsClockTime {
  const mtc = getCoordinatedMarsTime(date);
  // Normalize longitude to [0, 360) East
  const eastLon = ((lonDeg % 360) + 360) % 360;
  const lmstHours = (mtc.decimalHours + eastLon / 15.0) % 24.0;
  return hoursToClock(lmstHours, 'LMST');
}

export interface MarsOrbitDetails {
  ls: number;
  season: string;
  marsYear: number;
  r_au: number;
  r_km: number;
  irradianceWm2: number;
  subsolarDecDeg: number;
  trueAnomalyDeg: number;
}

/**
 * Convert areocentric solar longitude (Ls) to northern hemisphere season.
 */
export function lsToSeason(ls: number): string {
  if (ls < 90) return 'Northern Spring / Southern Autumn';
  if (ls < 180) return 'Northern Summer / Southern Winter';
  if (ls < 270) return 'Northern Autumn / Southern Spring';
  return 'Northern Winter / Southern Summer';
}

/**
 * Compute high-precision Mars orbital geometry and seasonal parameters for a given date.
 * Uses Allison & McEwen (2000) perturbation series.
 */
export function getMarsOrbitDetails(date: Date = new Date()): MarsOrbitDetails {
  const jdTT = getJulianDateTT(date);
  const deltaJ2000 = jdTT - J2000_JD;

  // Mars Mean Anomaly M
  const mDeg = (19.3730 + 0.52402073 * deltaJ2000) % 360.0;
  const mRad = (mDeg * Math.PI) / 180.0;

  // Fictitious Mean Sun
  const alphaFms = (270.3871 + 0.52403843 * deltaJ2000) % 360.0;

  // Equation of Center (nu - M) with five-term perturbation series
  const nuMinusM =
    (10.6912 + 3.7e-7 * deltaJ2000) * Math.sin(mRad) +
    0.6228 * Math.sin(2.0 * mRad) +
    0.0503 * Math.sin(3.0 * mRad) +
    0.0046 * Math.sin(4.0 * mRad) +
    0.0005 * Math.sin(5.0 * mRad);

  // Solar Longitude Ls
  const ls = (((alphaFms + nuMinusM) % 360.0) + 360.0) % 360.0;

  // True Anomaly nu
  const trueAnomalyDeg = (((mDeg + nuMinusM) % 360.0) + 360.0) % 360.0;
  const nuRad = (trueAnomalyDeg * Math.PI) / 180.0;

  // Heliocentric distance r
  const e = MARS_ECCENTRICITY;
  const a = MARS_SEMI_MAJOR_AU;
  const r_au = (a * (1.0 - e * e)) / (1.0 + e * Math.cos(nuRad));
  const r_km = r_au * 1.495978707e8;

  // Solar irradiance at top of Mars atmosphere (inverse-square law)
  const irradianceWm2 = SOLAR_CONSTANT_1AU_W / (r_au * r_au);

  // Subsolar declination (latitude on Mars where Sun is at zenith)
  const tiltRad = (MARS_AXIAL_TILT_DEG * Math.PI) / 180.0;
  const lsRad = (ls * Math.PI) / 180.0;
  const decRad = Math.asin(Math.sin(tiltRad) * Math.sin(lsRad));
  const subsolarDecDeg = (decRad * 180.0) / Math.PI;

  // Mars Year calculation based on Ls=0 boundaries from 1955
  // MY 38 began ~ Nov 12, 2024. MY 39 began ~ Sep 30, 2026.
  const my = Math.floor((jdTT - MY1_START_JD) / 686.971) + 1;

  return {
    ls: Math.round(ls * 100) / 100,
    season: lsToSeason(ls),
    marsYear: my,
    r_au: Math.round(r_au * 10000) / 10000,
    r_km: Math.round(r_km),
    irradianceWm2: Math.round(irradianceWm2 * 10) / 10,
    subsolarDecDeg: Math.round(subsolarDecDeg * 100) / 100,
    trueAnomalyDeg: Math.round(trueAnomalyDeg * 100) / 100,
  };
}

// ── Real-Time React Hook ───────────────────────────────────────────────────

export interface RealTimeMarsClock {
  /** Current real-time Date object */
  now: Date;
  /** ISO UTC date string (YYYY-MM-DD) */
  utcDate: string;
  /** ISO UTC time string (HH:mm:ss UTC) */
  utcTime: string;
  /** Full UTC string (YYYY-MM-DD HH:mm:ss UTC) */
  utcFull: string;
  /** Raw Mars Sol Date (MSD) */
  msd: number;
  /** Formatted MSD, e.g. "Sol 54314" or "MSD 54314.52" */
  msdFormatted: string;
  /** Coordinated Mars Time, e.g. "12:25:17 MTC" */
  mtcFormatted: string;
  /** Local Mean Solar Time for specified longitude, e.g. "17:35:05 LMST" */
  lmstFormatted: string;
  /** Mars Year, e.g. 39 */
  marsYear: number;
  /** Mars Year string, e.g. "MY 39" */
  marsYearFormatted: string;
  /** Areocentric Solar Longitude Ls in degrees, e.g. 7.72 */
  ls: number;
  /** Formatted Ls, e.g. "Ls 7.7°" */
  lsFormatted: string;
  /** Current Martian season (Northern convention) */
  season: string;
  /** Mars-Sun distance in AU */
  distanceAu: number;
  /** Mars-Sun distance in km */
  distanceKm: number;
  /** Solar irradiance in W/m² */
  irradianceWm2: number;
  /** Subsolar declination in degrees */
  subsolarDecDeg: number;
}

/**
 * React hook that ticks every second with live Earth and Mars astronomical clock data.
 * If targetDate is specified (e.g. from user picking a custom date), it calculates for that date.
 */
export function useRealTimeMarsClock(
  lonDeg?: number,
  overrideDate?: string | null,
  intervalMs = 1000
): RealTimeMarsClock {
  const computeClock = (): RealTimeMarsClock => {
    let date = new Date();
    if (overrideDate) {
      // If user supplied a historical or future YYYY-MM-DD
      const parsed = new Date(overrideDate + 'T12:00:00Z');
      if (!isNaN(parsed.getTime())) {
        date = parsed;
      }
    }

    const msd = getMarsSolDate(date);
    const mtc = getCoordinatedMarsTime(date);
    const targetLon = lonDeg !== undefined ? lonDeg : 0;
    const lmst = getLocalMeanSolarTime(targetLon, date);
    const orbit = getMarsOrbitDetails(date);

    const year = date.getUTCFullYear();
    const month = String(date.getUTCMonth() + 1).padStart(2, '0');
    const day = String(date.getUTCDate()).padStart(2, '0');
    const hours = String(date.getUTCHours()).padStart(2, '0');
    const minutes = String(date.getUTCMinutes()).padStart(2, '0');
    const seconds = String(date.getUTCSeconds()).padStart(2, '0');

    const utcDate = `${year}-${month}-${day}`;
    const utcTime = `${hours}:${minutes}:${seconds} UTC`;
    const utcFull = `${utcDate} ${utcTime}`;

    return {
      now: date,
      utcDate,
      utcTime,
      utcFull,
      msd: Math.round(msd * 100000) / 100000,
      msdFormatted: `MSD ${msd.toFixed(2)}`,
      mtcFormatted: mtc.formatted,
      lmstFormatted: lmst.formatted,
      marsYear: orbit.marsYear,
      marsYearFormatted: `MY ${orbit.marsYear}`,
      ls: orbit.ls,
      lsFormatted: `L_s ${orbit.ls.toFixed(1)}°`,
      season: orbit.season,
      distanceAu: orbit.r_au,
      distanceKm: orbit.r_km,
      irradianceWm2: orbit.irradianceWm2,
      subsolarDecDeg: orbit.subsolarDecDeg,
    };
  };

  const [clock, setClock] = useState<RealTimeMarsClock>(computeClock);

  useEffect(() => {
    // Immediate compute on dependency change
    setClock(computeClock());

    // Live interval
    const timer = setInterval(() => {
      setClock(computeClock());
    }, intervalMs);

    return () => clearInterval(timer);
  }, [lonDeg, overrideDate, intervalMs]);

  return clock;
}
