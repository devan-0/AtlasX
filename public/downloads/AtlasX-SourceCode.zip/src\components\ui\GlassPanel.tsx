import React from 'react';

interface Props {
  children: React.ReactNode;
  className?: string;
  title?: string;
  badge?: React.ReactNode;
  actions?: React.ReactNode;
  noPad?: boolean;
}

export default function GlassPanel({ children, className = '', title, badge, actions, noPad }: Props) {
  return (
    <div className={`glass-panel ${noPad ? '' : 'p-4'} ${className}`}>
      {(title || badge || actions) && (
        <div className={`flex items-center gap-2 ${noPad ? 'px-4 pt-4' : ''} mb-3 pb-2.5 border-b border-white/5`}>
          {title && <span className="text-xs font-semibold uppercase tracking-widest text-slate-400">{title}</span>}
          {badge && <span>{badge}</span>}
          <div className="flex-1" />
          {actions}
        </div>
      )}
      {children}
    </div>
  );
}
