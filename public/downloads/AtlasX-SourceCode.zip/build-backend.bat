@echo off
REM build-backend.bat — Build the Python backend into mars_backend.exe
REM Run from the project root: .\build-backend.bat
echo.
echo ===========================
echo  Building Mars Backend EXE
echo ===========================
echo.

cd /d "%~dp0backend"

echo [1/3] Cleaning previous build...
if exist dist rmdir /S /Q dist
if exist build rmdir /S /Q build

echo [2/3] Running PyInstaller...
python -m PyInstaller mars_backend.spec --clean --noconfirm

if errorlevel 1 (
  echo.
  echo ERROR: PyInstaller build failed!
  pause
  exit /b 1
)

echo [3/3] Verifying output...
if exist "dist\mars_backend\mars_backend.exe" (
  echo.
  echo  SUCCESS: backend\dist\mars_backend\mars_backend.exe
  echo  Size: 
  dir "dist\mars_backend\mars_backend.exe" | findstr "mars_backend.exe"
) else (
  echo.
  echo ERROR: Expected output not found at dist\mars_backend\mars_backend.exe
  exit /b 1
)

echo.
echo Backend build complete.
cd /d "%~dp0"
