"""
generate_icon.py — Convert icon.svg → icon.png → icon.ico
Requires: pip install pillow cairosvg  (or just pillow if cairosvg unavailable)
"""

import sys
import os

def main():
    out_dir = os.path.dirname(os.path.abspath(__file__))
    svg_path = os.path.join(out_dir, 'icon.svg')
    png_path = os.path.join(out_dir, 'icon.png')
    ico_path = os.path.join(out_dir, 'icon.ico')

    # Try cairosvg first (best quality SVG→PNG)
    try:
        import cairosvg
        cairosvg.svg2png(url=svg_path, write_to=png_path, output_width=256, output_height=256)
        print(f'[cairosvg] Generated {png_path}')
    except ImportError:
        # Fallback: generate a pure-Python programmatic PNG via Pillow
        print('[cairosvg not available] Generating programmatic icon via Pillow...')
        try:
            from PIL import Image, ImageDraw, ImageFilter
            generate_pillow_icon(png_path)
        except ImportError:
            print('ERROR: Neither cairosvg nor Pillow is available.')
            print('Install with: pip install pillow')
            sys.exit(1)

    # Convert PNG → ICO with multiple resolutions
    from PIL import Image
    img = Image.open(png_path).convert('RGBA')

    sizes = [(16,16), (24,24), (32,32), (48,48), (64,64), (128,128), (256,256)]
    imgs = [img.resize(s, Image.LANCZOS) for s in sizes]
    imgs[0].save(ico_path, format='ICO', sizes=[(s[0], s[1]) for s in sizes],
                 append_images=imgs[1:])
    print(f'[pillow] Generated {ico_path}')


def generate_pillow_icon(png_path):
    """Draw a Mars icon programmatically using Pillow."""
    from PIL import Image, ImageDraw, ImageFilter
    import math

    SIZE = 256
    img = Image.new('RGBA', (SIZE, SIZE), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    # Background rounded rect (dark space)
    draw.rounded_rectangle([0, 0, SIZE-1, SIZE-1], radius=32, fill=(13, 20, 33, 255))

    # Stars
    for sx, sy in [(30,25),(220,40),(240,180),(15,200),(200,15),(45,230)]:
        draw.ellipse([sx-1,sy-1,sx+1,sy+1], fill=(255,255,255,180))

    # Mars sphere — radial gradient approximation
    cx, cy, r = 128, 128, 98
    for i in range(r, 0, -1):
        t = 1 - i/r
        red   = int(88  + (200-88)*t*t)
        green = int(30  + (80-30)*t*t)
        blue  = int(10  + (30-10)*t*t)
        alpha = 255
        draw.ellipse([cx-i, cy-i, cx+i, cy+i], fill=(red, green, blue, alpha))

    # Polar cap
    for i in range(14, 0, -1):
        t = 1 - i/14
        v = int(200 + 55*t)
        draw.ellipse([cx-42+i*2, cy-43-i, cx+42-i*2, cy-43+i], fill=(v,v,v-10,int(200*t)))

    # Crosshair
    green = (52, 211, 153, 200)
    lw = 3
    # Horizontal
    draw.line([(52,128),(88,128)], fill=green, width=lw)
    draw.line([(168,128),(204,128)], fill=green, width=lw)
    # Vertical
    draw.line([(128,52),(128,88)], fill=green, width=lw)
    draw.line([(128,168),(128,204)], fill=green, width=lw)
    # Center dot
    draw.ellipse([123,123,133,133], fill=green)
    # Dashed ring — approximate with arc segments
    for angle in range(0, 360, 20):
        x1 = cx + 18*math.cos(math.radians(angle)) - 2
        y1 = cy + 18*math.sin(math.radians(angle)) - 2
        x2 = cx + 18*math.cos(math.radians(angle+12)) + 2
        y2 = cy + 18*math.sin(math.radians(angle+12)) + 2
        draw.arc([cx-18,cy-18,cx+18,cy+18], angle, angle+10, fill=green, width=2)

    img.save(png_path, 'PNG')
    print(f'[pillow] Generated programmatic {png_path}')


if __name__ == '__main__':
    main()
