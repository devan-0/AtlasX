// AtlasX — Data Export Utilities
// Provides GeoJSON, JSON, CSV, HTML, and browser-download helpers.

import { Route, SavedMission, ScienceTarget } from '../types';

// ---------------------------------------------------------------------------
// GeoJSON export
// ---------------------------------------------------------------------------

/**
 * Export a Route as a GeoJSON FeatureCollection.
 *
 * The collection contains:
 *   1. A LineString feature for the full path geometry.
 *   2. A Point feature for each waypoint.
 *
 * Coordinates are [longitude, latitude] per GeoJSON spec (RFC 7946).
 * Mars elevation (metres) is included as the optional third element.
 */
export function routeToGeoJSON(route: Route): object {
  // Full path line
  const lineCoords = route.profile.map((pt) => [pt.lon, pt.lat, pt.elevation]);

  const lineFeature = {
    type: 'Feature',
    properties: {
      id: route.id,
      name: route.name,
      type: route.type,
      totalDistanceKm: route.totalDistance,
      estimatedDurationH: route.estimatedDuration,
      maxSlopeDeg: route.maxSlope,
      meanSlopeDeg: route.meanSlope,
      totalElevationGainM: route.totalElevationGain,
      totalElevationLossM: route.totalElevationLoss,
      hazardCount: route.hazardCount,
      scienceTargetsCount: route.scienceTargetsCount,
      totalCost: route.totalCost,
      costBreakdown: route.costBreakdown,
      createdAt: route.createdAt,
      notes: route.notes ?? null,
    },
    geometry: {
      type: 'LineString',
      coordinates: lineCoords,
    },
  };

  // Waypoint points
  const waypointFeatures = route.waypoints.map((wp) => ({
    type: 'Feature',
    properties: {
      id: wp.id,
      name: wp.name,
      waypointType: wp.type,
      scienceTargetId: wp.scienceTargetId ?? null,
      notes: wp.notes ?? null,
    },
    geometry: {
      type: 'Point',
      coordinates: [wp.coordinates.lon, wp.coordinates.lat],
    },
  }));

  return {
    type: 'FeatureCollection',
    features: [lineFeature, ...waypointFeatures],
    // Custom metadata (non-standard, in a dedicated namespace)
    atlasX: {
      exportedAt: new Date().toISOString(),
      crs: 'Mars_2000_Sphere_IAU (Planetocentric, degrees E)',
      application: 'AtlasX',
      version: '1.0.0',
    },
  };
}

// ---------------------------------------------------------------------------
// Mission JSON export
// ---------------------------------------------------------------------------

/**
 * Serialise a SavedMission to a formatted JSON string.
 *
 * Includes a metadata wrapper with schema version and export timestamp so
 * that future importers can handle version differences gracefully.
 */
export function missionToJSON(mission: SavedMission): string {
  const envelope = {
    schemaVersion: '1.0.0',
    exportedAt: new Date().toISOString(),
    application: 'AtlasX',
    mission,
  };
  return JSON.stringify(envelope, null, 2);
}

// ---------------------------------------------------------------------------
// Science targets CSV export
// ---------------------------------------------------------------------------

/** Escape a CSV field value: wrap in quotes if it contains comma, quote, or newline. */
function csvEscape(value: unknown): string {
  const str = value === null || value === undefined ? '' : String(value);
  if (str.includes(',') || str.includes('"') || str.includes('\n')) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

/**
 * Export an array of ScienceTarget objects to a CSV string.
 *
 * Columns (in order):
 *   id, name, lat, lon, category, priority, dataQuality,
 *   rationale, observations, missionStatus, estimatedDetourKm,
 *   uncertainty, notes, dataSource
 */
export function scienceTargetsToCSV(targets: ScienceTarget[]): string {
  const HEADERS = [
    'id',
    'name',
    'lat',
    'lon',
    'category',
    'priority',
    'dataQuality',
    'rationale',
    'observations',
    'missionStatus',
    'estimatedDetourKm',
    'uncertainty',
    'notes',
    'dataSource',
  ];

  const rows: string[] = [HEADERS.join(',')];

  for (const t of targets) {
    const row = [
      csvEscape(t.id),
      csvEscape(t.name),
      csvEscape(t.coordinates.lat),
      csvEscape(t.coordinates.lon),
      csvEscape(t.category),
      csvEscape(t.priority),
      csvEscape(t.dataQuality),
      csvEscape(t.rationale),
      csvEscape(t.observations.join('; ')),
      csvEscape(t.missionStatus),
      csvEscape(t.estimatedDetourKm ?? ''),
      csvEscape(t.uncertainty),
      csvEscape(t.notes ?? ''),
      csvEscape(t.dataSource),
    ];
    rows.push(row.join(','));
  }

  return rows.join('\r\n');
}

// ---------------------------------------------------------------------------
// HTML mission report
// ---------------------------------------------------------------------------

/** Format a number with a fixed number of decimals, returning '—' if null/undefined. */
function fmt(v: number | undefined | null, decimals = 1): string {
  if (v === null || v === undefined) return '—';
  return v.toFixed(decimals);
}

/**
 * Generate a self-contained HTML mission report string.
 *
 * The report includes:
 *   - Mission overview (name, region, creation/update dates, notes)
 *   - Route summary table (distance, duration, slopes, hazards, science targets)
 *   - Science targets table sorted by priority (descending)
 *   - Inline CSS for a clean, printable appearance
 *
 * @param mission - The mission to report on
 * @param routes  - Routes to include in the report
 * @param targets - Science targets to include
 * @returns HTML string
 */
export function generateMissionReport(
  mission: SavedMission,
  routes: Route[],
  targets: ScienceTarget[],
): string {
  const missionDate = new Date(mission.createdAt).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
  const updatedDate = new Date(mission.updatedAt).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  // ---- Route rows ----
  const routeRows = routes
    .map(
      (r) => `
      <tr>
        <td>${escapeHtml(r.name)}</td>
        <td>${escapeHtml(r.type)}</td>
        <td>${fmt(r.totalDistance, 2)} km</td>
        <td>${fmt(r.estimatedDuration)} h</td>
        <td>${fmt(r.maxSlope)}°</td>
        <td>${fmt(r.meanSlope)}°</td>
        <td>${r.totalElevationGain} m ↑ / ${r.totalElevationLoss} m ↓</td>
        <td>${r.hazardCount}</td>
        <td>${r.scienceTargetsCount}</td>
        <td>${fmt(r.totalCost, 3)}</td>
      </tr>`,
    )
    .join('');

  // ---- Science target rows (sorted by priority desc) ----
  const sortedTargets = [...targets].sort((a, b) => b.priority - a.priority);
  const targetRows = sortedTargets
    .map(
      (t) => `
      <tr>
        <td>${escapeHtml(t.name)}</td>
        <td>${t.priority}</td>
        <td>${escapeHtml(t.category)}</td>
        <td>${fmt(t.coordinates.lat, 4)}°, ${fmt(t.coordinates.lon, 4)}°</td>
        <td>${escapeHtml(t.dataQuality)}</td>
        <td>${escapeHtml(t.missionStatus)}</td>
        <td>${t.estimatedDetourKm !== undefined ? fmt(t.estimatedDetourKm, 2) + ' km' : '—'}</td>
        <td class="rationale">${escapeHtml(t.rationale)}</td>
      </tr>`,
    )
    .join('');

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Mission Report — ${escapeHtml(mission.name)}</title>
  <style>
    /* ---- Reset & base ---- */
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: 'Segoe UI', Arial, sans-serif;
      font-size: 13px;
      color: #1a1a1a;
      background: #fff;
      padding: 32px 40px;
      max-width: 1100px;
      margin: 0 auto;
    }
    /* ---- Header ---- */
    .report-header {
      border-bottom: 3px solid #c0392b;
      padding-bottom: 16px;
      margin-bottom: 24px;
    }
    .report-header h1 {
      font-size: 24px;
      font-weight: 700;
      color: #c0392b;
      letter-spacing: 0.5px;
    }
    .report-header .subtitle {
      font-size: 13px;
      color: #555;
      margin-top: 4px;
    }
    /* ---- Sections ---- */
    section { margin-bottom: 32px; }
    section h2 {
      font-size: 15px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.8px;
      border-bottom: 1px solid #e0e0e0;
      padding-bottom: 6px;
      margin-bottom: 12px;
      color: #333;
    }
    /* ---- Overview grid ---- */
    .overview-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
      gap: 10px 20px;
    }
    .overview-item label {
      display: block;
      font-size: 10px;
      text-transform: uppercase;
      letter-spacing: 0.6px;
      color: #888;
      margin-bottom: 2px;
    }
    .overview-item span {
      font-size: 13px;
      font-weight: 600;
      color: #222;
    }
    /* ---- Tables ---- */
    table {
      width: 100%;
      border-collapse: collapse;
      font-size: 12px;
    }
    th {
      background: #f0f0f0;
      color: #333;
      font-weight: 600;
      text-align: left;
      padding: 7px 10px;
      border: 1px solid #ddd;
    }
    td {
      padding: 6px 10px;
      border: 1px solid #e0e0e0;
      vertical-align: top;
    }
    tr:nth-child(even) td { background: #fafafa; }
    td.rationale { max-width: 280px; color: #444; }
    /* ---- Notes ---- */
    .notes-box {
      background: #f9f9f9;
      border-left: 3px solid #aaa;
      padding: 10px 14px;
      font-size: 12px;
      color: #444;
      white-space: pre-wrap;
    }
    /* ---- Footer ---- */
    .report-footer {
      margin-top: 40px;
      border-top: 1px solid #e0e0e0;
      padding-top: 12px;
      font-size: 11px;
      color: #999;
    }
    @media print {
      body { padding: 20px; }
      .report-header h1 { font-size: 20px; }
    }
  </style>
</head>
<body>

<div class="report-header">
  <h1>🚀 Mars Mission Report — ${escapeHtml(mission.name)}</h1>
  <div class="subtitle">
    Generated by AtlasX &nbsp;·&nbsp;
    Exported: ${new Date().toUTCString()}
  </div>
</div>

<section>
  <h2>Mission Overview</h2>
  <div class="overview-grid">
    <div class="overview-item">
      <label>Mission Name</label>
      <span>${escapeHtml(mission.name)}</span>
    </div>
    <div class="overview-item">
      <label>Region</label>
      <span>${escapeHtml(mission.region.name)}</span>
    </div>
    <div class="overview-item">
      <label>Region Scientific Interest</label>
      <span>${escapeHtml(mission.region.scientificInterest)}</span>
    </div>
    <div class="overview-item">
      <label>Centre Coordinates</label>
      <span>${fmt(mission.region.coordinates.lat, 4)}°, ${fmt(mission.region.coordinates.lon, 4)}°</span>
    </div>
    <div class="overview-item">
      <label>Bounding Box</label>
      <span>
        N ${fmt(mission.region.boundingBox.north, 2)}° /
        S ${fmt(mission.region.boundingBox.south, 2)}° /
        E ${fmt(mission.region.boundingBox.east, 2)}° /
        W ${fmt(mission.region.boundingBox.west, 2)}°
      </span>
    </div>
    <div class="overview-item">
      <label>Version</label>
      <span>${escapeHtml(mission.version)}</span>
    </div>
    <div class="overview-item">
      <label>Created</label>
      <span>${missionDate}</span>
    </div>
    <div class="overview-item">
      <label>Last Updated</label>
      <span>${updatedDate}</span>
    </div>
    <div class="overview-item">
      <label>Routes</label>
      <span>${routes.length}</span>
    </div>
    <div class="overview-item">
      <label>Science Targets</label>
      <span>${targets.length}</span>
    </div>
    <div class="overview-item">
      <label>Candidate Sites</label>
      <span>${mission.candidateSites.length}</span>
    </div>
  </div>
  ${mission.region.description ? `<p style="margin-top:12px;color:#555;font-size:12px;">${escapeHtml(mission.region.description)}</p>` : ''}
</section>

${
  routes.length > 0
    ? `<section>
  <h2>Routes (${routes.length})</h2>
  <table>
    <thead>
      <tr>
        <th>Name</th>
        <th>Type</th>
        <th>Distance</th>
        <th>Est. Duration</th>
        <th>Max Slope</th>
        <th>Mean Slope</th>
        <th>Elevation Δ</th>
        <th>Hazards</th>
        <th>Sci. Targets</th>
        <th>Total Cost</th>
      </tr>
    </thead>
    <tbody>${routeRows}</tbody>
  </table>
</section>`
    : ''
}

${
  targets.length > 0
    ? `<section>
  <h2>Science Targets (${targets.length})</h2>
  <table>
    <thead>
      <tr>
        <th>Name</th>
        <th>Priority</th>
        <th>Category</th>
        <th>Coordinates</th>
        <th>Data Quality</th>
        <th>Status</th>
        <th>Detour</th>
        <th>Rationale</th>
      </tr>
    </thead>
    <tbody>${targetRows}</tbody>
  </table>
</section>`
    : ''
}

${
  mission.notes
    ? `<section>
  <h2>Mission Notes</h2>
  <div class="notes-box">${escapeHtml(mission.notes)}</div>
</section>`
    : ''
}

<div class="report-footer">
  AtlasX &nbsp;·&nbsp; Mission ID: ${escapeHtml(mission.id)} &nbsp;·&nbsp;
  All coordinates are planetocentric, degrees East (0–360°) unless otherwise noted. &nbsp;·&nbsp;
  Data classifications may include observed, derived, modelled, simulated, or unavailable values.
</div>

</body>
</html>`;
}

// ---------------------------------------------------------------------------
// HTML helper — prevent XSS when embedding user-supplied strings
// ---------------------------------------------------------------------------

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// ---------------------------------------------------------------------------
// Browser download
// ---------------------------------------------------------------------------

/**
 * Trigger a file download in the browser.
 *
 * Creates a temporary <a> element with an object URL, programmatically clicks
 * it, then cleans up. Works in all modern browsers; no-op in non-browser
 * environments (e.g. Node.js unit test runners).
 *
 * @param content  - Text content of the file
 * @param filename - Suggested file name for the download dialog
 * @param mimeType - MIME type, e.g. 'application/json', 'text/csv'
 */
export function downloadFile(content: string, filename: string, mimeType: string): void {
  if (typeof document === 'undefined') {
    // Non-browser environment — no-op
    return;
  }

  const blob = new Blob([content], { type: `${mimeType};charset=utf-8;` });
  const url = URL.createObjectURL(blob);

  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  anchor.style.display = 'none';

  document.body.appendChild(anchor);
  anchor.click();

  // Clean up: remove element and revoke object URL after the browser has
  // had time to initiate the download.
  requestAnimationFrame(() => {
    document.body.removeChild(anchor);
    URL.revokeObjectURL(url);
  });
}
