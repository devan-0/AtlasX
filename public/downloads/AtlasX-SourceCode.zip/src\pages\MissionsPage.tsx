import React, { useState } from 'react';
import { useAppStore } from '../store/useAppStore';
import { missionToJSON, scienceTargetsToCSV, downloadFile } from '../utils/export';
import GlassPanel from '../components/ui/GlassPanel';
import { Bookmark, Save, Trash2, Download, Upload, FileJson, FileText, Plus } from 'lucide-react';

export default function MissionsPage() {
  const { savedMissions, activeMissionId, saveMission, loadMission, deleteMission, routes, scienceTargets, selectedRegion } = useAppStore();
  const [missionName, setMissionName] = useState('');
  const [missionNotes, setMissionNotes] = useState('');
  const [saved, setSaved] = useState(false);

  const handleSave = () => {
    if (!missionName.trim()) return;
    saveMission(missionName.trim(), missionNotes);
    setMissionName('');
    setMissionNotes('');
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const handleExportJSON = (mission: ReturnType<typeof useAppStore.getState>['savedMissions'][0]) => {
    const json = missionToJSON(mission);
    downloadFile(json, `${mission.name.replace(/\s+/g, '_')}_mission.json`, 'application/json');
  };

  const handleExportCSV = () => {
    const csv = scienceTargetsToCSV(scienceTargets);
    downloadFile(csv, 'science_targets.csv', 'text/csv');
  };

  return (
    <div className="h-full overflow-y-auto p-4 space-y-4">
      {/* Save form */}
      <GlassPanel title="Save Current Mission">
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3 text-[11px] text-slate-400 p-2 bg-white/3 rounded">
            <div><span className="text-slate-500">Region:</span> <span className="text-slate-200">{selectedRegion.name}</span></div>
            <div><span className="text-slate-500">Routes:</span> <span className="text-slate-200">{routes.length}</span></div>
            <div><span className="text-slate-500">Targets:</span> <span className="text-slate-200">{scienceTargets.length}</span></div>
          </div>
          <input
            value={missionName}
            onChange={e => setMissionName(e.target.value)}
            placeholder="Mission name (e.g. Jezero Delta Survey Alpha)"
            className="w-full bg-navy-900 border border-white/10 rounded px-3 py-2 text-sm text-slate-200 outline-none focus:border-mars-500/50 transition-colors"
          />
          <textarea
            rows={2}
            value={missionNotes}
            onChange={e => setMissionNotes(e.target.value)}
            placeholder="Mission notes, objectives, or comments…"
            className="w-full bg-navy-900 border border-white/10 rounded px-3 py-2 text-sm text-slate-200 outline-none focus:border-mars-500/50 transition-colors resize-none"
          />
          <div className="flex gap-2">
            <button
              onClick={handleSave}
              disabled={!missionName.trim()}
              className="flex items-center gap-2 px-4 py-2 bg-mars-600 hover:bg-mars-500 disabled:opacity-50 text-white text-sm font-medium rounded transition-colors"
            >
              <Save size={14} />
              {saved ? 'Saved!' : 'Save Mission'}
            </button>
            <button onClick={handleExportCSV}
              className="flex items-center gap-2 px-3 py-2 bg-white/5 hover:bg-white/10 text-slate-300 text-sm rounded transition-colors">
              <FileText size={14} /> Export Targets CSV
            </button>
          </div>
        </div>
      </GlassPanel>

      {/* Saved missions list */}
      <GlassPanel title={`Saved Missions (${savedMissions.length})`}>
        {savedMissions.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 gap-3">
            <Bookmark size={28} className="text-slate-600" />
            <div className="text-slate-500 text-sm">No saved missions yet</div>
            <div className="text-slate-600 text-xs max-w-xs text-center">Fill in a mission name above and click Save to record your current work session.</div>
          </div>
        ) : (
          <div className="space-y-2">
            {savedMissions.map(m => (
              <div key={m.id}
                className={`flex items-center gap-3 p-3 rounded-lg border transition-all ${m.id === activeMissionId ? 'border-mars-500/40 bg-mars-600/10' : 'border-white/5 hover:border-white/10'}`}>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium text-slate-200 truncate">{m.name}</span>
                    {m.id === activeMissionId && (
                      <span className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 font-mono">ACTIVE</span>
                    )}
                  </div>
                  <div className="text-[10px] text-slate-500 mt-0.5">
                    {m.region.name} · {m.routes.length} routes · {m.scienceTargets.length} targets · {new Date(m.createdAt).toLocaleDateString()}
                  </div>
                  {m.notes && <div className="text-[10px] text-slate-600 truncate mt-0.5">{m.notes}</div>}
                </div>
                <div className="flex items-center gap-1 flex-shrink-0">
                  <button onClick={() => loadMission(m.id)}
                    className="px-2 py-1 text-xs text-cyan-400 hover:bg-cyan-500/10 rounded transition-colors">Load</button>
                  <button onClick={() => handleExportJSON(m)}
                    className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-white/5 rounded transition-colors" title="Export JSON">
                    <FileJson size={13} />
                  </button>
                  <button onClick={() => deleteMission(m.id)}
                    className="p-1.5 text-slate-600 hover:text-red-400 hover:bg-red-500/10 rounded transition-colors" title="Delete">
                    <Trash2 size={13} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </GlassPanel>

      {/* Export info */}
      <GlassPanel title="Export Formats">
        <div className="text-xs text-slate-400 space-y-1.5">
          <div className="flex items-center gap-2"><FileJson size={12} className="text-cyan-400" /><span><span className="text-slate-200">JSON</span> — Full mission snapshot: region, routes, targets, layers, notes</span></div>
          <div className="flex items-center gap-2"><FileText size={12} className="text-emerald-400" /><span><span className="text-slate-200">CSV</span> — Science targets with coordinates, category, rationale, priority</span></div>
          <div className="mt-2 text-slate-500">PDF mission report generation requires the backend (FastAPI) to be running. See README.md for setup instructions.</div>
        </div>
      </GlassPanel>
    </div>
  );
}
