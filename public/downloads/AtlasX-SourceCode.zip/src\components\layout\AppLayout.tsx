// AppLayout — root shell that composes Sidebar, TopToolbar, page content, StatusBar
import React, { lazy, Suspense } from 'react';
import Sidebar from './Sidebar';
import TopToolbar from './TopToolbar';
import StatusBar from './StatusBar';
import LoadingSpinner from '../ui/LoadingSpinner';
import { useAppStore } from '../../store/useAppStore';

// Lazy-loaded page components
const OverviewPage    = lazy(() => import('../../pages/OverviewPage'));
const AtlasPage       = lazy(() => import('../../pages/AtlasPage'));
const Terrain3DPage   = lazy(() => import('../../pages/Terrain3DPage'));
const RoutesPage      = lazy(() => import('../../pages/RoutesPage'));
const SciencePage     = lazy(() => import('../../pages/SciencePage'));
const MineralsPage    = lazy(() => import('../../pages/MineralsPage'));
const SolarPage       = lazy(() => import('../../pages/SolarPage'));
const AtmospherePage  = lazy(() => import('../../pages/AtmospherePage'));
const SuitabilityPage = lazy(() => import('../../pages/SuitabilityPage'));
const ComparisonPage  = lazy(() => import('../../pages/ComparisonPage'));
const CataloguePage   = lazy(() => import('../../pages/CataloguePage'));
const MissionsPage    = lazy(() => import('../../pages/MissionsPage'));
const SettingsPage    = lazy(() => import('../../pages/SettingsPage'));

type NavPage =
  | 'overview' | 'atlas' | 'terrain3d' | 'routes' | 'science'
  | 'minerals' | 'solar' | 'atmosphere' | 'suitability'
  | 'comparison' | 'catalogue' | 'missions' | 'settings';

const PAGE_MAP: Record<NavPage, React.LazyExoticComponent<React.FC>> = {
  overview:    OverviewPage,
  atlas:       AtlasPage,
  terrain3d:   Terrain3DPage,
  routes:      RoutesPage,
  science:     SciencePage,
  minerals:    MineralsPage,
  solar:       SolarPage,
  atmosphere:  AtmospherePage,
  suitability: SuitabilityPage,
  comparison:  ComparisonPage,
  catalogue:   CataloguePage,
  missions:    MissionsPage,
  settings:    SettingsPage,
};

const PageFallback: React.FC = () => (
  <div className="flex-1 flex items-center justify-center">
    <LoadingSpinner size="lg" label="Loading module…" />
  </div>
);

const AppLayout: React.FC = () => {
  const activePage = useAppStore((s) => s.activePage) as NavPage;
  const ActivePage = PAGE_MAP[activePage] ?? OverviewPage;

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-gray-950 text-white">
      {/* Left sidebar */}
      <Sidebar />

      {/* Right column: toolbar + content + status */}
      <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
        {/* Top toolbar */}
        <TopToolbar />

        {/* Main scrollable content */}
        <main className="flex-1 overflow-hidden flex flex-col min-h-0">
          <Suspense fallback={<PageFallback />}>
            <ActivePage />
          </Suspense>
        </main>

        {/* Bottom status bar */}
        <StatusBar />
      </div>
    </div>
  );
};

export default AppLayout;
