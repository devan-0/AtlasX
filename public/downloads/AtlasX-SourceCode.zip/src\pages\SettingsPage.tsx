import React, { useState } from 'react';
import { useAppStore } from '../store/useAppStore';
import GlassPanel from '../components/ui/GlassPanel';
import { Settings, Globe, Ruler, MapPin, Trash2, Info, ExternalLink, Moon, Sun, Sparkles } from 'lucide-react';

const ATTRIBUTION = [
  { name: 'MOLA Elevation Data', src: 'NASA/GSFC, MGS mission', url: 'https://pds-geosciences.wustl.edu/missions/mgs/mola.html' },
  { name: 'HiRISE Imagery & DTMs', src: 'University of Arizona / NASA', url: 'https://www.uahirise.org' },
  { name: 'CRISM Mineral Maps', src: 'APL / NASA/MRO', url: 'https://crism.jhuapl.edu' },
  { name: 'MEDA Atmospheric Data', src: 'CAB / NASA (Perseverance)', url: 'https://pds.nasa.gov' },
  { name: 'OpenPlanetaryMap Basemap', src: 'OpenPlanetary (CTX/NASA)', url: 'https://openplanetary.org' },
  { name: 'InSight Seismic/Met Data', src: 'JPL / NASA InSight', url: 'https://pds.nasa.gov' },
];

export default function SettingsPage() {
  const {
    units,
    setUnits,
    coordFormat,
    setCoordFormat,
    regions,
    setSelectedRegion,
    selectedRegion,
    setShowIntro,
    theme,
    setTheme,
  } = useAppStore();
  const [cleared, setCleared] = useState(false);

  const handleClearCache = () => {
    try {
      localStorage.removeItem('atlasx-storage');
      localStorage.removeItem('mars-explorer-atlas');
      setCleared(true);
      setTimeout(() => setCleared(false), 2000);
    } catch {
      // ignore
    }
  };

  return (
    <div className="h-full overflow-y-auto p-4 space-y-4 max-w-3xl">
      {/* Appearance */}
      <GlassPanel title="Appearance">
        <div className="flex items-center justify-between py-1">
          <div>
            <div className="text-sm text-slate-200 font-medium">Theme</div>
            <div className="text-[11px] text-slate-500">Interface color scheme</div>
          </div>
          <div className="flex bg-white/5 rounded-lg p-0.5 gap-1 border border-white/10">
            <button
              onClick={() => setTheme('dark')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium transition-all ${
                theme === 'dark'
                  ? 'bg-mars-600/30 text-orange-400 border border-mars-500/50 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Moon size={13} />
              <span>Dark</span>
            </button>
            <button
              onClick={() => setTheme('bright')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium transition-all ${
                theme === 'bright'
                  ? 'bg-amber-500/20 text-amber-500 border border-amber-500/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Sun size={13} />
              <span>Bright</span>
            </button>
          </div>
        </div>
      </GlassPanel>

      {/* Units */}
      <GlassPanel title="Units & Coordinates">
        <div className="space-y-3">
          <div className="flex items-center justify-between py-1">
            <div>
              <div className="text-sm text-slate-200">Measurement Units</div>
              <div className="text-[11px] text-slate-500">Distance, elevation, speed</div>
            </div>
            <div className="flex bg-white/5 rounded-lg p-0.5 gap-0.5">
              {(['metric','imperial'] as const).map(u => (
                <button key={u} onClick={() => setUnits(u)}
                  className={`px-3 py-1 rounded text-xs font-medium capitalize transition-colors ${units === u ? 'bg-mars-600/30 text-orange-400' : 'text-slate-500 hover:text-slate-300'}`}>
                  {u}
                </button>
              ))}
            </div>
          </div>
          <div className="flex items-center justify-between py-1">
            <div>
              <div className="text-sm text-slate-200">Coordinate Format</div>
              <div className="text-[11px] text-slate-500">How coordinates are displayed</div>
            </div>
            <div className="flex bg-white/5 rounded-lg p-0.5 gap-0.5">
              {(['decimal','dms'] as const).map(f => (
                <button key={f} onClick={() => setCoordFormat(f)}
                  className={`px-3 py-1 rounded text-xs font-medium uppercase transition-colors ${coordFormat === f ? 'bg-mars-600/30 text-orange-400' : 'text-slate-500 hover:text-slate-300'}`}>
                  {f}
                </button>
              ))}
            </div>
          </div>
        </div>
      </GlassPanel>

      {/* Default region */}
      <GlassPanel title="Default Study Region">
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
          {regions.map(r => (
            <button key={r.id} onClick={() => setSelectedRegion(r)}
              className={`p-2 rounded border text-xs text-left transition-colors ${r.id === selectedRegion.id ? 'border-mars-500/40 bg-mars-600/10 text-orange-400' : 'border-white/5 hover:border-white/15 text-slate-400 hover:text-slate-200'}`}>
              <div className="font-medium">{r.name}</div>
              <div className="text-[10px] text-slate-500 mt-0.5 capitalize">{r.scientificInterest} interest</div>
            </button>
          ))}
        </div>
      </GlassPanel>

      {/* Cache */}
      <GlassPanel title="Cache Management">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-sm text-slate-200">Local State Cache</div>
            <div className="text-[11px] text-slate-500">Clears saved missions, routes, and preferences from localStorage</div>
          </div>
          <button onClick={handleClearCache}
            className="flex items-center gap-2 px-3 py-1.5 bg-red-500/10 hover:bg-red-500/20 text-red-400 text-xs rounded border border-red-500/20 transition-colors">
            <Trash2 size={12} />
            {cleared ? 'Cleared!' : 'Clear Cache'}
          </button>
        </div>
      </GlassPanel>

      {/* About */}
      <GlassPanel title="About AtlasX">
        <div className="space-y-3">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-mars-600/20 border border-mars-600/30 flex items-center justify-center flex-shrink-0">
              <span className="text-lg">🪐</span>
            </div>
            <div>
              <div className="font-semibold text-slate-100">AtlasX</div>
              <div className="text-[11px] text-slate-400">Version 1.0.0 · Standalone Planetary Exploration Platform</div>
              <div className="text-xs text-slate-300 mt-1">AtlasX – An Advanced Planetary Exploration, Surface Intelligence and Mission Planning Platform.</div>
            </div>
          </div>
          <div className="p-3 rounded-lg bg-orange-500/10 border border-orange-500/25 text-[11px] text-orange-200 space-y-1.5 leading-relaxed">
            <div className="font-semibold text-orange-300">Affiliation & Compliance Disclaimer:</div>
            <div>AtlasX is an independent educational and research project. It is not affiliated with, endorsed by, or officially associated with NASA or any other space agency.</div>
            <div className="text-[10px] text-orange-300/80 pt-1 border-t border-orange-500/20">
              Scientific Notice: Simulated telemetry and scoring data are for educational demonstration and analysis. No routes, scores, or analyses are certified for human spaceflight operations.
            </div>
          </div>
          <div className="text-[11px] text-slate-500">
            <span className="font-medium text-slate-400">License:</span> MIT License · Open source for educational and research purposes
          </div>
          <div className="pt-2 border-t border-white/5 flex items-center justify-between">
            <div>
              <div className="text-xs text-slate-200 font-medium">Application Launch Intro</div>
              <div className="text-[10px] text-slate-400">Replay the dynamic AtlasX animated intro sequence with audio & telemetry</div>
            </div>
            <button
              onClick={() => setShowIntro(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded bg-mars-600/25 hover:bg-mars-600/35 border border-mars-500/40 text-orange-200 text-xs font-semibold transition-colors"
            >
              <Sparkles size={12} className="text-amber-400" />
              Replay Intro
            </button>
          </div>
        </div>
      </GlassPanel>

      {/* Attribution */}
      <GlassPanel title="Data Attribution & Sources">
        <div className="space-y-1.5">
          {ATTRIBUTION.map((a, i) => (
            <div key={i} className="flex items-center justify-between py-1 border-b border-white/5 last:border-0">
              <div>
                <div className="text-xs text-slate-200">{a.name}</div>
                <div className="text-[10px] text-slate-500">{a.src}</div>
              </div>
              <a href={a.url} target="_blank" rel="noopener noreferrer"
                className="text-cyan-400 hover:text-cyan-300 transition-colors">
                <ExternalLink size={12} />
              </a>
            </div>
          ))}
        </div>
      </GlassPanel>

      {/* Stack */}
      <GlassPanel title="Technical Stack">
        <div className="grid grid-cols-2 gap-x-6 gap-y-1 text-[11px] text-slate-400">
          {[
            ['Frontend', 'React 18 + TypeScript'],
            ['Build', 'Vite 5'],
            ['Styling', 'Tailwind CSS 3'],
            ['State', 'Zustand 4'],
            ['Maps', 'Leaflet / react-leaflet'],
            ['3D', 'Three.js / @react-three/fiber'],
            ['Charts', 'Recharts 2'],
            ['Data Query', '@tanstack/react-query'],
            ['Runtime', 'Browser / Vite dev server'],
          ].map(([k, v], i) => (
            <div key={i} className="flex gap-2">
              <span className="text-slate-600 flex-shrink-0 w-20">{k}:</span>
              <span className="text-slate-300">{v}</span>
            </div>
          ))}
        </div>
      </GlassPanel>
    </div>
  );
}
