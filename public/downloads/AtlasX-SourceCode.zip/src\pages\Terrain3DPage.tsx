import React, { useRef, useState, useMemo, useEffect } from 'react';
import { Canvas, useFrame, ThreeElements } from '@react-three/fiber';
import { OrbitControls, Stars, Text, Grid } from '@react-three/drei';
import * as THREE from 'three';
import { useAppStore } from '../store/useAppStore';
import { HAZARDS, SCIENCE_TARGETS } from '../data/sampleData';
import DataBadge from '../components/ui/DataBadge';
import GlassPanel from '../components/ui/GlassPanel';
import { RotateCw, ZoomIn, Layers, Info } from 'lucide-react';

// Generate a procedural Mars terrain mesh
function generateTerrainGeometry(size: number, segments: number, exaggeration: number) {
  const geometry = new THREE.PlaneGeometry(size, size, segments, segments);
  const positions = geometry.attributes.position as THREE.BufferAttribute;
  const colors: number[] = [];
  const count = positions.count;

  for (let i = 0; i < count; i++) {
    const x = positions.getX(i);
    const z = positions.getZ(i);
    const nx = x / size;
    const nz = z / size;

    // Multi-octave noise approximation using trig
    const elevation =
      Math.sin(nx * 6.2 + 1.0) * 0.35 +
      Math.sin(nz * 5.1 + 0.5) * 0.30 +
      Math.sin((nx + nz) * 9.3 + 0.8) * 0.15 +
      Math.sin(nx * 15.0 + nz * 12.0) * 0.08 +
      Math.cos(nx * 20.0 - nz * 18.0 + 1.2) * 0.04 +
      Math.sin(nx * 3.0) * Math.cos(nz * 4.0) * 0.20 +
      Math.cos(nx * 25.0 + 2.0) * Math.sin(nz * 22.0) * 0.03;

    const y = elevation * 2.0 * exaggeration;
    positions.setY(i, y);

    // Color by elevation
    const t = (elevation + 0.8) / 1.6;
    const r = THREE.MathUtils.lerp(0.20, 0.78, t);
    const g = THREE.MathUtils.lerp(0.08, 0.42, t);
    const b = THREE.MathUtils.lerp(0.05, 0.25, t);
    colors.push(r, g, b);
  }

  geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
  geometry.computeVertexNormals();
  return geometry;
}

interface TerrainProps {
  exaggeration: number;
  wireframe: boolean;
}

function MarsTerrain({ exaggeration, wireframe }: TerrainProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  const geometry = useMemo(() => generateTerrainGeometry(20, 128, exaggeration), [exaggeration]);

  return (
    <mesh ref={meshRef} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
      <primitive object={geometry} attach="geometry" />
      <meshStandardMaterial
        vertexColors
        wireframe={wireframe}
        roughness={0.9}
        metalness={0.05}
        side={THREE.DoubleSide}
      />
    </mesh>
  );
}

function HazardMarker({ x, z, severity }: { x: number; z: number; severity: string }) {
  const colorMap: Record<string, string> = {
    low: '#22d3ee', moderate: '#f59e0b', high: '#ef4444', extreme: '#dc2626',
  };
  const color = colorMap[severity] || '#94a3b8';
  const meshRef = useRef<THREE.Mesh>(null);
  useFrame(({ clock }) => {
    if (meshRef.current) {
      meshRef.current.position.y = 0.15 + Math.sin(clock.getElapsedTime() * 2 + x) * 0.05;
    }
  });
  return (
    <mesh ref={meshRef} position={[x, 0.2, z]}>
      <sphereGeometry args={[0.12, 8, 8]} />
      <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.6} />
    </mesh>
  );
}

function ScienceMarker({ x, z }: { x: number; z: number }) {
  const meshRef = useRef<THREE.Mesh>(null);
  useFrame(({ clock }) => {
    if (meshRef.current) {
      meshRef.current.rotation.y = clock.getElapsedTime() * 0.8;
      meshRef.current.position.y = 0.25 + Math.sin(clock.getElapsedTime() * 1.5 + x) * 0.06;
    }
  });
  return (
    <mesh ref={meshRef} position={[x, 0.3, z]}>
      <octahedronGeometry args={[0.12, 0]} />
      <meshStandardMaterial color="#a78bfa" emissive="#7c3aed" emissiveIntensity={0.8} />
    </mesh>
  );
}

function SunLight() {
  const ref = useRef<THREE.DirectionalLight>(null);
  useFrame(({ clock }) => {
    if (ref.current) {
      const t = clock.getElapsedTime() * 0.1;
      ref.current.position.set(Math.cos(t) * 15, 10, Math.sin(t) * 15);
    }
  });
  return <directionalLight ref={ref} intensity={1.2} castShadow color="#ffd5b0" />;
}

export default function Terrain3DPage() {
  const { selectedRegion, routes, activeRouteId, theme } = useAppStore();
  const [exaggeration, setExaggeration] = useState(2);
  const [wireframe, setWireframe] = useState(false);
  const [cameraKey, setCameraKey] = useState(0);
  const [selectedInfo, setSelectedInfo] = useState<string | null>(null);
  const isBright = theme === 'bright';

  const activeRoute = routes.find(r => r.id === activeRouteId);

  // Scatter hazards and targets in the scene
  const hazardPositions = HAZARDS.map((hz, i) => ({
    x: ((i % 5) - 2) * 2.5 + Math.sin(i * 1.7) * 1.5,
    z: (Math.floor(i / 5) - 1) * 2.5 + Math.cos(i * 2.1) * 1.5,
    severity: hz.severity,
    name: hz.type,
  }));

  const sciPositions = SCIENCE_TARGETS.map((st, i) => ({
    x: Math.cos(i * 1.2) * 4 + Math.sin(i * 0.8) * 2,
    z: Math.sin(i * 1.5) * 4 + Math.cos(i * 0.9) * 2,
    name: st.name,
  }));

  return (
    <div className="flex flex-col h-full overflow-hidden">
      {/* Controls bar */}
      <div className={`flex items-center gap-4 px-4 py-2 border-b flex-shrink-0 ${
        isBright ? 'border-slate-200 bg-white/80' : 'border-white/5 bg-navy-900/60'
      }`}>
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400">Elevation ×</span>
          <input
            type="range" min={0.5} max={8} step={0.5} value={exaggeration}
            onChange={e => setExaggeration(parseFloat(e.target.value))}
            className="w-28 h-1 accent-orange-500"
          />
          <span className="text-xs font-mono text-orange-400 w-6">{exaggeration}</span>
        </div>
        <div className={`h-4 w-px ${isBright ? 'bg-slate-200' : 'bg-white/10'}`} />
        <label className="flex items-center gap-1.5 text-xs text-slate-400 cursor-pointer">
          <input type="checkbox" checked={wireframe} onChange={e => setWireframe(e.target.checked)} className="w-3 h-3 accent-orange-500" />
          Wireframe
        </label>
        <div className={`h-4 w-px ${isBright ? 'bg-slate-200' : 'bg-white/10'}`} />
        <button
          onClick={() => setCameraKey(k => k + 1)}
          className="flex items-center gap-1 text-xs text-slate-400 hover:text-slate-200 transition-colors"
        >
          <RotateCw size={12} /> Reset camera
        </button>
        <div className="flex-1" />
        <DataBadge classification="simulated" />
        <span className="text-[10px] text-orange-400 font-mono">SIMULATED TERRAIN — Procedural model</span>
      </div>

      {/* 3D Canvas */}
      <div className="flex-1 relative">
        <Canvas
          key={cameraKey}
          camera={{ position: [0, 8, 14], fov: 50, near: 0.1, far: 1000 }}
          style={{ background: isBright ? '#e2e8f0' : '#040810' }}
          shadows
        >
          <ambientLight intensity={isBright ? 0.75 : 0.3} color={isBright ? '#ffffff' : '#4060a0'} />
          <SunLight />
          {!isBright && <Stars radius={200} depth={60} count={3000} factor={3} fade speed={0.5} />}

          <MarsTerrain exaggeration={exaggeration} wireframe={wireframe} />

          {/* Hazard markers */}
          {hazardPositions.map((hp, i) => (
            <HazardMarker key={`hz-${i}`} x={hp.x} z={hp.z} severity={hp.severity} />
          ))}

          {/* Science markers */}
          {sciPositions.map((sp, i) => (
            <ScienceMarker key={`sci-${i}`} x={sp.x} z={sp.z} />
          ))}

          <OrbitControls
            enableDamping
            dampingFactor={0.05}
            minDistance={3}
            maxDistance={40}
            maxPolarAngle={Math.PI / 2.05}
          />

          {/* Grid overlay */}
          <Grid
            position={[0, -0.01, 0]}
            args={[20, 20]}
            cellSize={1}
            cellThickness={0.4}
            cellColor="#1e293b"
            sectionSize={5}
            sectionThickness={0.8}
            sectionColor="#334155"
            fadeDistance={30}
            fadeStrength={1}
          />
        </Canvas>

        {/* Overlay info */}
        <div className="absolute top-3 left-3 space-y-2 pointer-events-none">
          <GlassPanel className="!p-3 max-w-52 pointer-events-auto">
            <div className="text-[10px] text-slate-500 uppercase tracking-wide mb-2">Terrain Legend</div>
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-sm flex-shrink-0" style={{ background: 'linear-gradient(#321404, #c87040)' }} />
                <span className="text-xs text-slate-400">Elevation (low → high)</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full flex-shrink-0 bg-orange-400" style={{ opacity: 0.8 }} />
                <span className="text-xs text-slate-400">Hazard zone</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded flex-shrink-0 bg-violet-400" style={{ opacity: 0.8 }} />
                <span className="text-xs text-slate-400">Science target</span>
              </div>
            </div>
          </GlassPanel>
        </div>

        <div className="absolute bottom-3 left-3 pointer-events-none">
          <GlassPanel className="!p-2 pointer-events-auto">
            <div className="text-[10px] font-mono text-slate-500">Region: <span className="text-slate-300">{selectedRegion.name}</span></div>
            <div className="text-[10px] font-mono text-slate-500">Mesh: 128×128 segments · Procedural noise</div>
            <div className="text-[10px] font-mono text-orange-400/70">Not a scientifically accurate terrain model</div>
          </GlassPanel>
        </div>

        {/* Controls hint */}
        <div className="absolute bottom-3 right-3 pointer-events-none">
          <div className="text-[10px] font-mono text-slate-600 text-right space-y-0.5">
            <div>Left drag: rotate</div>
            <div>Right drag: pan</div>
            <div>Scroll: zoom</div>
          </div>
        </div>
      </div>
    </div>
  );
}
