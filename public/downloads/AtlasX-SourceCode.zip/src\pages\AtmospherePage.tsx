import React, { useMemo, useState } from 'react';
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { useAppStore } from '../store/useAppStore';
import { ATMOSPHERIC_DATA } from '../data/sampleData';
import { useInsightWeather } from '../services/hooks';
import DataBadge from '../components/ui/DataBadge';
import GlassPanel from '../components/ui/GlassPanel';
import { Wind, Thermometer, Gauge, CloudFog, Wifi, WifiOff, RefreshCw, ExternalLink, ShieldCheck, ShieldAlert, AlertTriangle, Eye, Sun } from 'lucide-react';
import { computeEVAMeteorologicalAdvisory } from '../utils/evaWeatherHazard';
import type { InsightWeatherSol } from '../services/api';

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="glass-panel p-2 text-xs space-y-0.5">
      <div className="text-slate-500">{label}</div>
      {payload.map((p: any, i: number) => (
        <div key={i} style={{ color: p.color }}>{p.name}: {typeof p.value === 'number' ? p.value.toFixed(2) : p.value ?? 'N/A'}</div>
      ))}
    </div>
  );
};

function WindRoseFromSols({ sols }: { sols: InsightWeatherSol[] }) {
  // InSight wind data doesn't have per-sol direction, show speed distribution as polar-style chart
  const bins = 7;
  const speeds = sols.map(s => s.wind_speed.average_m_s ?? 0).filter(v => v > 0);
  const maxSpeed = Math.max(...speeds, 1);
  const cx = 80, cy = 80, maxR = 58;

  return (
    <svg width={160} height={160} viewBox="0 0 160 160">
      {[0.25, 0.5, 0.75, 1].map(r => (
        <circle key={r} cx={cx} cy={cy} r={maxR * r} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth={1} />
      ))}
      {['N','NE','E','SE','S','SW','W','NW'].map((label, i) => {
        const a = (i * 45 - 90) * Math.PI / 180;
        return <text key={i} x={cx + (maxR + 12) * Math.cos(a)} y={cy + (maxR + 12) * Math.sin(a)}
          textAnchor="middle" dominantBaseline="middle"
          fill="rgba(148,163,184,0.7)" fontSize={9} fontFamily="monospace">{label}</text>;
      })}
      {speeds.slice(0, bins).map((spd, i) => {
        const a = (i * (360 / bins) - 90) * Math.PI / 180;
        const r = (spd / maxSpeed) * maxR;
        const half = (360 / bins * Math.PI / 180) / 2;
        const x1 = cx + r * Math.cos(a - half);
        const y1 = cy + r * Math.sin(a - half);
        const x2 = cx + r * Math.cos(a + half);
        const y2 = cy + r * Math.sin(a + half);
        return <path key={i} d={`M${cx},${cy} L${x1},${y1} A${r},${r} 0 0,1 ${x2},${y2} Z`}
          fill="rgba(34,211,238,0.35)" stroke="rgba(34,211,238,0.7)" strokeWidth={0.8} />;
      })}
    </svg>
  );
}

function SimulatedWindRose() {
  const data = ATMOSPHERIC_DATA;
  const bins = 8;
  const binSize = 360 / bins;
  const counts = Array(bins).fill(0);
  const magnitudes = Array(bins).fill(0);
  data.forEach(d => {
    if (d.windDirectionDeg !== undefined && d.windSpeedMs !== undefined) {
      const bin = Math.floor(((d.windDirectionDeg + binSize / 2) % 360) / binSize);
      counts[bin]++;
      magnitudes[bin] += d.windSpeedMs;
    }
  });
  const maxMag = Math.max(...magnitudes, 1);
  const cx = 80, cy = 80, maxR = 58;
  const labels = ['N','NE','E','SE','S','SW','W','NW'];
  return (
    <svg width={160} height={160} viewBox="0 0 160 160">
      {[0.25,0.5,0.75,1].map(r=><circle key={r} cx={cx} cy={cy} r={maxR*r} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth={1}/>)}
      {labels.map((_,i)=>{const a=(i*binSize-90)*Math.PI/180;return<line key={i} x1={cx} y1={cy} x2={cx+maxR*Math.cos(a)} y2={cy+maxR*Math.sin(a)} stroke="rgba(255,255,255,0.06)" strokeWidth={1}/>;} )}
      {counts.map((count,i)=>{if(!count)return null;const a=(i*binSize-90)*Math.PI/180;const r=(magnitudes[i]/maxMag)*maxR;const half=(binSize*Math.PI/180)/2;const x1=cx+r*Math.cos(a-half);const y1=cy+r*Math.sin(a-half);const x2=cx+r*Math.cos(a+half);const y2=cy+r*Math.sin(a+half);return<path key={i} d={`M${cx},${cy} L${x1},${y1} A${r},${r} 0 0,1 ${x2},${y2} Z`} fill="rgba(251,146,60,0.3)" stroke="rgba(251,146,60,0.7)" strokeWidth={0.8}/>;} )}
      {labels.map((label,i)=>{const a=(i*binSize-90)*Math.PI/180;return<text key={i} x={cx+(maxR+12)*Math.cos(a)} y={cy+(maxR+12)*Math.sin(a)} textAnchor="middle" dominantBaseline="middle" fill="rgba(148,163,184,0.7)" fontSize={9} fontFamily="monospace">{label}</text>;} )}
    </svg>
  );
}

export default function AtmospherePage() {
  const { selectedRegion, theme } = useAppStore();
  const isBright = theme === 'bright';
  const [activeTab, setActiveTab] = useState<'insight' | 'simulated'>('insight');

  // ── Real InSight data from NASA API via backend ───────────────────────────
  const insight = useInsightWeather();
  const isLive = insight.source === 'live' && !!insight.data?.sols?.length;

  // ── InSight chart data ────────────────────────────────────────────────────
  const insightChartData = useMemo(() => {
    if (!insight.data?.sols) return [];
    return insight.data.sols.map(sol => ({
      sol: `Sol ${sol.sol}`,
      tempAvg: sol.air_temperature.average_c,
      tempMin: sol.air_temperature.min_c,
      tempMax: sol.air_temperature.max_c,
      pressure: sol.pressure.average_pa,
      wind: sol.wind_speed.average_m_s,
    }));
  }, [insight.data]);

  // ── Simulated MEDA fallback data ──────────────────────────────────────────
  const simulatedChartData = useMemo(() => ATMOSPHERIC_DATA.map((d, i) => ({
    sol: d.timestamp.match(/Sol (\d+)/)?.[1] ?? String(i),
    temp: d.temperatureK != null ? Math.round(d.temperatureK) : null,
    pressure: d.pressurePa != null ? Math.round(d.pressurePa) : null,
    wind: d.windSpeedMs != null ? parseFloat(d.windSpeedMs.toFixed(1)) : null,
    dust: d.dustOpticalDepth != null ? parseFloat(d.dustOpticalDepth.toFixed(3)) : null,
  })), []);

  const latestSol = insight.data?.latest_sol;

  // ── Meteorological Stream EVA Survival Advisory ──
  const advisory = useMemo(() => {
    const currentTempK = isLive && latestSol?.air_temperature?.average_c != null
      ? latestSol.air_temperature.average_c + 273.15
      : 215;
    const currentPressure = isLive && latestSol?.pressure?.average_pa != null
      ? latestSol.pressure.average_pa
      : 740;
    const currentWind = isLive && latestSol?.wind_speed?.average_m_s != null
      ? latestSol.wind_speed.average_m_s
      : 6.2;

    return computeEVAMeteorologicalAdvisory({
      sol: latestSol?.sol ?? 1180,
      temperatureK: currentTempK,
      pressurePa: currentPressure,
      windSpeedMs: currentWind,
      dustOpticalDepth: 0.55,
    });
  }, [latestSol, isLive]);

  return (
    <div className="h-full overflow-y-auto p-4 space-y-4">

      {/* Status banner */}
      {insight.loading ? (
        <div className="flex items-center gap-2 p-2.5 rounded-lg bg-blue-500/10 border border-blue-500/20 text-xs text-blue-300">
          <div className="w-3 h-3 border border-blue-400 border-t-transparent rounded-full animate-spin" />
          Fetching real InSight weather data from NASA API…
        </div>
      ) : isLive ? (
        <div className="flex items-center gap-2 p-2.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-xs text-emerald-300">
          <Wifi size={13} />
          <span>
            <strong>LIVE NASA DATA</strong> — InSight APSS (Elysium Planitia, 4.5°N 135.6°E).
            Mission ended Dec 2022 — this is the last available real Mars weather observation.
          </span>
          <a href="https://mars.nasa.gov/insight/weather/" target="_blank" rel="noopener" className="ml-auto flex-shrink-0 text-emerald-400 hover:text-emerald-300">
            <ExternalLink size={12} />
          </a>
          <button onClick={insight.refetch} className="flex-shrink-0 text-emerald-400 hover:text-emerald-300">
            <RefreshCw size={12} />
          </button>
        </div>
      ) : (
        <div className="flex items-center gap-2 p-2.5 rounded-lg bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300">
          <WifiOff size={13} />
          <span>Backend not reachable — showing simulated seasonal pattern.
            Start <code className="font-mono bg-black/30 px-1 rounded">cd backend && python main.py</code> for real InSight data.</span>
          <button onClick={insight.refetch} className="ml-auto flex-shrink-0 text-blue-400 hover:text-blue-300">
            <RefreshCw size={12} />
          </button>
        </div>
      )}

      {/* EVA Meteorological Survival Hazard Advisory */}
      <div className={`p-4 rounded-lg border backdrop-blur-md ${
        isBright ? 'bg-white border-slate-200 shadow-sm' : 'bg-black/50 border-white/10'
      }`}>
        <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
          <div className="flex items-center gap-2.5">
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
              advisory.evaSafetyRating === 'NO_GO'
                ? 'bg-red-500/20 text-red-400'
                : advisory.evaSafetyRating === 'CAUTION'
                ? 'bg-amber-500/20 text-amber-400'
                : 'bg-emerald-500/20 text-emerald-400'
            }`}>
              {advisory.evaSafetyRating === 'NO_GO' ? (
                <ShieldAlert size={18} />
              ) : advisory.evaSafetyRating === 'CAUTION' ? (
                <AlertTriangle size={18} />
              ) : (
                <ShieldCheck size={18} />
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className={`text-sm font-bold uppercase tracking-wide ${isBright ? 'text-slate-900' : 'text-white'}`}>
                  EVA Meteorological Survival Rating:
                </span>
                <span className={`font-mono font-bold text-xs px-2 py-0.5 rounded ${
                  advisory.evaSafetyRating === 'NO_GO'
                    ? 'bg-red-500/20 text-red-400 border border-red-500/40 animate-pulse'
                    : advisory.evaSafetyRating === 'CAUTION'
                    ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                    : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                }`}>
                  {advisory.evaSafetyRating === 'NO_GO'
                    ? 'NO-GO / EXTREME METEOROLOGICAL HAZARD'
                    : advisory.evaSafetyRating === 'CAUTION'
                    ? 'CAUTION / RESTRICTED TRAVERSE RADIUS'
                    : 'GO / NOMINAL PLANETARY ATMOSPHERE'}
                </span>
              </div>
              <p className={`text-[11px] font-mono ${isBright ? 'text-slate-500' : 'text-slate-400'}`}>
                Pipelines: NASA MEDA (Mars 2020) & InSight APSS Atmospheric Telemetry
              </p>
            </div>
          </div>
          <DataBadge classification="modelled" />
        </div>

        {/* Hazard Metrics Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-3">
          <div className={`p-2.5 rounded border text-xs ${
            isBright ? 'bg-slate-50 border-slate-200' : 'bg-white/5 border-white/5'
          }`}>
            <span className="text-[10px] text-slate-500 uppercase font-mono block">Optical Visibility</span>
            <span className="font-mono text-cyan-400 font-bold text-sm">
              {(advisory.visibilityRangeMeters / 1000).toFixed(1)} km
            </span>
            <span className="text-[10px] text-slate-500 block">Koschmieder (tau: {advisory.dustOpticalDepthTau})</span>
          </div>

          <div className={`p-2.5 rounded border text-xs ${
            isBright ? 'bg-slate-50 border-slate-200' : 'bg-white/5 border-white/5'
          }`}>
            <span className="text-[10px] text-slate-500 uppercase font-mono block">Thermal Suit Load</span>
            <span className="font-mono text-amber-400 font-bold text-sm">
              +{advisory.thermalSuitPenaltyPercent}%
            </span>
            <span className="text-[10px] text-slate-500 block">Battery heating demand</span>
          </div>

          <div className={`p-2.5 rounded border text-xs ${
            isBright ? 'bg-slate-50 border-slate-200' : 'bg-white/5 border-white/5'
          }`}>
            <span className="text-[10px] text-slate-500 uppercase font-mono block">Dust Storm Risk</span>
            <span className={`font-mono font-bold text-sm capitalize ${
              advisory.stormRisk === 'severe' ? 'text-red-400' : advisory.stormRisk === 'high' ? 'text-orange-400' : 'text-emerald-400'
            }`}>
              {advisory.stormRisk}
            </span>
            <span className="text-[10px] text-slate-500 block">Optical depth tau: {advisory.dustOpticalDepthTau}</span>
          </div>

          <div className={`p-2.5 rounded border text-xs ${
            isBright ? 'bg-slate-50 border-slate-200' : 'bg-white/5 border-white/5'
          }`}>
            <span className="text-[10px] text-slate-500 uppercase font-mono block">Surface UV Index</span>
            <span className="font-mono text-violet-400 font-bold text-sm">
              {advisory.uvFluxIndex} / 10
            </span>
            <span className="text-[10px] text-slate-500 block">Direct unshielded UV-B/C</span>
          </div>
        </div>

        {/* Actionable Recommendations */}
        <div className="space-y-1">
          {advisory.recommendations.map((rec, i) => (
            <div key={i} className="text-xs font-mono text-slate-400 flex items-center gap-1.5">
              <span className="text-mars-orange">▸</span> {rec}
            </div>
          ))}
        </div>
      </div>
      <div className="flex items-center gap-1 p-1 rounded-lg bg-white/5 border border-white/5 w-fit">
        <button
          onClick={() => setActiveTab('insight')}
          className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all ${activeTab === 'insight' ? 'bg-mars-600/30 text-orange-300' : 'text-slate-500 hover:text-slate-300'}`}
        >
          {isLive ? '🔴 InSight APSS (Real)' : 'InSight APSS'}
        </button>
        <button
          onClick={() => setActiveTab('simulated')}
          className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all ${activeTab === 'simulated' ? 'bg-mars-600/30 text-orange-300' : 'text-slate-500 hover:text-slate-300'}`}
        >
          MEDA Simulated Pattern
        </button>
      </div>

      {/* ── INSIGHT REAL DATA TAB ── */}
      {activeTab === 'insight' && (
        <>
          {/* Latest sol stats */}
          {latestSol && (
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              {[
                {
                  icon: <Thermometer size={14} />,
                  label: 'Air Temperature (avg)',
                  value: latestSol.air_temperature.average_c != null ? `${latestSol.air_temperature.average_c.toFixed(1)} °C` : 'N/A',
                  sub: latestSol.air_temperature.min_c != null ? `${latestSol.air_temperature.min_c.toFixed(1)} to ${latestSol.air_temperature.max_c?.toFixed(1)} °C` : '',
                  badge: 'observed' as const,
                },
                {
                  icon: <Gauge size={14} />,
                  label: 'Atmospheric Pressure',
                  value: latestSol.pressure.average_pa != null ? `${latestSol.pressure.average_pa.toFixed(0)} Pa` : 'N/A',
                  sub: `~${latestSol.pressure.average_pa != null ? (latestSol.pressure.average_pa / 101325 * 100).toFixed(3) : '—'}% of Earth STP`,
                  badge: 'observed' as const,
                },
                {
                  icon: <Wind size={14} />,
                  label: 'Wind Speed (avg)',
                  value: latestSol.wind_speed.average_m_s != null ? `${latestSol.wind_speed.average_m_s.toFixed(2)} m/s` : 'N/A',
                  sub: `Max: ${latestSol.wind_speed.max_m_s?.toFixed(2) ?? '—'} m/s`,
                  badge: 'observed' as const,
                },
                {
                  icon: <CloudFog size={14} />,
                  label: 'Mars Sol',
                  value: `Sol ${latestSol.sol}`,
                  sub: latestSol.northern_season,
                  badge: 'observed' as const,
                },
              ].map((s, i) => (
                <div key={i} className="glass-panel p-3">
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-1.5 text-slate-500">{s.icon}<span className="text-[10px] uppercase tracking-wide">{s.label}</span></div>
                    <DataBadge classification={s.badge} />
                  </div>
                  <div className="text-lg font-bold font-mono text-slate-100">{s.value}</div>
                  <div className="text-[10px] text-slate-500">{s.sub}</div>
                </div>
              ))}
            </div>
          )}

          {!isLive && !insight.loading && (
            <div className="p-4 rounded-lg border border-white/5 bg-white/2 text-center text-xs text-slate-500">
              Start the backend API server to view real InSight APSS observations.
            </div>
          )}

          {insightChartData.length > 0 && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <GlassPanel title="Air Temperature — InSight APSS" badge={<DataBadge classification="observed" />}>
                <div className="text-[9px] text-slate-600 mb-2">Elysium Planitia surface air temperature (°C)</div>
                <ResponsiveContainer width="100%" height={160}>
                  <LineChart data={insightChartData} margin={{ top: 5, right: 10, bottom: 5, left: 30 }}>
                    <CartesianGrid strokeDasharray="3,3" stroke="rgba(255,255,255,0.04)" />
                    <XAxis dataKey="sol" tick={{ fill: '#64748b', fontSize: 9 }} />
                    <YAxis tick={{ fill: '#64748b', fontSize: 9 }} />
                    <Tooltip content={<CustomTooltip />} />
                    <Line type="monotone" dataKey="tempAvg" name="Avg Temp (°C)" stroke="#f87171" strokeWidth={2} dot={{ r: 3, fill: '#f87171' }} />
                    <Line type="monotone" dataKey="tempMin" name="Min (°C)" stroke="#60a5fa" strokeWidth={1} dot={false} strokeDasharray="3,2" />
                    <Line type="monotone" dataKey="tempMax" name="Max (°C)" stroke="#fb923c" strokeWidth={1} dot={false} strokeDasharray="3,2" />
                  </LineChart>
                </ResponsiveContainer>
              </GlassPanel>

              <GlassPanel title="Atmospheric Pressure — InSight APSS" badge={<DataBadge classification="observed" />}>
                <div className="text-[9px] text-slate-600 mb-2">Surface pressure (Pa) — Elysium Planitia</div>
                <ResponsiveContainer width="100%" height={160}>
                  <LineChart data={insightChartData} margin={{ top: 5, right: 10, bottom: 5, left: 40 }}>
                    <CartesianGrid strokeDasharray="3,3" stroke="rgba(255,255,255,0.04)" />
                    <XAxis dataKey="sol" tick={{ fill: '#64748b', fontSize: 9 }} />
                    <YAxis tick={{ fill: '#64748b', fontSize: 9 }} domain={['auto', 'auto']} />
                    <Tooltip content={<CustomTooltip />} />
                    <Line type="monotone" dataKey="pressure" name="Pressure (Pa)" stroke="#60a5fa" strokeWidth={2} dot={{ r: 3, fill: '#60a5fa' }} />
                  </LineChart>
                </ResponsiveContainer>
              </GlassPanel>

              <GlassPanel title="Wind Speed — InSight APSS" badge={<DataBadge classification="observed" />}>
                <div className="text-[9px] text-slate-600 mb-2">Horizontal wind speed (m/s) — InSight HWS sensor</div>
                <ResponsiveContainer width="100%" height={160}>
                  <AreaChart data={insightChartData} margin={{ top: 5, right: 10, bottom: 5, left: 25 }}>
                    <CartesianGrid strokeDasharray="3,3" stroke="rgba(255,255,255,0.04)" />
                    <XAxis dataKey="sol" tick={{ fill: '#64748b', fontSize: 9 }} />
                    <YAxis tick={{ fill: '#64748b', fontSize: 9 }} />
                    <Tooltip content={<CustomTooltip />} />
                    <Area type="monotone" dataKey="wind" name="Wind (m/s)" stroke="#34d399" fill="rgba(52,211,153,0.15)" strokeWidth={2} dot={{ r: 3, fill: '#34d399' }} />
                  </AreaChart>
                </ResponsiveContainer>
              </GlassPanel>

              <GlassPanel title="InSight Location & Instrument Info">
                <div className="space-y-2 text-xs text-slate-400">
                  {insight.data && (
                    <>
                      <div className="grid grid-cols-2 gap-x-4 gap-y-1.5">
                        <div><span className="text-slate-600">Location:</span> {insight.data.location.name}</div>
                        <div><span className="text-slate-600">Lat:</span> {insight.data.location.lat}°N</div>
                        <div><span className="text-slate-600">Lon:</span> {insight.data.location.lon}°E</div>
                        <div><span className="text-slate-600">Elevation:</span> {insight.data.location.elevation_m} m</div>
                        <div><span className="text-slate-600">Instrument:</span> {insight.data.instrument}</div>
                        <div><span className="text-slate-600">Mission ended:</span> {insight.data.mission_end_date}</div>
                      </div>
                      <div className="p-2 bg-blue-500/10 border border-blue-500/20 rounded text-[10px] text-blue-300">
                        {insight.data.note}
                      </div>
                      <a href={insight.data.source_url} target="_blank" rel="noopener"
                        className="flex items-center gap-1 text-cyan-400 hover:text-cyan-300 text-[11px]">
                        <ExternalLink size={11} /> View on NASA InSight Weather page
                      </a>
                    </>
                  )}
                </div>
              </GlassPanel>
            </div>
          )}
        </>
      )}

      {/* ── SIMULATED MEDA TAB ── */}
      {activeTab === 'simulated' && (
        <>
          <div className="flex items-start gap-3 p-3 rounded-lg bg-orange-500/10 border border-orange-500/20">
            <DataBadge classification="simulated" />
            <div className="text-xs text-orange-300">
              Synthetic seasonal pattern based on published MEDA (Perseverance) averages from Jezero Crater.
              NOT real-time data. For real MEDA data, see DATA_SOURCES.md.
            </div>
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            {(() => {
              const temps = ATMOSPHERIC_DATA.map(d => d.temperatureK).filter(Boolean) as number[];
              const press = ATMOSPHERIC_DATA.map(d => d.pressurePa).filter(Boolean) as number[];
              const winds = ATMOSPHERIC_DATA.map(d => d.windSpeedMs).filter(Boolean) as number[];
              const dust  = ATMOSPHERIC_DATA.map(d => d.dustOpticalDepth).filter(Boolean) as number[];
              const avg = (arr: number[]) => arr.length ? arr.reduce((a,b) => a+b, 0) / arr.length : 0;
              return [
                { icon: <Thermometer size={14}/>, label: 'Avg Temperature', value: `${avg(temps).toFixed(0)} K`, sub: `${Math.min(...temps).toFixed(0)}–${Math.max(...temps).toFixed(0)} K` },
                { icon: <Gauge size={14}/>, label: 'Avg Pressure', value: `${avg(press).toFixed(0)} Pa`, sub: `~${(avg(press)/101325*100).toFixed(3)}% Earth STP` },
                { icon: <Wind size={14}/>, label: 'Avg Wind', value: `${avg(winds).toFixed(1)} m/s`, sub: `Max: ${Math.max(...winds).toFixed(1)} m/s` },
                { icon: <CloudFog size={14}/>, label: 'Mean Dust τ', value: avg(dust).toFixed(2), sub: 'Optical depth' },
              ];
            })().map((s, i) => (
              <div key={i} className="glass-panel p-3">
                <div className="flex items-center gap-1.5 mb-1 text-slate-500">{s.icon}<span className="text-[10px] uppercase tracking-wide">{s.label}</span></div>
                <div className="text-lg font-bold font-mono text-slate-100">{s.value}</div>
                <div className="text-[10px] text-slate-500">{s.sub}</div>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <GlassPanel title="Temperature over Sols" badge={<DataBadge classification="simulated" />}>
              <ResponsiveContainer width="100%" height={160}>
                <LineChart data={simulatedChartData} margin={{ top: 5, right: 10, bottom: 5, left: 30 }}>
                  <CartesianGrid strokeDasharray="3,3" stroke="rgba(255,255,255,0.04)" />
                  <XAxis dataKey="sol" tick={{ fill: '#64748b', fontSize: 9 }} interval={5} />
                  <YAxis tick={{ fill: '#64748b', fontSize: 9 }} />
                  <Tooltip content={<CustomTooltip />} />
                  <Line type="monotone" dataKey="temp" name="Temperature (K)" stroke="#f87171" strokeWidth={1.5} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </GlassPanel>

            <GlassPanel title="Pressure over Sols" badge={<DataBadge classification="simulated" />}>
              <ResponsiveContainer width="100%" height={160}>
                <LineChart data={simulatedChartData} margin={{ top: 5, right: 10, bottom: 5, left: 35 }}>
                  <CartesianGrid strokeDasharray="3,3" stroke="rgba(255,255,255,0.04)" />
                  <XAxis dataKey="sol" tick={{ fill: '#64748b', fontSize: 9 }} interval={5} />
                  <YAxis tick={{ fill: '#64748b', fontSize: 9 }} />
                  <Tooltip content={<CustomTooltip />} />
                  <Line type="monotone" dataKey="pressure" name="Pressure (Pa)" stroke="#60a5fa" strokeWidth={1.5} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </GlassPanel>

            <GlassPanel title="Simulated Wind Rose" badge={<DataBadge classification="simulated" />}>
              <div className="flex items-center gap-6">
                <SimulatedWindRose />
                <div className="space-y-1 text-xs text-slate-400">
                  <div>Petal length: avg wind speed per direction</div>
                  <div>8 directional bins (45° each)</div>
                  <div>Based on {ATMOSPHERIC_DATA.length} synthetic observations</div>
                  <div className="text-orange-400 text-[10px] mt-2">⚠ Synthetic — not actual measurements</div>
                </div>
              </div>
            </GlassPanel>

            <GlassPanel title="Real MEDA Data Access">
              <div className="space-y-2 text-xs text-slate-400">
                <div className="flex items-start gap-2"><span className="text-slate-600">Instrument:</span><span>MEDA (Mars Environmental Dynamics Analyzer)</span></div>
                <div className="flex items-start gap-2"><span className="text-slate-600">Mission:</span><span>Perseverance (Mars 2020)</span></div>
                <div className="flex items-start gap-2"><span className="text-slate-600">Location:</span><span>Jezero Crater, {selectedRegion.coordinates.lat.toFixed(2)}°N</span></div>
                <div className="mt-2 p-2 bg-blue-500/10 border border-blue-500/20 rounded text-[10px] text-blue-300">
                  Real MEDA data is available at the NASA PDS Atmospheres Node.
                  See DATA_SOURCES.md for the integration pipeline.
                </div>
              </div>
            </GlassPanel>
          </div>
        </>
      )}
    </div>
  );
}
