import React, { useState } from 'react';
import { DATASETS } from '../data/sampleData';
import DataBadge from '../components/ui/DataBadge';
import GlassPanel from '../components/ui/GlassPanel';
import { Database, ExternalLink, ChevronDown, ChevronRight, Filter } from 'lucide-react';
import type { DataClassification } from '../types';

const PROC_STATUS: Record<string, string> = {
  raw: 'bg-slate-500/20 text-slate-400',
  calibrated: 'bg-blue-500/20 text-blue-400',
  derived: 'bg-cyan-500/20 text-cyan-400',
  synthesized: 'bg-orange-500/20 text-orange-400',
  unavailable: 'bg-red-500/20 text-red-400',
};

export default function CataloguePage() {
  const [expanded, setExpanded] = useState<string | null>(null);
  const [filterCls, setFilterCls] = useState<DataClassification | 'all'>('all');

  const filtered = filterCls === 'all' ? DATASETS : DATASETS.filter(d => d.classification === filterCls);
  const CLS_TYPES: (DataClassification | 'all')[] = ['all', 'observed', 'derived', 'modelled', 'simulated', 'unavailable'];

  return (
    <div className="h-full overflow-y-auto p-4 space-y-4">
      {/* Legend */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-2">
        {(['observed','derived','modelled','simulated','unavailable'] as DataClassification[]).map(cls => (
          <div key={cls} className="glass-panel p-2 flex items-center gap-2">
            <DataBadge classification={cls} />
            <div className="text-[10px] text-slate-400 leading-tight">
              {cls === 'observed' && 'Instrument measurement'}
              {cls === 'derived' && 'Calculated from data'}
              {cls === 'modelled' && 'Model output'}
              {cls === 'simulated' && 'Synthetic demo'}
              {cls === 'unavailable' && 'Not accessible'}
            </div>
          </div>
        ))}
      </div>

      {/* Filter */}
      <div className="flex items-center gap-2">
        <Filter size={13} className="text-slate-500" />
        <span className="text-xs text-slate-500">Filter:</span>
        {CLS_TYPES.map(c => (
          <button key={c} onClick={() => setFilterCls(c)}
            className={`px-2 py-0.5 rounded text-[10px] font-medium capitalize transition-colors ${filterCls === c ? 'bg-mars-600/30 text-orange-400 border border-mars-600/30' : 'text-slate-500 hover:text-slate-300'}`}>
            {c}
          </button>
        ))}
        <span className="ml-auto text-[10px] text-slate-500">{filtered.length} datasets</span>
      </div>

      {/* Dataset rows */}
      <div className="space-y-2">
        {filtered.map(ds => (
          <div key={ds.id} className="glass-panel overflow-hidden">
            {/* Header row */}
            <button
              className="w-full flex items-center gap-3 px-4 py-3 hover:bg-white/3 transition-colors text-left"
              onClick={() => setExpanded(expanded === ds.id ? null : ds.id)}
            >
              {expanded === ds.id ? <ChevronDown size={14} className="text-slate-400 flex-shrink-0" /> : <ChevronRight size={14} className="text-slate-500 flex-shrink-0" />}
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium text-slate-200 truncate">{ds.name}</div>
                <div className="text-[11px] text-slate-500">{ds.instrument} · {ds.mission}</div>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <DataBadge classification={ds.classification} />
                <span className={`text-[10px] px-1.5 py-0.5 rounded font-mono capitalize ${PROC_STATUS[ds.processingStatus] ?? ''}`}>
                  {ds.processingStatus}
                </span>
                <span className="text-[10px] text-slate-500 font-mono w-24 text-right">{ds.resolution}</span>
              </div>
            </button>

            {/* Expanded detail */}
            {expanded === ds.id && (
              <div className="border-t border-white/5 px-4 py-3 grid grid-cols-2 gap-3 text-xs bg-white/2">
                <div>
                  <div className="text-[10px] text-slate-500 uppercase tracking-wide mb-0.5">Acquisition Date</div>
                  <div className="text-slate-300">{ds.acquisitionDate ?? '—'}</div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-500 uppercase tracking-wide mb-0.5">Coverage</div>
                  <div className="text-slate-300">{ds.coverage}</div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-500 uppercase tracking-wide mb-0.5">CRS / Projection</div>
                  <div className="text-slate-300 font-mono">{ds.crs}</div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-500 uppercase tracking-wide mb-0.5">Last Retrieval</div>
                  <div className="text-slate-300">{ds.lastRetrieval ?? 'Not yet retrieved'}</div>
                </div>
                <div className="col-span-2">
                  <div className="text-[10px] text-slate-500 uppercase tracking-wide mb-0.5">Source URL</div>
                  <a href={ds.sourceUrl} target="_blank" rel="noopener noreferrer"
                    className="text-cyan-400 hover:text-cyan-300 break-all flex items-center gap-1 transition-colors">
                    {ds.sourceUrl} <ExternalLink size={10} />
                  </a>
                </div>
                {ds.notes && (
                  <div className="col-span-2">
                    <div className="text-[10px] text-slate-500 uppercase tracking-wide mb-0.5">Notes</div>
                    <div className="text-slate-400">{ds.notes}</div>
                  </div>
                )}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Integration note */}
      <GlassPanel title="Real Data Integration">
        <div className="text-xs text-slate-400 space-y-1">
          <div>Real datasets are accessible from the sources linked above. To integrate live data into this application:</div>
          <ol className="list-decimal ml-4 space-y-1 mt-1">
            <li>Implement a backend proxy (FastAPI) to fetch from NASA PDS or OPeNDAP servers</li>
            <li>Parse GeoTIFF/NetCDF files using GDAL/rasterio on the backend</li>
            <li>Serve tiled data via a Tile Map Service (TMS) endpoint to the Leaflet frontend</li>
            <li>Cache processed tiles in SQLite or filesystem cache</li>
          </ol>
          <div className="mt-2 text-slate-500">See <span className="font-mono text-cyan-400">DATA_SOURCES.md</span> for detailed integration instructions.</div>
        </div>
      </GlassPanel>
    </div>
  );
}
