$root = Split-Path -Parent $PSScriptRoot
$zipPath = Join-Path $root "AtlasX-SourceCode.zip"
if (Test-Path $zipPath) { Remove-Item $zipPath -Force }

$tempDir = Join-Path $env:TEMP ("atlasx_src_" + [Guid]::NewGuid().ToString("N"))
New-Item -ItemType Directory -Path $tempDir -Force | Out-Null

$excludes = @("node_modules", "dist", "app", "release", ".git", "AtlasX-SourceCode.zip")
Get-ChildItem -Path $root | Where-Object { $excludes -notcontains $_.Name } | ForEach-Object {
    if ($_.PSIsContainer) {
        if ($_.Name -eq "backend") {
            $backendTemp = Join-Path $tempDir "backend"
            New-Item -ItemType Directory -Path $backendTemp -Force | Out-Null
            Copy-Item (Join-Path $root "backend\main.py") $backendTemp
            Copy-Item (Join-Path $root "backend\mars_backend.spec") $backendTemp
            Copy-Item (Join-Path $root "backend\requirements.txt") $backendTemp
        } else {
            Copy-Item -Path $_.FullName -Destination (Join-Path $tempDir $_.Name) -Recurse
        }
    } else {
        Copy-Item -Path $_.FullName -Destination (Join-Path $tempDir $_.Name)
    }
}

Compress-Archive -Path (Join-Path $tempDir "*") -DestinationPath $zipPath -CompressionLevel Optimal
Remove-Item -Path $tempDir -Recurse -Force
Get-Item $zipPath | Select-Object Name, Length, LastWriteTime
